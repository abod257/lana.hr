import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth, hasPermission } from "@/lib/auth";
import { ApiResponse, handleApiError } from "@/lib/api-response";
import { createAuditLog, getClientInfo } from "@/lib/audit";
import { attendanceSchema } from "@/lib/validations";
import { generateId } from "@/lib/utils";
import { differenceInMinutes, parseISO, startOfDay } from "date-fns";

export async function GET(request: NextRequest) {
  try {
    const user = await requireAuth();
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get("page") || "1");
    const pageSize = parseInt(searchParams.get("pageSize") || "30");
    const employeeId = searchParams.get("employeeId");
    const startDate = searchParams.get("startDate");
    const endDate = searchParams.get("endDate");

    const where: any = {};
    if (employeeId) where.employeeId = employeeId;
    if (startDate && endDate) {
      where.date = {
        gte: new Date(startDate),
        lte: new Date(endDate),
      };
    } else if (startDate) {
      where.date = { gte: new Date(startDate) };
    }

    // Role-based filter
    if (!hasPermission(user, "attendance.view_all")) {
      if (hasPermission(user, "attendance.view_team") && user.employee) {
        where.employee = { managerId: user.employee.id };
      } else if (user.employee) {
        where.employeeId = user.employee.id;
      }
    }

    const [records, total] = await Promise.all([
      prisma.attendance.findMany({
        where,
        include: {
          employee: {
            select: { id: true, employeeCode: true, firstNameEn: true, lastNameEn: true, firstNameAr: true, lastNameAr: true },
          },
        },
        orderBy: { date: "desc" },
        skip: (page - 1) * pageSize,
        take: pageSize,
      }),
      prisma.attendance.count({ where }),
    ]);

    return ApiResponse.paginated(records, total, page, pageSize);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await requireAuth();
    if (!hasPermission(user, "attendance.manage")) {
      return ApiResponse.forbidden();
    }

    const body = await request.json();
    const validated = attendanceSchema.parse(body);
    const { ipAddress, userAgent } = getClientInfo(request);

    const attendance = await prisma.attendance.upsert({
      where: {
        employeeId_date: {
          employeeId: validated.employeeId,
          date: new Date(validated.date),
        },
      },
      create: {
        ...validated,
        date: new Date(validated.date),
        checkIn: validated.checkIn ? new Date(validated.checkIn) : null,
        checkOut: validated.checkOut ? new Date(validated.checkOut) : null,
      },
      update: {
        checkIn: validated.checkIn ? new Date(validated.checkIn) : undefined,
        checkOut: validated.checkOut ? new Date(validated.checkOut) : undefined,
        status: validated.status,
        notes: validated.notes,
      },
    });

    await createAuditLog({
      userId: user.id,
      action: "CREATE",
      resource: "Attendance",
      resourceId: attendance.id,
      description: `Attendance recorded for ${validated.date}`,
      ipAddress,
      userAgent,
    });

    return ApiResponse.success(attendance);
  } catch (error) {
    return handleApiError(error);
  }
}
