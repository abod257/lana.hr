"use client";

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Bell, CheckCircle2, Clock, AlertCircle, FileText, Calendar } from "lucide-react";
import Link from "next/link";
import { formatRelativeTime } from "@/lib/utils";

export function DashboardRecent({ data }: { data: any }) {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Recent Notifications */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Bell className="h-5 w-5 text-primary" />
                Recent Notifications
              </CardTitle>
              <CardDescription>
                {data.unreadNotifications > 0
                  ? `${data.unreadNotifications} unread`
                  : "All caught up!"}
              </CardDescription>
            </div>
            <Link href="/notifications">
              <Button variant="ghost" size="sm">View All</Button>
            </Link>
          </div>
        </CardHeader>
        <CardContent>
          {data.recentNotifications.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <CheckCircle2 className="h-12 w-12 mx-auto mb-2 opacity-50" />
              <p className="text-sm">No notifications</p>
            </div>
          ) : (
            <div className="space-y-2">
              {data.recentNotifications.slice(0, 5).map((notif: any) => (
                <Link
                  key={notif.id}
                  href={notif.link || "/notifications"}
                  className="flex items-start gap-3 p-3 rounded-lg hover:bg-accent transition-colors"
                >
                  <div className={`h-2 w-2 rounded-full mt-2 ${notif.isRead ? "bg-muted" : "bg-primary animate-pulse"}`} />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium">{notif.titleEn}</p>
                    <p className="text-xs text-muted-foreground line-clamp-2 mt-0.5">
                      {notif.messageEn}
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">
                      {formatRelativeTime(notif.createdAt, "en")}
                    </p>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Pending Approvals */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5 text-warning" />
            Pending Approvals
          </CardTitle>
          <CardDescription>Items requiring your attention</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <Link href="/leave" className="flex items-center justify-between p-3 rounded-lg hover:bg-accent">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-amber-100 dark:bg-amber-950/30 flex items-center justify-center">
                  <Calendar className="h-5 w-5 text-amber-600" />
                </div>
                <div>
                  <p className="text-sm font-medium">Leave Requests</p>
                  <p className="text-xs text-muted-foreground">Pending review</p>
                </div>
              </div>
              <Badge variant="warning">{data.pendingLeaveRequests}</Badge>
            </Link>

            <Link href="/payroll" className="flex items-center justify-between p-3 rounded-lg hover:bg-accent">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-blue-100 dark:bg-blue-950/30 flex items-center justify-center">
                  <FileText className="h-5 w-5 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm font-medium">Loan Requests</p>
                  <p className="text-xs text-muted-foreground">Pending approval</p>
                </div>
              </div>
              <Badge variant="info">{data.pendingLoanRequests}</Badge>
            </Link>

            <Link href="/payroll" className="flex items-center justify-between p-3 rounded-lg hover:bg-accent">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-green-100 dark:bg-green-950/30 flex items-center justify-center">
                  <FileText className="h-5 w-5 text-green-600" />
                </div>
                <div>
                  <p className="text-sm font-medium">Expense Claims</p>
                  <p className="text-xs text-muted-foreground">To be reimbursed</p>
                </div>
              </div>
              <Badge variant="success">{data.pendingExpenseClaims}</Badge>
            </Link>

            <Link href="/payroll" className="flex items-center justify-between p-3 rounded-lg hover:bg-accent">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-purple-100 dark:bg-purple-950/30 flex items-center justify-center">
                  <Clock className="h-5 w-5 text-purple-600" />
                </div>
                <div>
                  <p className="text-sm font-medium">Overtime Requests</p>
                  <p className="text-xs text-muted-foreground">Pending review</p>
                </div>
              </div>
              <Badge variant="secondary">{data.pendingOvertimeRequests}</Badge>
            </Link>

            {data.expiringDocs > 0 && (
              <Link href="/documents" className="flex items-center justify-between p-3 rounded-lg hover:bg-accent">
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-lg bg-red-100 dark:bg-red-950/30 flex items-center justify-center">
                    <AlertCircle className="h-5 w-5 text-red-600" />
                  </div>
                  <div>
                    <p className="text-sm font-medium">Documents Expiring</p>
                    <p className="text-xs text-muted-foreground">Within 30 days</p>
                  </div>
                </div>
                <Badge variant="destructive">{data.expiringDocs}</Badge>
              </Link>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
