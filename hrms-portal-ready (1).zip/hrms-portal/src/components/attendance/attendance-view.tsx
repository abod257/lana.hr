"use client";

import * as React from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Clock, LogIn, LogOut, MapPin, Timer, AlertTriangle } from "lucide-react";
import { toast } from "sonner";
import type { AuthUser } from "@/lib/auth";
import { format } from "date-fns";

export function AttendanceView({ user }: { user: AuthUser }) {
  const [today, setToday] = React.useState<any>(null);
  const [loading, setLoading] = React.useState(true);
  const [now, setNow] = React.useState(new Date());
  const [checkingIn, setCheckingIn] = React.useState(false);
  const [checkingOut, setCheckingOut] = React.useState(false);

  React.useEffect(() => {
    const interval = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(interval);
  }, []);

  const fetchToday = React.useCallback(async () => {
    setLoading(true);
    try {
      const today = new Date().toISOString().split("T")[0];
      const res = await fetch(`/api/attendance?employeeId=${user.employee?.id}&startDate=${today}&endDate=${today}`);
      const data = await res.json();
      if (data.success && data.data?.[0]) {
        setToday(data.data[0]);
      } else {
        setToday(null);
      }
    } catch {
      setToday(null);
    } finally {
      setLoading(false);
    }
  }, [user.employee?.id]);

  React.useEffect(() => {
    fetchToday();
  }, [fetchToday]);

  const handleCheckIn = async () => {
    setCheckingIn(true);
    try {
      const res = await fetch("/api/attendance/check-in", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ location: "Office" }),
      });
      const data = await res.json();
      if (data.success) {
        toast.success(data.message || "Checked in successfully");
        fetchToday();
      } else {
        toast.error(data.message || "Check-in failed");
      }
    } catch {
      toast.error("Network error");
    } finally {
      setCheckingIn(false);
    }
  };

  const handleCheckOut = async () => {
    setCheckingOut(true);
    try {
      const res = await fetch("/api/attendance/check-out", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ location: "Office" }),
      });
      const data = await res.json();
      if (data.success) {
        toast.success(data.message || "Checked out successfully");
        fetchToday();
      } else {
        toast.error(data.message || "Check-out failed");
      }
    } catch {
      toast.error("Network error");
    } finally {
      setCheckingOut(false);
    }
  };

  const workedSeconds = today?.checkIn && !today?.checkOut
    ? Math.floor((now.getTime() - new Date(today.checkIn).getTime()) / 1000)
    : 0;

  const workedDisplay = today?.workedHours
    ? `${today.workedHours} hrs`
    : `${Math.floor(workedSeconds / 3600)}h ${Math.floor((workedSeconds % 3600) / 60)}m`;

  return (
    <div className="space-y-6">
      {/* Clock Card */}
      <Card className="overflow-hidden">
        <div className="bg-gradient-to-br from-primary via-primary to-accent-foreground p-8 text-white">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
              <p className="text-white/80 text-sm mb-1">Current Time</p>
              <p className="text-5xl font-bold font-mono tracking-tight">
                {format(now, "HH:mm:ss")}
              </p>
              <p className="text-white/80 text-sm mt-2">
                {format(now, "EEEE, MMMM d, yyyy")}
              </p>
            </div>

            <div className="flex flex-col items-center gap-3">
              {!today?.checkIn ? (
                <Button
                  size="xl"
                  variant="glass"
                  onClick={handleCheckIn}
                  loading={checkingIn}
                  className="text-white border-white/30 hover:bg-white/20"
                >
                  <LogIn className="me-2 h-5 w-5" />
                  Check In
                </Button>
              ) : !today?.checkOut ? (
                <>
                  <Button
                    size="xl"
                    variant="glass"
                    onClick={handleCheckOut}
                    loading={checkingOut}
                    className="text-white border-white/30 hover:bg-white/20"
                  >
                    <LogOut className="me-2 h-5 w-5" />
                    Check Out
                  </Button>
                  <p className="text-sm text-white/80 flex items-center gap-2">
                    <Timer className="h-4 w-4" />
                    Working: {workedDisplay}
                  </p>
                </>
              ) : (
                <div className="text-center">
                  <Badge variant="success" className="text-base px-4 py-2">
                    ✓ Day Complete
                  </Badge>
                  <p className="text-sm text-white/80 mt-2">Total: {workedDisplay}</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </Card>

      {/* Status Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-5">
            <p className="text-sm text-muted-foreground">Status</p>
            <div className="mt-2">
              {today ? (
                <Badge variant={today.status === "LATE" ? "warning" : "success"} className="text-base">
                  {today.status}
                </Badge>
              ) : (
                <Badge variant="secondary" className="text-base">Not Checked In</Badge>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-5">
            <p className="text-sm text-muted-foreground">Check In</p>
            <p className="text-xl font-bold mt-2">
              {today?.checkIn ? format(new Date(today.checkIn), "HH:mm") : "—"}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-5">
            <p className="text-sm text-muted-foreground">Check Out</p>
            <p className="text-xl font-bold mt-2">
              {today?.checkOut ? format(new Date(today.checkOut), "HH:mm") : "—"}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-5">
            <p className="text-sm text-muted-foreground">Late By</p>
            <p className="text-xl font-bold mt-2 text-warning">
              {today?.lateMinutes ? `${today.lateMinutes}m` : "—"}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Notes/Info */}
      {today?.notes && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Today's Notes</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm">{today.notes}</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
