import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth, hasPermission } from "@/lib/auth";
import { ApiResponse, handleApiError } from "@/lib/api-response";
import { createAuditLog, getClientInfo } from "@/lib/audit";
import { documentSchema } from "@/lib/validations";

export async function GET(request: NextRequest) {
  try {
    const user = await requireAuth();
    const { searchParams } = new URL(request.url);
    const employeeId = searchParams.get("employeeId");
    const documentType = searchParams.get("documentType");

    const where: any = {};
    if (employeeId) where.employeeId = employeeId;
    if (documentType) where.documentType = documentType;

    // Role-based filter
    if (!hasPermission(user, "documents.view_all")) {
      if (user.employee) {
        where.employeeId = user.employee.id;
      }
    }

    const documents = await prisma.employeeDocument.findMany({
      where,
      include: {
        employee: { select: { id: true, firstNameEn: true, lastNameEn: true, firstNameAr: true, lastNameAr: true, employeeCode: true } },
      },
      orderBy: { createdAt: "desc" },
    });

    return ApiResponse.success(documents);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await requireAuth();
    if (!hasPermission(user, "documents.upload")) {
      return ApiResponse.forbidden();
    }

    const body = await request.json();
    const validated = documentSchema.parse(body);
    const { ipAddress, userAgent } = getClientInfo(request);

    const document = await prisma.employeeDocument.create({
      data: {
        ...validated,
        issueDate: validated.issueDate ? new Date(validated.issueDate) : null,
        expiryDate: validated.expiryDate ? new Date(validated.expiryDate) : null,
        uploadedById: user.id,
        status: "ACTIVE",
      },
    });

    await createAuditLog({
      userId: user.id,
      action: "UPLOAD_DOCUMENT",
      resource: "EmployeeDocument",
      resourceId: document.id,
      description: `Uploaded document: ${validated.titleEn}`,
      ipAddress,
      userAgent,
    });

    return ApiResponse.created(document, "Document uploaded successfully");
  } catch (error) {
    return handleApiError(error);
  }
}
