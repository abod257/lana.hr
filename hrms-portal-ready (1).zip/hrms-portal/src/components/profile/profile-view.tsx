"use client";

import * as React from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Mail, Phone, MapPin, Building2, Briefcase, Calendar, DollarSign, FileText, Lock, Save } from "lucide-react";
import { toast } from "sonner";
import type { AuthUser } from "@/lib/auth";
import { getInitials } from "@/lib/utils";

export function ProfileView({ user }: { user: AuthUser }) {
  const [saving, setSaving] = React.useState(false);
  const [passwordSaving, setPasswordSaving] = React.useState(false);
  const [passwordForm, setPasswordForm] = React.useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });

  const handleChangePassword = async () => {
    if (passwordForm.newPassword !== passwordForm.confirmPassword) {
      toast.error("Passwords don't match");
      return;
    }
    if (passwordForm.newPassword.length < 8) {
      toast.error("Password must be at least 8 characters");
      return;
    }

    setPasswordSaving(true);
    try {
      const res = await fetch("/api/auth/change-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(passwordForm),
      });
      const data = await res.json();
      if (data.success) {
        toast.success("Password changed successfully");
        setPasswordForm({ currentPassword: "", newPassword: "", confirmPassword: "" });
      } else {
        toast.error(data.message || "Failed");
      }
    } catch {
      toast.error("Error");
    } finally {
      setPasswordSaving(false);
    }
  };

  const fullName = `${user.employee?.firstNameEn || ""} ${user.employee?.lastNameEn || ""}`.trim() || user.email;
  const initials = user.employee ? getInitials(user.employee.firstNameEn, user.employee.lastNameEn) : user.email.substring(0, 2).toUpperCase();

  return (
    <div className="space-y-6">
      {/* Profile Header */}
      <Card className="overflow-hidden">
        <div className="h-32 bg-gradient-to-br from-primary via-primary to-accent-foreground" />
        <CardContent className="p-6 -mt-12">
          <div className="flex flex-col md:flex-row items-start md:items-end gap-4">
            <Avatar className="h-24 w-24 border-4 border-background shadow-lg">
              <AvatarImage src={user.employee?.profilePicture || undefined} />
              <AvatarFallback className="text-2xl">{initials}</AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <h2 className="text-2xl font-bold">{fullName}</h2>
              <p className="text-muted-foreground">{user.email}</p>
              <div className="flex items-center gap-2 mt-2">
                <Badge variant="secondary">{user.role.displayNameEn}</Badge>
                <Badge variant="success">{user.status}</Badge>
              </div>
            </div>
            <Button variant="outline" className="gap-2">
              <Save className="h-4 w-4" />
              Save Changes
            </Button>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="personal">
        <TabsList>
          <TabsTrigger value="personal">Personal Info</TabsTrigger>
          <TabsTrigger value="employment">Employment</TabsTrigger>
          <TabsTrigger value="security">Security</TabsTrigger>
        </TabsList>

        <TabsContent value="personal">
          <Card>
            <CardHeader>
              <CardTitle>Personal Information</CardTitle>
              <CardDescription>Your personal details</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label>First Name (English)</Label>
                  <Input defaultValue={user.employee?.firstNameEn} />
                </div>
                <div>
                  <Label>Last Name (English)</Label>
                  <Input defaultValue={user.employee?.lastNameEn} />
                </div>
                <div>
                  <Label>First Name (Arabic)</Label>
                  <Input defaultValue={user.employee?.firstNameAr} dir="rtl" />
                </div>
                <div>
                  <Label>Last Name (Arabic)</Label>
                  <Input defaultValue={user.employee?.lastNameAr} dir="rtl" />
                </div>
                <div>
                  <Label>Email</Label>
                  <Input defaultValue={user.email} type="email" startIcon={<Mail className="h-4 w-4" />} disabled />
                </div>
                <div>
                  <Label>Phone</Label>
                  <Input startIcon={<Phone className="h-4 w-4" />} placeholder="+966 5X XXX XXXX" />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="employment">
          <Card>
            <CardHeader>
              <CardTitle>Employment Information</CardTitle>
              <CardDescription>Your job and salary details</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label>Employee Code</Label>
                  <Input defaultValue={user.employee?.employeeCode} disabled />
                </div>
                <div>
                  <Label>Department</Label>
                  <Input value="—" disabled />
                </div>
                <div>
                  <Label>Position</Label>
                  <Input value="—" disabled />
                </div>
                <div>
                  <Label>Contract Type</Label>
                  <Input value="Permanent" disabled />
                </div>
                <div>
                  <Label>Hire Date</Label>
                  <Input type="date" disabled />
                </div>
                <div>
                  <Label>Status</Label>
                  <Input value="Active" disabled />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="security">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lock className="h-5 w-5" />
                Change Password
              </CardTitle>
              <CardDescription>Update your account password</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 max-w-md">
              <div>
                <Label>Current Password</Label>
                <Input
                  type="password"
                  value={passwordForm.currentPassword}
                  onChange={(e) => setPasswordForm({ ...passwordForm, currentPassword: e.target.value })}
                />
              </div>
              <div>
                <Label>New Password</Label>
                <Input
                  type="password"
                  value={passwordForm.newPassword}
                  onChange={(e) => setPasswordForm({ ...passwordForm, newPassword: e.target.value })}
                />
                <p className="text-xs text-muted-foreground mt-1">
                  Must be 8+ chars with uppercase, lowercase, number, and special character.
                </p>
              </div>
              <div>
                <Label>Confirm New Password</Label>
                <Input
                  type="password"
                  value={passwordForm.confirmPassword}
                  onChange={(e) => setPasswordForm({ ...passwordForm, confirmPassword: e.target.value })}
                />
              </div>
              <Button onClick={handleChangePassword} loading={passwordSaving}>
                Update Password
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
