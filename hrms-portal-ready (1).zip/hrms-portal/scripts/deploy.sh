#!/bin/bash

# =====================================================
# HRMS Portal - Production Deployment Script
# =====================================================

set -e

echo "🚀 Starting HRMS Portal deployment..."

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m'

# Check prerequisites
echo -e "${BLUE}📋 Checking prerequisites...${NC}"
command -v node >/dev/null 2>&1 || { echo -e "${RED}❌ Node.js is required${NC}"; exit 1; }
command -v npm >/dev/null 2>&1 || { echo -e "${RED}❌ npm is required${NC}"; exit 1; }

NODE_VERSION=$(node -v | sed 's/v//')
REQUIRED_VERSION="20.0.0"

if [ "$(printf '%s\n' "$REQUIRED_VERSION" "$NODE_VERSION" | sort -V | head -n1)" != "$REQUIRED_VERSION" ]; then
  echo -e "${RED}❌ Node.js v20+ required (you have v$NODE_VERSION)${NC}"
  exit 1
fi

echo -e "${GREEN}✓ Node.js v$NODE_VERSION${NC}"

# Install dependencies
echo -e "${BLUE}📦 Installing dependencies...${NC}"
npm ci --include=dev

# Generate Prisma client
echo -e "${BLUE}🔧 Generating Prisma client...${NC}"
npx prisma generate

# Run type check
echo -e "${BLUE}🔍 Running type check...${NC}"
npm run type-check || { echo -e "${RED}❌ Type check failed${NC}"; exit 1; }

# Build
echo -e "${BLUE}🏗️  Building application...${NC}"
npm run build

echo -e "${GREEN}✅ Build complete!${NC}"

# Run database migrations
if [ -n "$DATABASE_URL" ]; then
  echo -e "${BLUE}🗄️  Running database migrations...${NC}"
  npx prisma migrate deploy || echo -e "${RED}⚠️  Migration failed (database may not be ready)${NC}"
fi

echo -e "${GREEN}✅ Deployment complete!${NC}"
echo ""
echo "Next steps:"
echo "  - npm start    # Start the production server"
echo "  - pm2 start    # Or use PM2 for process management"
echo "  - docker-compose up -d    # Or use Docker"
