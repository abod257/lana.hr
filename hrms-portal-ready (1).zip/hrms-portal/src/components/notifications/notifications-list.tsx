"use client";

import * as React from "react";
import Link from "next/link";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Bell, CheckCheck, Calendar, FileText, DollarSign, UserPlus, AlertCircle } from "lucide-react";
import { toast } from "sonner";
import { getRelativeTime } from "@/lib/utils";

export function NotificationsList() {
  const [notifications, setNotifications] = React.useState<any[]>([]);
  const [loading, setLoading] = React.useState(true);

  const fetchNotifications = React.useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/notifications");
      const data = await res.json();
      if (data.success) {
        setNotifications(data.data || []);
      }
    } catch {} finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    fetchNotifications();
  }, [fetchNotifications]);

  const markAllRead = async () => {
    try {
      await fetch("/api/notifications", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ markAllRead: true }),
      });
      toast.success("All notifications marked as read");
      fetchNotifications();
    } catch {
      toast.error("Failed");
    }
  };

  const getIcon = (type: string) => {
    if (type.includes("LEAVE")) return Calendar;
    if (type.includes("PAYROLL")) return DollarSign;
    if (type.includes("DOCUMENT") || type.includes("CONTRACT") || type.includes("IQAMA") || type.includes("PASSPORT")) return FileText;
    if (type.includes("RECRUITMENT")) return UserPlus;
    if (type.includes("ANNOUNCEMENT")) return Bell;
    return AlertCircle;
  };

  const getColor = (priority: string) => {
    switch (priority) {
      case "URGENT": return "text-red-600";
      case "HIGH": return "text-orange-600";
      default: return "text-blue-600";
    }
  };

  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="text-sm text-muted-foreground">
            {notifications.filter(n => !n.isRead).length} unread of {notifications.length} total
          </div>
          <Button variant="outline" size="sm" onClick={markAllRead} className="gap-2">
            <CheckCheck className="h-4 w-4" />
            Mark all as read
          </Button>
        </div>

        {loading ? (
          <div className="text-center py-12">Loading...</div>
        ) : notifications.length === 0 ? (
          <div className="text-center py-12">
            <Bell className="h-12 w-12 mx-auto text-muted-foreground/50 mb-3" />
            <p className="text-muted-foreground">No notifications</p>
          </div>
        ) : (
          <div className="space-y-2">
            {notifications.map((n) => {
              const Icon = getIcon(n.type);
              return (
                <Link
                  key={n.id}
                  href={n.link || "#"}
                  className={`flex items-start gap-3 p-4 rounded-lg border transition-colors ${
                    n.isRead ? "bg-background" : "bg-accent/30 border-primary/30"
                  } hover:bg-accent`}
                >
                  <div className={`h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center ${getColor(n.priority)}`}>
                    <Icon className="h-5 w-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className={`text-sm ${!n.isRead ? "font-bold" : "font-medium"}`}>{n.titleEn}</h4>
                      {!n.isRead && <div className="h-2 w-2 rounded-full bg-primary animate-pulse" />}
                      {n.priority === "URGENT" && <Badge variant="destructive">Urgent</Badge>}
                      {n.priority === "HIGH" && <Badge variant="warning">High</Badge>}
                    </div>
                    <p className="text-sm text-muted-foreground">{n.messageEn}</p>
                    <p className="text-xs text-muted-foreground mt-1">{getRelativeTime(n.createdAt, "en")}</p>
                  </div>
                </Link>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
