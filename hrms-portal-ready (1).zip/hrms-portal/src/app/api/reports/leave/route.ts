import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth, hasPermission } from "@/lib/auth";
import { ApiResponse, handleApiError } from "@/lib/api-response";

export async function GET(request: NextRequest) {
  try {
    const user = await requireAuth();
    if (!hasPermission(user, "reports.view")) {
      return ApiResponse.forbidden();
    }

    const year = parseInt(new URL(request.url).searchParams.get("year") || new Date().getFullYear().toString());
    const startOfYear = new Date(year, 0, 1);
    const endOfYear = new Date(year, 11, 31);

    const leaves = await prisma.leaveRequest.findMany({
      where: {
        createdAt: { gte: startOfYear, lte: endOfYear },
      },
      select: {
        leaveType: true,
        status: true,
        days: true,
        startDate: true,
        endDate: true,
      },
    });

    const byType = leaves.reduce((acc: any, l) => {
      acc[l.leaveType] = (acc[l.leaveType] || 0) + l.days;
      return acc;
    }, {});

    const byStatus = leaves.reduce((acc: any, l) => {
      acc[l.status] = (acc[l.status] || 0) + 1;
      return acc;
    }, {});

    return ApiResponse.success({
      year,
      total: leaves.length,
      totalDays: leaves.reduce((s, l) => s + l.days, 0),
      byType,
      byStatus,
    });
  } catch (error) {
    return handleApiError(error);
  }
}
