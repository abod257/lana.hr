import { NextResponse } from "next/server";
import { getSession } from "@/lib/auth";
import { ApiResponse, handleApiError } from "@/lib/api-response";

export async function GET() {
  try {
    const user = await getSession();
    if (!user) {
      return ApiResponse.unauthorized();
    }
    return ApiResponse.success(user);
  } catch (error) {
    return handleApiError(error);
  }
}
