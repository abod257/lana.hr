import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth, hasPermission } from "@/lib/auth";
import { ApiResponse, handleApiError } from "@/lib/api-response";
import { createAuditLog, getClientInfo } from "@/lib/audit";

export async function GET(request: NextRequest) {
  try {
    await requireAuth();
    const { searchParams } = new URL(request.url);
    const category = searchParams.get("category");

    const where: any = {};
    if (category) where.category = category;

    const settings = await prisma.setting.findMany({
      where,
      orderBy: { key: "asc" },
    });

    const company = await prisma.company.findFirst();

    return ApiResponse.success({ settings, company });
  } catch (error) {
    return handleApiError(error);
  }
}

export async function PUT(request: NextRequest) {
  try {
    const user = await requireAuth();
    if (!hasPermission(user, "settings.manage")) {
      return ApiResponse.forbidden();
    }

    const body = await request.json();
    const { ipAddress, userAgent } = getClientInfo(request);

    if (body.company) {
      await prisma.company.upsert({
        where: { id: body.company.id || "default" },
        create: { ...body.company },
        update: body.company,
      });
    }

    if (body.settings && Array.isArray(body.settings)) {
      for (const setting of body.settings) {
        await prisma.setting.upsert({
          where: { key: setting.key },
          create: {
            key: setting.key,
            value: setting.value,
            category: setting.category || "GENERAL",
            description: setting.description,
            isPublic: setting.isPublic || false,
            dataType: setting.dataType || "STRING",
          },
          update: {
            value: setting.value,
            description: setting.description,
          },
        });
      }
    }

    await createAuditLog({
      userId: user.id,
      action: "UPDATE",
      resource: "Settings",
      description: "Settings updated",
      ipAddress,
      userAgent,
    });

    return ApiResponse.success({ message: "Settings updated successfully" });
  } catch (error) {
    return handleApiError(error);
  }
}
