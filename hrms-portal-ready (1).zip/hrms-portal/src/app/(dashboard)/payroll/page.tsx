import { Suspense } from "react";
import { getSession } from "@/lib/auth";
import { redirect } from "next/navigation";
import { PayrollView } from "@/components/payroll/payroll-view";

export default async function PayrollPage() {
  const user = await getSession();
  if (!user) redirect("/login");

  return (
    <div className="space-y-6 animate-fade-in-up">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Payroll</h1>
        <p className="text-muted-foreground mt-1">Manage payroll processing and payslips</p>
      </div>
      <Suspense fallback={<div>Loading...</div>}>
        <PayrollView />
      </Suspense>
    </div>
  );
}
