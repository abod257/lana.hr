import { NextResponse } from "next/server";
import { logout } from "@/lib/auth";
import { ApiResponse, handleApiError } from "@/lib/api-response";

export async function POST() {
  try {
    await logout();
    return ApiResponse.success({ message: "Logged out successfully" });
  } catch (error) {
    return handleApiError(error);
  }
}
