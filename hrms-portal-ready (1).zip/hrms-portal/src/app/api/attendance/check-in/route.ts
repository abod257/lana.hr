import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth } from "@/lib/auth";
import { ApiResponse, handleApiError } from "@/lib/api-response";
import { createAuditLog, getClientInfo } from "@/lib/audit";
import { checkInSchema } from "@/lib/validations";

export async function POST(request: NextRequest) {
  try {
    const user = await requireAuth();
    if (!user.employee) {
      return ApiResponse.badRequest("User is not linked to an employee record");
    }

    const body = await request.json().catch(() => ({}));
    const validated = checkInSchema.parse(body);
    const { ipAddress, userAgent } = getClientInfo(request);

    const today = startOfDay(new Date());
    const now = new Date();

    // Check if already checked in today
    const existing = await prisma.attendance.findUnique({
      where: {
        employeeId_date: {
          employeeId: user.employee.id,
          date: today,
        },
      },
    });

    if (existing?.checkIn) {
      return ApiResponse.badRequest("Already checked in today");
    }

    // Calculate if late (assuming 9:00 AM start)
    const startTime = new Date(today);
    startTime.setHours(9, 0, 0, 0);
    const lateMinutes = Math.max(0, differenceInMinutes(now, startTime));
    const isLate = lateMinutes > 0;

    const attendance = await prisma.attendance.upsert({
      where: {
        employeeId_date: {
          employeeId: user.employee.id,
          date: today,
        },
      },
      create: {
        employeeId: user.employee.id,
        date: today,
        checkIn: now,
        status: isLate ? "LATE" : "PRESENT",
        lateMinutes,
        isLate,
        location: validated.location,
        notes: validated.notes,
        ipAddress,
      },
      update: {
        checkIn: now,
        status: isLate ? "LATE" : "PRESENT",
        lateMinutes,
        isLate,
        location: validated.location,
        notes: validated.notes,
        ipAddress,
      },
    });

    await createAuditLog({
      userId: user.id,
      action: "CHECK_IN",
      resource: "Attendance",
      resourceId: attendance.id,
      description: `Checked in at ${now.toISOString()}`,
      ipAddress,
      userAgent,
    });

    return ApiResponse.success({
      ...attendance,
      message: isLate ? `Checked in (Late by ${lateMinutes} minutes)` : "Checked in successfully",
    });
  } catch (error) {
    return handleApiError(error);
  }
}

function startOfDay(date: Date): Date {
  const d = new Date(date);
  d.setHours(0, 0, 0, 0);
  return d;
}

function differenceInMinutes(later: Date, earlier: Date): number {
  return Math.floor((later.getTime() - earlier.getTime()) / (1000 * 60));
}
