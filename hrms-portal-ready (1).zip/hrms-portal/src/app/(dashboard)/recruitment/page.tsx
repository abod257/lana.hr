import { Suspense } from "react";
import { getSession } from "@/lib/auth";
import { redirect } from "next/navigation";
import { RecruitmentView } from "@/components/recruitment/recruitment-view";

export default async function RecruitmentPage() {
  const user = await getSession();
  if (!user) redirect("/login");

  return (
    <div className="space-y-6 animate-fade-in-up">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Recruitment</h1>
        <p className="text-muted-foreground mt-1">Manage job openings and candidates</p>
      </div>
      <Suspense fallback={<div>Loading...</div>}>
        <RecruitmentView />
      </Suspense>
    </div>
  );
}
