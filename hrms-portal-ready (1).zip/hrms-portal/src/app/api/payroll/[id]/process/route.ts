import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth, hasPermission } from "@/lib/auth";
import { ApiResponse, handleApiError } from "@/lib/api-response";
import { createAuditLog, getClientInfo } from "@/lib/audit";
import { generateId } from "@/lib/utils";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await requireAuth();
    if (!hasPermission(user, "payroll.process")) {
      return ApiResponse.forbidden();
    }

    const { id } = await params;
    const body = await request.json().catch(() => ({}));
    const employeeIds: string[] | undefined = body.employeeIds;
    const { ipAddress, userAgent } = getClientInfo(request);

    const payroll = await prisma.payroll.findUnique({
      where: { id },
      include: { payslips: true },
    });
    if (!payroll) return ApiResponse.notFound();
    if (payroll.status !== "PROCESSING" && payroll.status !== "DRAFT") {
      return ApiResponse.badRequest(`Cannot process payroll with status ${payroll.status}`);
    }

    // Get employees to process
    const where: any = {
      deletedAt: null,
      status: "ACTIVE",
    };
    if (employeeIds && employeeIds.length > 0) {
      where.id = { in: employeeIds };
    }

    const employees = await prisma.employee.findMany({
      where,
      include: {
        attendances: {
          where: {
            date: { gte: payroll.startDate, lte: payroll.endDate },
          },
        },
        leaveRequests: {
          where: {
            status: "APPROVED",
            startDate: { lte: payroll.endDate },
            endDate: { gte: payroll.startDate },
          },
        },
        overtimeRequests: {
          where: {
            status: "APPROVED",
            date: { gte: payroll.startDate, lte: payroll.endDate },
          },
        },
      },
    });

    let totalEarnings = 0;
    let totalDeductions = 0;
    let totalNet = 0;

    // Create payslips
    for (const emp of employees) {
      const basicSalary = parseFloat(emp.basicSalary.toString());
      const housing = parseFloat((emp.housingAllowance || 0).toString());
      const transport = parseFloat((emp.transportAllowance || 0).toString());
      const other = parseFloat((emp.otherAllowances || 0).toString());

      // Calculate overtime
      const overtimeAmount = emp.overtimeRequests.reduce((sum, ot) => {
        return sum + parseFloat(ot.amount.toString());
      }, 0);

      const grossEarnings = basicSalary + housing + transport + other + overtimeAmount;

      // Calculate deductions (simplified)
      const absentDays = emp.attendances.filter((a) => a.status === "ABSENT").length;
      const lateMinutes = emp.attendances.reduce((sum, a) => sum + a.lateMinutes, 0);
      const absentDeduction = (basicSalary / 30) * absentDays;
      const lateDeduction = (basicSalary / 30 / 8 / 60) * lateMinutes;
      const insuranceDeduction = grossEarnings * 0.0975; // GOSI 9.75%

      const totalDeduct = absentDeduction + lateDeduction + insuranceDeduction;
      const netPay = grossEarnings - totalDeduct;

      totalEarnings += grossEarnings;
      totalDeductions += totalDeduct;
      totalNet += netPay;

      await prisma.payslip.create({
        data: {
          payslipNumber: generateId("PS"),
          payrollId: payroll.id,
          employeeId: emp.id,
          period: payroll.period,
          basicSalary,
          housingAllowance: housing,
          transportAllowance: transport,
          otherAllowances: other,
          overtimeAmount,
          totalEarnings: grossEarnings,
          absentDeduction,
          lateDeduction,
          insuranceDeduction,
          totalDeductions: totalDeduct,
          netPay,
          workedDays: emp.attendances.filter((a) => a.status === "PRESENT").length,
          absentDays,
          paidLeaveDays: emp.leaveRequests.filter((l) => ["ANNUAL", "SICK"].includes(l.leaveType)).length,
          unpaidLeaveDays: emp.leaveRequests.filter((l) => l.leaveType === "UNPAID").length,
          overtimeHours: emp.overtimeRequests.reduce((s, o) => s + parseFloat(o.hours.toString()), 0),
          status: "DRAFT",
        },
      });
    }

    // Update payroll totals
    await prisma.payroll.update({
      where: { id },
      data: {
        totalEmployees: employees.length,
        totalEarnings,
        totalDeductions,
        totalNetPay: totalNet,
        status: "PROCESSING",
      },
    });

    await createAuditLog({
      userId: user.id,
      action: "PROCESS_PAYROLL",
      resource: "Payroll",
      resourceId: id,
      description: `Processed payroll for ${employees.length} employees`,
      ipAddress,
      userAgent,
    });

    return ApiResponse.success({
      message: `Processed payroll for ${employees.length} employees`,
      totalEarnings,
      totalDeductions,
      totalNetPay: totalNet,
      employeeCount: employees.length,
    });
  } catch (error) {
    return handleApiError(error);
  }
}
