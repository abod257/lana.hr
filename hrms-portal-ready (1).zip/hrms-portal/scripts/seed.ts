// =====================================================
// HRMS Portal - Database Seeder
// Run: npm run db:seed
// =====================================================

import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  console.log("🌱 Starting database seeding...\n");

  // =====================================================
  // 1. Permissions
  // =====================================================
  console.log("📝 Seeding permissions...");
  const permissions = [
    { code: "employees.view", resource: "employees", action: "view" },
    { code: "employees.create", resource: "employees", action: "create" },
    { code: "employees.update", resource: "employees", action: "update" },
    { code: "employees.delete", resource: "employees", action: "delete" },
    { code: "employees.export", resource: "employees", action: "export" },
    { code: "departments.view", resource: "departments", action: "view" },
    { code: "departments.manage", resource: "departments", action: "manage" },
    { code: "positions.view", resource: "positions", action: "view" },
    { code: "positions.manage", resource: "positions", action: "manage" },
    { code: "attendance.view_own", resource: "attendance", action: "view_own" },
    { code: "attendance.view_team", resource: "attendance", action: "view_team" },
    { code: "attendance.view_all", resource: "attendance", action: "view_all" },
    { code: "attendance.manage", resource: "attendance", action: "manage" },
    { code: "attendance.check_in", resource: "attendance", action: "check_in" },
    { code: "leave.request", resource: "leave", action: "request" },
    { code: "leave.view_own", resource: "leave", action: "view_own" },
    { code: "leave.view_team", resource: "leave", action: "view_team" },
    { code: "leave.view_all", resource: "leave", action: "view_all" },
    { code: "leave.approve", resource: "leave", action: "approve" },
    { code: "leave.manage", resource: "leave", action: "manage" },
    { code: "payroll.view_own", resource: "payroll", action: "view_own" },
    { code: "payroll.view_all", resource: "payroll", action: "view_all" },
    { code: "payroll.process", resource: "payroll", action: "process" },
    { code: "payroll.approve", resource: "payroll", action: "approve" },
    { code: "payroll.export", resource: "payroll", action: "export" },
    { code: "payslips.view_own", resource: "payslips", action: "view_own" },
    { code: "recruitment.view", resource: "recruitment", action: "view" },
    { code: "recruitment.manage", resource: "recruitment", action: "manage" },
    { code: "recruitment.interview", resource: "recruitment", action: "interview" },
    { code: "documents.view_own", resource: "documents", action: "view_own" },
    { code: "documents.view_all", resource: "documents", action: "view_all" },
    { code: "documents.manage", resource: "documents", action: "manage" },
    { code: "documents.upload", resource: "documents", action: "upload" },
    { code: "notifications.view", resource: "notifications", action: "view" },
    { code: "notifications.manage", resource: "notifications", action: "manage" },
    { code: "reports.view", resource: "reports", action: "view" },
    { code: "reports.export", resource: "reports", action: "export" },
    { code: "settings.view", resource: "settings", action: "view" },
    { code: "settings.manage", resource: "settings", action: "manage" },
    { code: "audit.view", resource: "audit", action: "view" },
    { code: "profile.view_own", resource: "profile", action: "view_own" },
    { code: "profile.update_own", resource: "profile", action: "update_own" },
    { code: "loan.request", resource: "loan", action: "request" },
    { code: "expense.claim", resource: "expense", action: "claim" },
    { code: "overtime.request", resource: "overtime", action: "request" },
    { code: "salary_certificate.request", resource: "salary_certificate", action: "request" },
  ];

  for (const p of permissions) {
    await prisma.permission.upsert({
      where: { code: p.code },
      create: p,
      update: p,
    });
  }
  console.log(`   ✓ ${permissions.length} permissions created\n`);

  // =====================================================
  // 2. Roles
  // =====================================================
  console.log("👥 Seeding roles...");

  const allPermissions = await prisma.permission.findMany();
  const permMap = new Map(allPermissions.map((p) => [p.code, p]));

  const ROLE_PERMISSIONS: Record<string, string[]> = {
    EMPLOYEE: [
      "attendance.view_own", "attendance.check_in",
      "leave.request", "leave.view_own",
      "payroll.view_own", "payslips.view_own",
      "documents.view_own", "notifications.view",
      "profile.view_own", "profile.update_own",
      "loan.request", "expense.claim", "overtime.request", "salary_certificate.request",
    ],
    MANAGER: [
      "employees.view",
      "attendance.view_own", "attendance.view_team", "attendance.check_in",
      "leave.request", "leave.view_own", "leave.view_team", "leave.approve",
      "payroll.view_own", "payslips.view_own",
      "recruitment.view", "recruitment.interview",
      "documents.view_own", "documents.view_all",
      "notifications.view", "reports.view",
      "profile.view_own", "profile.update_own",
      "loan.request", "expense.claim", "overtime.request", "salary_certificate.request",
    ],
    HR_OFFICER: [
      "employees.view", "employees.create", "employees.update", "employees.export",
      "departments.view", "positions.view",
      "attendance.view_own", "attendance.view_all", "attendance.check_in", "attendance.manage",
      "leave.request", "leave.view_own", "leave.view_all", "leave.approve", "leave.manage",
      "payroll.view_own", "payslips.view_own",
      "recruitment.view", "recruitment.manage", "recruitment.interview",
      "documents.view_own", "documents.view_all", "documents.manage", "documents.upload",
      "notifications.view", "reports.view", "reports.export",
      "profile.view_own", "profile.update_own",
      "loan.request", "expense.claim", "overtime.request", "salary_certificate.request",
    ],
    PAYROLL_OFFICER: [
      "employees.view",
      "attendance.view_own", "attendance.view_all", "attendance.check_in",
      "leave.request", "leave.view_own", "leave.view_all",
      "payroll.view_own", "payroll.view_all", "payroll.process", "payroll.approve", "payroll.export",
      "payslips.view_own",
      "documents.view_own", "notifications.view",
      "reports.view", "reports.export",
      "profile.view_own", "profile.update_own",
      "loan.request", "expense.claim", "overtime.request", "salary_certificate.request",
    ],
    HR_MANAGER: [
      "employees.view", "employees.create", "employees.update", "employees.delete", "employees.export",
      "departments.view", "departments.manage",
      "positions.view", "positions.manage",
      "attendance.view_own", "attendance.view_team", "attendance.view_all", "attendance.check_in", "attendance.manage",
      "leave.request", "leave.view_own", "leave.view_team", "leave.view_all", "leave.approve", "leave.manage",
      "payroll.view_all", "payroll.approve", "payroll.export", "payslips.view_own",
      "recruitment.view", "recruitment.manage", "recruitment.interview",
      "documents.view_own", "documents.view_all", "documents.manage", "documents.upload",
      "notifications.view", "notifications.manage",
      "reports.view", "reports.export",
      "settings.view", "settings.manage", "audit.view",
      "profile.view_own", "profile.update_own",
      "loan.request", "expense.claim", "overtime.request", "salary_certificate.request",
    ],
    SYSTEM_ADMIN: allPermissions.map((p) => p.code),
  };

  const rolesConfig = [
    { name: "EMPLOYEE", displayNameAr: "موظف", displayNameEn: "Employee", level: 1 },
    { name: "MANAGER", displayNameAr: "مدير", displayNameEn: "Manager", level: 2 },
    { name: "HR_OFFICER", displayNameAr: "مسؤول موارد بشرية", displayNameEn: "HR Officer", level: 3 },
    { name: "PAYROLL_OFFICER", displayNameAr: "مسؤول رواتب", displayNameEn: "Payroll Officer", level: 3 },
    { name: "HR_MANAGER", displayNameAr: "مدير موارد بشرية", displayNameEn: "HR Manager", level: 4 },
    { name: "SYSTEM_ADMIN", displayNameAr: "مدير النظام", displayNameEn: "System Administrator", level: 5 },
  ];

  for (const role of rolesConfig) {
    const created = await prisma.role.upsert({
      where: { name: role.name },
      create: { ...role, isSystem: true },
      update: { ...role },
    });

    // Clear existing permissions and reassign
    await prisma.rolePermission.deleteMany({ where: { roleId: created.id } });

    const perms = ROLE_PERMISSIONS[role.name] || [];
    for (const code of perms) {
      const p = permMap.get(code);
      if (p) {
        await prisma.rolePermission.create({
          data: { roleId: created.id, permissionId: p.id },
        });
      }
    }
  }
  console.log(`   ✓ ${rolesConfig.length} roles created\n`);

  // =====================================================
  // 3. Departments
  // =====================================================
  console.log("🏢 Seeding departments...");
  const departments = [
    { code: "EXEC", nameAr: "الإدارة التنفيذية", nameEn: "Executive" },
    { code: "HR", nameAr: "الموارد البشرية", nameEn: "Human Resources" },
    { code: "FIN", nameAr: "المالية", nameEn: "Finance" },
    { code: "IT", nameAr: "تقنية المعلومات", nameEn: "Information Technology" },
    { code: "SALES", nameAr: "المبيعات", nameEn: "Sales" },
    { code: "MKT", nameAr: "التسويق", nameEn: "Marketing" },
    { code: "OPS", nameAr: "العمليات", nameEn: "Operations" },
    { code: "ENG", nameAr: "الهندسة", nameEn: "Engineering" },
    { code: "LEGAL", nameAr: "الشؤون القانونية", nameEn: "Legal" },
  ];

  for (const dept of departments) {
    await prisma.department.upsert({
      where: { code: dept.code },
      create: dept,
      update: dept,
    });
  }
  console.log(`   ✓ ${departments.length} departments created\n`);

  // =====================================================
  // 4. Positions
  // =====================================================
  console.log("💼 Seeding positions...");
  const allDepts = await prisma.department.findMany();
  const deptMap = new Map(allDepts.map((d) => [d.code, d]));

  const positions = [
    { code: "CEO", titleAr: "الرئيس التنفيذي", titleEn: "Chief Executive Officer", departmentId: deptMap.get("EXEC")!.id, level: 5 },
    { code: "HR-MGR", titleAr: "مدير الموارد البشرية", titleEn: "HR Manager", departmentId: deptMap.get("HR")!.id, level: 4 },
    { code: "HR-OFF", titleAr: "مسؤول موارد بشرية", titleEn: "HR Officer", departmentId: deptMap.get("HR")!.id, level: 3 },
    { code: "PAY-OFF", titleAr: "مسؤول الرواتب", titleEn: "Payroll Officer", departmentId: deptMap.get("FIN")!.id, level: 3 },
    { code: "FIN-MGR", titleAr: "مدير مالي", titleEn: "Finance Manager", departmentId: deptMap.get("FIN")!.id, level: 4 },
    { code: "ACC", titleAr: "محاسب", titleEn: "Accountant", departmentId: deptMap.get("FIN")!.id, level: 2 },
    { code: "IT-MGR", titleAr: "مدير تقنية المعلومات", titleEn: "IT Manager", departmentId: deptMap.get("IT")!.id, level: 4 },
    { code: "DEV-SR", titleAr: "مطور أول", titleEn: "Senior Developer", departmentId: deptMap.get("IT")!.id, level: 3 },
    { code: "DEV", titleAr: "مطور", titleEn: "Developer", departmentId: deptMap.get("IT")!.id, level: 2 },
    { code: "SALES-MGR", titleAr: "مدير المبيعات", titleEn: "Sales Manager", departmentId: deptMap.get("SALES")!.id, level: 4 },
    { code: "SALES-REP", titleAr: "مندوب مبيعات", titleEn: "Sales Representative", departmentId: deptMap.get("SALES")!.id, level: 2 },
    { code: "MKT-MGR", titleAr: "مدير التسويق", titleEn: "Marketing Manager", departmentId: deptMap.get("MKT")!.id, level: 4 },
    { code: "MKT-SPEC", titleAr: "أخصائي تسويق", titleEn: "Marketing Specialist", departmentId: deptMap.get("MKT")!.id, level: 2 },
    { code: "OPS-MGR", titleAr: "مدير العمليات", titleEn: "Operations Manager", departmentId: deptMap.get("OPS")!.id, level: 4 },
    { code: "OPS-SPEC", titleAr: "أخصائي عمليات", titleEn: "Operations Specialist", departmentId: deptMap.get("OPS")!.id, level: 2 },
    { code: "ENG-MGR", titleAr: "مدير هندسي", titleEn: "Engineering Manager", departmentId: deptMap.get("ENG")!.id, level: 4 },
    { code: "ENG", titleAr: "مهندس", titleEn: "Engineer", departmentId: deptMap.get("ENG")!.id, level: 2 },
  ];

  for (const pos of positions) {
    await prisma.position.upsert({
      where: { code: pos.code },
      create: pos,
      update: pos,
    });
  }
  console.log(`   ✓ ${positions.length} positions created\n`);

  // =====================================================
  // 5. Company
  // =====================================================
  console.log("🏛️  Seeding company info...");
  await prisma.company.upsert({
    where: { id: "default" },
    create: {
      id: "default",
      nameAr: "شركة المثال",
      nameEn: "Example Company",
      legalName: "Example Company Ltd.",
      taxNumber: "300000000000003",
      crNumber: "1010101010",
      address: "King Fahd Road, Riyadh",
      city: "Riyadh",
      country: "Saudi Arabia",
      phone: "+966 11 000 0000",
      email: "info@example.com",
      website: "https://example.com",
      currency: "SAR",
      timezone: "Asia/Riyadh",
    },
    update: {},
  });
  console.log(`   ✓ Company created\n`);

  // =====================================================
  // 6. Admin User
  // =====================================================
  console.log("👤 Seeding admin user...");
  const adminEmail = process.env.DEFAULT_ADMIN_EMAIL || "admin@company.com";
  const adminPassword = process.env.DEFAULT_ADMIN_PASSWORD || "Admin@123456";
  const adminRole = await prisma.role.findUnique({ where: { name: "SYSTEM_ADMIN" } });
  const itDept = deptMap.get("IT")!;
  const sysAdminPos = await prisma.position.findUnique({ where: { code: "IT-MGR" } });

  const passwordHash = await bcrypt.hash(adminPassword, 12);

  await prisma.user.upsert({
    where: { email: adminEmail.toLowerCase() },
    create: {
      email: adminEmail.toLowerCase(),
      passwordHash,
      roleId: adminRole!.id,
      status: "ACTIVE",
      emailVerified: true,
    },
    update: {},
  });

  const adminUser = await prisma.user.findUnique({ where: { email: adminEmail.toLowerCase() } });

  // Create admin employee profile
  await prisma.employee.upsert({
    where: { userId: adminUser!.id },
    create: {
      userId: adminUser!.id,
      employeeCode: "EMP-001",
      firstNameAr: "مدير",
      lastNameAr: "النظام",
      firstNameEn: "System",
      lastNameEn: "Administrator",
      email: adminEmail.toLowerCase(),
      gender: "MALE",
      maritalStatus: "MARRIED",
      nationality: "Saudi Arabia",
      departmentId: itDept.id,
      positionId: sysAdminPos!.id,
      hireDate: new Date("2020-01-01"),
      contractType: "PERMANENT",
      status: "ACTIVE",
      basicSalary: 25000,
      housingAllowance: 10000,
      transportAllowance: 2000,
    },
    update: {},
  });

  console.log(`   ✓ Admin user created: ${adminEmail} / ${adminPassword}\n`);

  // =====================================================
  // 7. Demo Employees
  // =====================================================
  console.log("👥 Seeding demo employees...");
  const demoEmployees = [
    {
      employeeCode: "EMP-002",
      email: "ahmed.mohammed@company.com",
      firstNameAr: "أحمد",
      lastNameAr: "محمد",
      firstNameEn: "Ahmed",
      lastNameEn: "Mohammed",
      gender: "MALE",
      nationality: "Saudi Arabia",
      departmentCode: "HR",
      positionCode: "HR-MGR",
      basicSalary: 18000,
      housingAllowance: 7500,
      transportAllowance: 1500,
      roleName: "HR_MANAGER",
    },
    {
      employeeCode: "EMP-003",
      email: "fatima.ali@company.com",
      firstNameAr: "فاطمة",
      lastNameAr: "علي",
      firstNameEn: "Fatima",
      lastNameEn: "Ali",
      gender: "FEMALE",
      nationality: "Saudi Arabia",
      departmentCode: "HR",
      positionCode: "HR-OFF",
      basicSalary: 12000,
      housingAllowance: 5000,
      transportAllowance: 1000,
      roleName: "HR_OFFICER",
    },
    {
      employeeCode: "EMP-004",
      email: "khalid.saeed@company.com",
      firstNameAr: "خالد",
      lastNameAr: "سعيد",
      firstNameEn: "Khalid",
      lastNameEn: "Saeed",
      gender: "MALE",
      nationality: "Saudi Arabia",
      departmentCode: "FIN",
      positionCode: "PAY-OFF",
      basicSalary: 14000,
      housingAllowance: 6000,
      transportAllowance: 1200,
      roleName: "PAYROLL_OFFICER",
    },
    {
      employeeCode: "EMP-005",
      email: "mohammed.ahmed@company.com",
      firstNameAr: "محمد",
      lastNameAr: "أحمد",
      firstNameEn: "Mohammed",
      lastNameEn: "Ahmed",
      gender: "MALE",
      nationality: "Egypt",
      departmentCode: "IT",
      positionCode: "DEV-SR",
      basicSalary: 15000,
      housingAllowance: 6500,
      transportAllowance: 1200,
      roleName: "EMPLOYEE",
    },
    {
      employeeCode: "EMP-006",
      email: "sara.hassan@company.com",
      firstNameAr: "سارة",
      lastNameAr: "حسن",
      firstNameEn: "Sara",
      lastNameEn: "Hassan",
      gender: "FEMALE",
      nationality: "Saudi Arabia",
      departmentCode: "MKT",
      positionCode: "MKT-SPEC",
      basicSalary: 11000,
      housingAllowance: 4500,
      transportAllowance: 900,
      roleName: "EMPLOYEE",
    },
  ];

  const positionMap = new Map(
    (await prisma.position.findMany()).map((p) => [p.code, p])
  );

  for (const emp of demoEmployees) {
    const role = await prisma.role.findUnique({ where: { name: emp.roleName } });
    const user = await prisma.user.upsert({
      where: { email: emp.email.toLowerCase() },
      create: {
        email: emp.email.toLowerCase(),
        passwordHash: await bcrypt.hash("Demo@123456", 12),
        roleId: role!.id,
        status: "ACTIVE",
        emailVerified: true,
      },
      update: {},
    });

    await prisma.employee.upsert({
      where: { userId: user.id },
      create: {
        userId: user.id,
        employeeCode: emp.employeeCode,
        email: emp.email.toLowerCase(),
        firstNameAr: emp.firstNameAr,
        lastNameAr: emp.lastNameAr,
        firstNameEn: emp.firstNameEn,
        lastNameEn: emp.lastNameEn,
        gender: emp.gender as any,
        nationality: emp.nationality,
        departmentId: deptMap.get(emp.departmentCode)!.id,
        positionId: positionMap.get(emp.positionCode)!.id,
        hireDate: new Date("2022-01-15"),
        contractType: "PERMANENT",
        status: "ACTIVE",
        basicSalary: emp.basicSalary,
        housingAllowance: emp.housingAllowance,
        transportAllowance: emp.transportAllowance,
      },
      update: {},
    });
  }
  console.log(`   ✓ ${demoEmployees.length} demo employees created (password: Demo@123456)\n`);

  // =====================================================
  // 8. Salary Components
  // =====================================================
  console.log("💰 Seeding salary components...");
  const salaryComponents = [
    { nameAr: "الراتب الأساسي", nameEn: "Basic Salary", code: "BASIC", type: "EARNING", category: "BASIC", calculationType: "FIXED", defaultValue: 10000, isFixed: true },
    { nameAr: "بدل السكن", nameEn: "Housing Allowance", code: "HOUSING", type: "EARNING", category: "ALLOWANCE", calculationType: "PERCENTAGE", percentage: 25, isFixed: true },
    { nameAr: "بدل النقل", nameEn: "Transport Allowance", code: "TRANSPORT", type: "EARNING", category: "ALLOWANCE", calculationType: "FIXED", defaultValue: 1000, isFixed: true },
    { nameAr: "العمل الإضافي", nameEn: "Overtime", code: "OVERTIME", type: "EARNING", category: "OVERTIME", calculationType: "FORMULA", formula: "hours * hourly_rate * 1.5", isFixed: false },
    { nameAr: "تأمينات اجتماعية", nameEn: "GOSI Insurance", code: "GOSI", type: "DEDUCTION", category: "INSURANCE", calculationType: "PERCENTAGE", percentage: 9.75 },
    { nameAr: "خصم تأخير", nameEn: "Late Deduction", code: "LATE", type: "DEDUCTION", category: "OTHER", calculationType: "FORMULA" },
    { nameAr: "سلفة", nameEn: "Loan", code: "LOAN", type: "DEDUCTION", category: "LOAN", calculationType: "FIXED" },
  ];

  for (const sc of salaryComponents) {
    await prisma.salaryComponent.upsert({
      where: { code: sc.code },
      create: sc as any,
      update: sc as any,
    });
  }
  console.log(`   ✓ ${salaryComponents.length} salary components created\n`);

  // =====================================================
  // 9. Settings
  // =====================================================
  console.log("⚙️  Seeding settings...");
  const settings = [
    { key: "company.name", value: { ar: "شركة المثال", en: "Example Company" }, category: "GENERAL", isPublic: true },
    { key: "company.working_days", value: { days: [0, 1, 2, 3, 4] }, category: "GENERAL", isPublic: true },
    { key: "leave.annual_quota", value: { days: 21 }, category: "LEAVE", isPublic: true },
    { key: "leave.sick_quota", value: { days: 30 }, category: "LEAVE", isPublic: true },
    { key: "attendance.work_start", value: { time: "09:00" }, category: "ATTENDANCE", isPublic: true },
    { key: "attendance.work_end", value: { time: "17:00" }, category: "ATTENDANCE", isPublic: true },
    { key: "attendance.grace_minutes", value: { minutes: 15 }, category: "ATTENDANCE", isPublic: true },
    { key: "payroll.gosi_percentage", value: { percentage: 9.75 }, category: "PAYROLL", isPublic: false },
    { key: "notifications.email_enabled", value: { enabled: true }, category: "NOTIFICATIONS", isPublic: false },
  ];

  for (const setting of settings) {
    await prisma.setting.upsert({
      where: { key: setting.key },
      create: setting as any,
      update: setting as any,
    });
  }
  console.log(`   ✓ ${settings.length} settings created\n`);

  // =====================================================
  // 10. Holidays
  // =====================================================
  console.log("📅 Seeding Saudi holidays...");
  const holidays = [
    { nameAr: "رأس السنة الميلادية", nameEn: "New Year's Day", date: new Date("2026-01-01"), type: "PUBLIC", year: 2026, isPaid: true },
    { nameAr: "يوم التأسيس", nameEn: "Founding Day", date: new Date("2026-02-22"), type: "NATIONAL", year: 2026, isPaid: true },
    { nameAr: "يوم العلم", nameEn: "Flag Day", date: new Date("2026-03-11"), type: "NATIONAL", year: 2026, isPaid: true },
    { nameAr: "عيد الفطر", nameEn: "Eid al-Fitr", date: new Date("2026-03-20"), type: "RELIGIOUS", year: 2026, isPaid: true },
    { nameAr: "عيد الأضحى", nameEn: "Eid al-Adha", date: new Date("2026-05-27"), type: "RELIGIOUS", year: 2026, isPaid: true },
    { nameAr: "اليوم الوطني", nameEn: "National Day", date: new Date("2026-09-23"), type: "NATIONAL", year: 2026, isPaid: true },
  ];

  for (const h of holidays) {
    await prisma.holiday.upsert({
      where: { date_type: { date: h.date, type: h.type } },
      create: h as any,
      update: h as any,
    });
  }
  console.log(`   ✓ ${holidays.length} holidays created\n`);

  console.log("✅ Seeding completed successfully!");
  console.log("\n📋 Login Credentials:");
  console.log(`   Admin: ${adminEmail} / ${adminPassword}`);
  console.log(`   Demo Employees: <email from list> / Demo@123456`);
}

main()
  .catch((e) => {
    console.error("❌ Seeding failed:", e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
