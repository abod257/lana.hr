"use client";

import * as React from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
  LayoutDashboard,
  Users,
  Building2,
  Briefcase,
  Clock,
  CalendarDays,
  Wallet,
  UserPlus,
  FileText,
  Bell,
  BarChart3,
  Settings,
  User,
  LogOut,
  ChevronLeft,
  ChevronRight,
  Menu,
  X,
  Globe,
  Moon,
  Sun,
  Search,
  Shield,
  History,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { useTheme } from "next-themes";
import { useLocale } from "@/components/locale-provider";
import { cn, getInitials } from "@/lib/utils";
import type { AuthUser } from "@/lib/auth";

interface DashboardShellProps {
  user: AuthUser;
  children: React.ReactNode;
  notificationsCount?: number;
}

interface NavItem {
  href: string;
  label: string;
  labelEn: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: number;
  roles?: string[];
  permission?: string;
}

const NAV_ITEMS: NavItem[] = [
  { href: "/dashboard", label: "لوحة التحكم", labelEn: "Dashboard", icon: LayoutDashboard },
  { href: "/employees", label: "الموظفون", labelEn: "Employees", icon: Users, roles: ["HR_OFFICER", "HR_MANAGER", "SYSTEM_ADMIN"] },
  { href: "/departments", label: "الأقسام", labelEn: "Departments", icon: Building2, roles: ["HR_OFFICER", "HR_MANAGER", "SYSTEM_ADMIN"] },
  { href: "/positions", label: "المناصب", labelEn: "Positions", icon: Briefcase, roles: ["HR_OFFICER", "HR_MANAGER", "SYSTEM_ADMIN"] },
  { href: "/attendance", label: "الحضور", labelEn: "Attendance", icon: Clock },
  { href: "/leave", label: "الإجازات", labelEn: "Leave", icon: CalendarDays },
  { href: "/payroll", label: "الرواتب", labelEn: "Payroll", icon: Wallet, roles: ["PAYROLL_OFFICER", "HR_MANAGER", "SYSTEM_ADMIN"] },
  { href: "/recruitment", label: "التوظيف", labelEn: "Recruitment", icon: UserPlus, roles: ["HR_OFFICER", "HR_MANAGER", "MANAGER", "SYSTEM_ADMIN"] },
  { href: "/documents", label: "الوثائق", labelEn: "Documents", icon: FileText },
  { href: "/reports", label: "التقارير", labelEn: "Reports", icon: BarChart3, roles: ["HR_OFFICER", "HR_MANAGER", "PAYROLL_OFFICER", "SYSTEM_ADMIN"] },
  { href: "/audit", label: "سجلات التدقيق", labelEn: "Audit Logs", icon: History, roles: ["SYSTEM_ADMIN"] },
  { href: "/settings", label: "الإعدادات", labelEn: "Settings", icon: Settings, roles: ["HR_MANAGER", "SYSTEM_ADMIN"] },
];

export function DashboardShell({ user, children, notificationsCount = 0 }: DashboardShellProps) {
  const pathname = usePathname();
  const router = useRouter();
  const { theme, setTheme } = useTheme();
  const { locale, setLocale, t } = useLocale();
  const [collapsed, setCollapsed] = React.useState(false);
  const [mobileOpen, setMobileOpen] = React.useState(false);

  const filteredNav = NAV_ITEMS.filter((item) => {
    if (!item.roles || item.roles.length === 0) return true;
    return item.roles.includes(user.role.name);
  });

  const userName = locale === "ar"
    ? `${user.employee?.firstNameAr || ""} ${user.employee?.lastNameAr || ""}`.trim()
    : `${user.employee?.firstNameEn || ""} ${user.employee?.lastNameEn || ""}`.trim() || user.email;

  const handleLogout = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/login");
    router.refresh();
  };

  const fullName = userName || "User";
  const initials = user.employee
    ? getInitials(user.employee.firstNameEn || "U", user.employee.lastNameEn || "U")
    : user.email.substring(0, 2).toUpperCase();

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      {/* Mobile Sidebar Overlay */}
      {mobileOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm lg:hidden"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={cn(
          "fixed lg:relative z-50 h-full bg-card border-e border-border flex flex-col transition-all duration-300",
          collapsed ? "w-20" : "w-72",
          mobileOpen ? "translate-x-0" : (locale === "ar" ? "translate-x-full lg:translate-x-0" : "-translate-x-full lg:translate-x-0")
        )}
      >
        {/* Logo */}
        <div className="h-16 flex items-center justify-between px-4 border-b border-border">
          {!collapsed && (
            <Link href="/dashboard" className="flex items-center gap-2">
              <div className="h-9 w-9 rounded-lg gradient-primary flex items-center justify-center shadow-md">
                <Shield className="h-5 w-5 text-white" />
              </div>
              <div className="flex flex-col">
                <span className="font-bold text-sm">{t("app.name")}</span>
                <span className="text-xs text-muted-foreground">{t("app.tagline").substring(0, 20)}...</span>
              </div>
            </Link>
          )}
          {collapsed && (
            <div className="h-9 w-9 rounded-lg gradient-primary flex items-center justify-center shadow-md mx-auto">
              <Shield className="h-5 w-5 text-white" />
            </div>
          )}
          <Button
            variant="ghost"
            size="icon"
            className="lg:flex hidden h-8 w-8"
            onClick={() => setCollapsed(!collapsed)}
          >
            {collapsed ? (locale === "ar" ? <ChevronLeft className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />) : (locale === "ar" ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />)}
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="lg:hidden h-8 w-8"
            onClick={() => setMobileOpen(false)}
          >
            <X className="h-4 w-4" />
          </Button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto p-3 space-y-1">
          {filteredNav.map((item) => {
            const Icon = item.icon;
            const isActive = pathname === item.href || pathname.startsWith(item.href + "/");
            const label = locale === "ar" ? item.label : item.labelEn;

            return (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setMobileOpen(false)}
                className={cn(
                  "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-200",
                  isActive
                    ? "bg-primary text-primary-foreground shadow-md"
                    : "text-muted-foreground hover:bg-accent hover:text-accent-foreground",
                  collapsed && "justify-center"
                )}
                title={collapsed ? label : undefined}
              >
                <Icon className="h-5 w-5 shrink-0" />
                {!collapsed && (
                  <>
                    <span className="flex-1">{label}</span>
                    {item.badge && item.badge > 0 && (
                      <Badge variant={isActive ? "glass" : "secondary"} className="h-5 px-2">
                        {item.badge}
                      </Badge>
                    )}
                  </>
                )}
              </Link>
            );
          })}
        </nav>

        {/* User info */}
        {!collapsed && (
          <div className="p-4 border-t border-border">
            <div className="flex items-center gap-3 p-2 rounded-lg hover:bg-accent transition-colors">
              <Avatar className="h-9 w-9">
                <AvatarImage src={user.employee?.profilePicture || undefined} alt={fullName} />
                <AvatarFallback>{initials}</AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold truncate">{fullName}</p>
                <p className="text-xs text-muted-foreground truncate">
                  {locale === "ar" ? user.role.displayNameAr : user.role.displayNameEn}
                </p>
              </div>
            </div>
          </div>
        )}
      </aside>

      {/* Main */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top Bar */}
        <header className="h-16 bg-card border-b border-border flex items-center justify-between px-4 lg:px-6 shrink-0">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              className="lg:hidden"
              onClick={() => setMobileOpen(true)}
            >
              <Menu className="h-5 w-5" />
            </Button>
            <div className="hidden md:block relative max-w-md w-full">
              <Search className="absolute start-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder={t("common.search")}
                className="ps-10 w-full md:w-80"
              />
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Locale switcher */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <Globe className="h-5 w-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>{t("common.language")}</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => setLocale("ar")}>
                  <span className={cn(locale === "ar" && "font-bold")}>العربية</span>
                  {locale === "ar" && <span className="ms-auto">✓</span>}
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setLocale("en")}>
                  <span className={cn(locale === "en" && "font-bold")}>English</span>
                  {locale === "en" && <span className="ms-auto">✓</span>}
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            {/* Theme toggle */}
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            >
              {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </Button>

            {/* Notifications */}
            <Link href="/notifications">
              <Button variant="ghost" size="icon" className="relative">
                <Bell className="h-5 w-5" />
                {notificationsCount > 0 && (
                  <span className="absolute top-1 end-1 h-4 w-4 bg-destructive text-destructive-foreground text-xs rounded-full flex items-center justify-center font-bold">
                    {notificationsCount > 9 ? "9+" : notificationsCount}
                  </span>
                )}
              </Button>
            </Link>

            {/* User menu */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="gap-2 px-2">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={user.employee?.profilePicture || undefined} />
                    <AvatarFallback>{initials}</AvatarFallback>
                  </Avatar>
                  <span className="hidden md:inline text-sm font-medium">{fullName}</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel>
                  <div className="flex flex-col space-y-1">
                    <p className="text-sm font-semibold">{fullName}</p>
                    <p className="text-xs text-muted-foreground">{user.email}</p>
                    <Badge variant="secondary" className="w-fit mt-1">
                      {locale === "ar" ? user.role.displayNameAr : user.role.displayNameEn}
                    </Badge>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link href="/profile" className="cursor-pointer">
                    <User className="me-2 h-4 w-4" />
                    {t("common.profile")}
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/settings" className="cursor-pointer">
                    <Settings className="me-2 h-4 w-4" />
                    {t("common.settings")}
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout} className="text-destructive cursor-pointer">
                  <LogOut className="me-2 h-4 w-4" />
                  {t("common.signOut")}
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto bg-muted/30">
          <div className="container mx-auto p-4 lg:p-6 max-w-7xl">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
