import { getSession } from "@/lib/auth";
import { notFound, redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Mail,
  Phone,
  MapPin,
  Building2,
  Briefcase,
  Calendar,
  DollarSign,
  FileText,
  CreditCard,
  Globe,
  Edit,
  ArrowLeft,
} from "lucide-react";
import Link from "next/link";
import { formatDate, getInitials } from "@/lib/utils";

export default async function EmployeeDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const user = await getSession();
  if (!user) redirect("/login");

  const employee = await prisma.employee.findUnique({
    where: { id },
    include: {
      user: true,
      department: true,
      position: true,
      manager: true,
      contracts: true,
    },
  }).catch(() => null);

  if (!employee) notFound();

  const initials = getInitials(employee.firstNameEn, employee.lastNameEn);

  return (
    <div className="space-y-6 animate-fade-in-up">
      <div className="flex items-center justify-between">
        <Link href="/employees">
          <Button variant="ghost" className="gap-2">
            <ArrowLeft className="h-4 w-4 rtl:rotate-180" />
            Back to Employees
          </Button>
        </Link>
        <Button className="gap-2">
          <Edit className="h-4 w-4" />
          Edit
        </Button>
      </div>

      {/* Profile Card */}
      <Card className="overflow-hidden">
        <div className="h-32 bg-gradient-to-br from-primary via-primary to-accent-foreground" />
        <CardContent className="p-6 -mt-12">
          <div className="flex flex-col md:flex-row items-start md:items-end gap-4">
            <Avatar className="h-24 w-24 border-4 border-background shadow-lg">
              <AvatarImage src={employee.profilePicture || undefined} />
              <AvatarFallback className="text-2xl">{initials}</AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <h2 className="text-2xl font-bold">
                {employee.firstNameEn} {employee.lastNameEn}
              </h2>
              <p className="text-muted-foreground">
                {employee.firstNameAr} {employee.lastNameAr}
              </p>
              <div className="flex items-center gap-2 mt-2">
                <Badge variant="secondary">{employee.employeeCode}</Badge>
                <Badge variant={employee.status === "ACTIVE" ? "success" : "warning"}>{employee.status}</Badge>
                <Badge variant="outline">{employee.contractType}</Badge>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="overview">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="employment">Employment</TabsTrigger>
          <TabsTrigger value="compensation">Compensation</TabsTrigger>
          <TabsTrigger value="documents">Documents</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Contact Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center gap-3 text-sm">
                  <Mail className="h-4 w-4 text-muted-foreground" />
                  <span>{employee.user.email}</span>
                </div>
                {employee.phone && (
                  <div className="flex items-center gap-3 text-sm">
                    <Phone className="h-4 w-4 text-muted-foreground" />
                    <span>{employee.phone}</span>
                  </div>
                )}
                {employee.personalEmail && (
                  <div className="flex items-center gap-3 text-sm">
                    <Mail className="h-4 w-4 text-muted-foreground" />
                    <span>{employee.personalEmail}</span>
                  </div>
                )}
                {employee.address && (
                  <div className="flex items-center gap-3 text-sm">
                    <MapPin className="h-4 w-4 text-muted-foreground" />
                    <span>{employee.address}, {employee.city}, {employee.country}</span>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Personal Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>
                    <p className="text-muted-foreground text-xs">Gender</p>
                    <p>{employee.gender}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground text-xs">Marital Status</p>
                    <p>{employee.maritalStatus}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground text-xs">Nationality</p>
                    <p>{employee.nationality || "—"}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground text-xs">Date of Birth</p>
                    <p>{employee.dateOfBirth ? formatDate(employee.dateOfBirth) : "—"}</p>
                  </div>
                  {employee.nationalId && (
                    <div className="col-span-2">
                      <p className="text-muted-foreground text-xs">National ID</p>
                      <p className="font-mono">{employee.nationalId}</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="employment" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Position</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center gap-3">
                  <Building2 className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="text-xs text-muted-foreground">Department</p>
                    <p className="font-medium">{employee.department.nameEn}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Briefcase className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="text-xs text-muted-foreground">Position</p>
                    <p className="font-medium">{employee.position.titleEn}</p>
                  </div>
                </div>
                {employee.manager && (
                  <div className="flex items-center gap-3">
                    <Users className="h-4 w-4 text-muted-foreground" />
                    <div>
                      <p className="text-xs text-muted-foreground">Reports To</p>
                      <p className="font-medium">{employee.manager.firstNameEn} {employee.manager.lastNameEn}</p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Employment Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <p className="text-xs text-muted-foreground">Hire Date</p>
                  <p className="font-medium">{formatDate(employee.hireDate)}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Contract Type</p>
                  <p className="font-medium">{employee.contractType}</p>
                </div>
                {employee.contractEndDate && (
                  <div>
                    <p className="text-xs text-muted-foreground">Contract End</p>
                    <p className="font-medium">{formatDate(employee.contractEndDate)}</p>
                  </div>
                )}
                <div>
                  <p className="text-xs text-muted-foreground">Status</p>
                  <Badge variant={employee.status === "ACTIVE" ? "success" : "warning"}>{employee.status}</Badge>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="compensation" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Salary Breakdown</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <p className="text-xs text-muted-foreground">Basic Salary</p>
                  <p className="text-2xl font-bold">{parseFloat(employee.basicSalary.toString()).toLocaleString()} SAR</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Housing Allowance</p>
                  <p className="text-xl font-semibold">{parseFloat((employee.housingAllowance || 0).toString()).toLocaleString()} SAR</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Transport Allowance</p>
                  <p className="text-xl font-semibold">{parseFloat((employee.transportAllowance || 0).toString()).toLocaleString()} SAR</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Other Allowances</p>
                  <p className="text-xl font-semibold">{parseFloat((employee.otherAllowances || 0).toString()).toLocaleString()} SAR</p>
                </div>
              </div>
              <div className="pt-4 border-t">
                <div className="flex justify-between items-center">
                  <p className="font-semibold">Total Package</p>
                  <p className="text-2xl font-bold text-primary">
                    {(parseFloat(employee.basicSalary.toString()) +
                      parseFloat((employee.housingAllowance || 0).toString()) +
                      parseFloat((employee.transportAllowance || 0).toString()) +
                      parseFloat((employee.otherAllowances || 0).toString())).toLocaleString()} SAR
                  </p>
                </div>
              </div>

              {(employee.bankName || employee.iban) && (
                <>
                  <div className="pt-4 border-t">
                    <h4 className="font-medium mb-3 flex items-center gap-2">
                      <CreditCard className="h-4 w-4" />
                      Bank Details
                    </h4>
                    <div className="space-y-2 text-sm">
                      {employee.bankName && (
                        <div>
                          <span className="text-muted-foreground">Bank: </span>
                          <span>{employee.bankName}</span>
                        </div>
                      )}
                      {employee.iban && (
                        <div>
                          <span className="text-muted-foreground">IBAN: </span>
                          <span className="font-mono">{employee.iban}</span>
                        </div>
                      )}
                    </div>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="documents">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Document Tracking</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {employee.iqamaNumber && (
                <div className="flex justify-between items-center p-3 border rounded-lg">
                  <div>
                    <p className="font-medium">Iqama</p>
                    <p className="text-sm text-muted-foreground font-mono">{employee.iqamaNumber}</p>
                  </div>
                  {employee.iqamaExpiryDate && (
                    <Badge variant={new Date(employee.iqamaExpiryDate) < new Date() ? "destructive" : "success"}>
                      Expires {formatDate(employee.iqamaExpiryDate)}
                    </Badge>
                  )}
                </div>
              )}
              {employee.passportNumber && (
                <div className="flex justify-between items-center p-3 border rounded-lg">
                  <div>
                    <p className="font-medium">Passport</p>
                    <p className="text-sm text-muted-foreground font-mono">{employee.passportNumber}</p>
                  </div>
                  {employee.passportExpiryDate && (
                    <Badge variant={new Date(employee.passportExpiryDate) < new Date() ? "destructive" : "success"}>
                      Expires {formatDate(employee.passportExpiryDate)}
                    </Badge>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

// Icons used in the component
import { Users } from "lucide-react";
