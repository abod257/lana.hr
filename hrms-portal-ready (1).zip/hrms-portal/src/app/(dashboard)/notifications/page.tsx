import { Suspense } from "react";
import { NotificationsList } from "@/components/notifications/notifications-list";

export default function NotificationsPage() {
  return (
    <div className="space-y-6 animate-fade-in-up">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Notifications</h1>
        <p className="text-muted-foreground mt-1">View all your notifications and alerts</p>
      </div>
      <Suspense fallback={<div>Loading...</div>}>
        <NotificationsList />
      </Suspense>
    </div>
  );
}
