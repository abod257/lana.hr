"use client";

import { Card, CardContent } from "@/components/ui/card";
import { Users, UserCheck, UserX, Calendar, FileText, TrendingUp, Wallet, AlertTriangle } from "lucide-react";
import { useLocale } from "@/components/locale-provider";

interface DashboardStatsProps {
  data: any;
  roleName: string;
}

export function DashboardStats({ data, roleName }: DashboardStatsProps) {
  const { t } = useLocale();
  const isAdmin = ["HR_MANAGER", "HR_OFFICER", "SYSTEM_ADMIN", "PAYROLL_OFFICER"].includes(roleName);

  const stats = isAdmin
    ? [
        {
          label: t("dashboard.totalEmployees"),
          value: data.totalEmployees,
          icon: Users,
          color: "from-blue-500 to-blue-600",
          bg: "bg-blue-50 dark:bg-blue-950/30",
          iconColor: "text-blue-600 dark:text-blue-400",
          trend: "+12%",
          trendUp: true,
        },
        {
          label: t("dashboard.presentToday"),
          value: data.presentToday,
          icon: UserCheck,
          color: "from-green-500 to-green-600",
          bg: "bg-green-50 dark:bg-green-950/30",
          iconColor: "text-green-600 dark:text-green-400",
          trend: `${Math.round((data.presentToday / Math.max(data.activeEmployees, 1)) * 100)}%`,
        },
        {
          label: t("dashboard.onLeave"),
          value: data.onLeaveToday,
          icon: Calendar,
          color: "from-amber-500 to-amber-600",
          bg: "bg-amber-50 dark:bg-amber-950/30",
          iconColor: "text-amber-600 dark:text-amber-400",
        },
        {
          label: t("dashboard.absent"),
          value: data.absentToday,
          icon: UserX,
          color: "from-red-500 to-red-600",
          bg: "bg-red-50 dark:bg-red-950/30",
          iconColor: "text-red-600 dark:text-red-400",
        },
      ]
    : [
        {
          label: t("dashboard.presentToday"),
          value: data.presentToday,
          icon: UserCheck,
          color: "from-green-500 to-green-600",
          bg: "bg-green-50 dark:bg-green-950/30",
          iconColor: "text-green-600 dark:text-green-400",
        },
        {
          label: "My Pending",
          value: data.personalStats?.myPending || 0,
          icon: FileText,
          color: "from-amber-500 to-amber-600",
          bg: "bg-amber-50 dark:bg-amber-950/30",
          iconColor: "text-amber-600 dark:text-amber-400",
        },
        {
          label: "My Approved",
          value: data.personalStats?.myApproved || 0,
          icon: Calendar,
          color: "from-blue-500 to-blue-600",
          bg: "bg-blue-50 dark:bg-blue-950/30",
          iconColor: "text-blue-600 dark:text-blue-400",
        },
        {
          label: "Payslips",
          value: data.personalStats?.myPayslips || 0,
          icon: Wallet,
          color: "from-purple-500 to-purple-600",
          bg: "bg-purple-50 dark:bg-purple-950/30",
          iconColor: "text-purple-600 dark:text-purple-400",
        },
      ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {stats.map((stat, i) => {
        const Icon = stat.icon;
        return (
          <Card key={i} className="overflow-hidden card-hover">
            <CardContent className="p-5">
              <div className="flex items-start justify-between mb-3">
                <div className={`h-11 w-11 rounded-xl ${stat.bg} flex items-center justify-center`}>
                  <Icon className={`h-5 w-5 ${stat.iconColor}`} />
                </div>
                {stat.trend && (
                  <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${
                    stat.trendUp ? "bg-success/10 text-success" : "bg-destructive/10 text-destructive"
                  }`}>
                    <TrendingUp className="inline h-3 w-3 me-1" />
                    {stat.trend}
                  </span>
                )}
              </div>
              <div className="space-y-0.5">
                <p className="text-2xl font-bold">{stat.value.toLocaleString()}</p>
                <p className="text-xs text-muted-foreground">{stat.label}</p>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
