import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { hashPassword } from "@/lib/auth";
import { ApiResponse, handleApiError } from "@/lib/api-response";
import { createAuditLog, getClientInfo } from "@/lib/audit";
import { registerSchema } from "@/lib/validations";

/**
 * Register endpoint - typically used for self-signup with invitation token
 * In production, this should require an invitation token
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const validated = registerSchema.parse(body);
    const { ipAddress, userAgent } = getClientInfo(request);

    // Check if user exists
    const existing = await prisma.user.findUnique({
      where: { email: validated.email.toLowerCase() },
    });
    if (existing) {
      return ApiResponse.conflict("Email already registered");
    }

    const passwordHash = await hashPassword(validated.password);

    // Get default employee role
    const employeeRole = await prisma.role.findUnique({
      where: { name: "EMPLOYEE" },
    });
    if (!employeeRole) {
      return ApiResponse.serverError("System not initialized. Please contact administrator.");
    }

    const user = await prisma.user.create({
      data: {
        email: validated.email.toLowerCase(),
        passwordHash,
        roleId: employeeRole.id,
      },
    });

    await createAuditLog({
      userId: user.id,
      action: "REGISTER",
      resource: "Authentication",
      description: "New user registered",
      ipAddress,
      userAgent,
    });

    return ApiResponse.created({ id: user.id, email: user.email }, "Registration successful");
  } catch (error) {
    return handleApiError(error);
  }
}
