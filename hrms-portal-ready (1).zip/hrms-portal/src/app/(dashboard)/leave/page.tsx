import { Suspense } from "react";
import { getSession } from "@/lib/auth";
import { redirect } from "next/navigation";
import { LeaveRequests } from "@/components/leave/leave-requests";

export default async function LeavePage() {
  const user = await getSession();
  if (!user) redirect("/login");

  return (
    <div className="space-y-6 animate-fade-in-up">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Leave Management</h1>
        <p className="text-muted-foreground mt-1">
          Request and manage leave applications
        </p>
      </div>
      <Suspense fallback={<div>Loading...</div>}>
        <LeaveRequests user={user} />
      </Suspense>
    </div>
  );
}
