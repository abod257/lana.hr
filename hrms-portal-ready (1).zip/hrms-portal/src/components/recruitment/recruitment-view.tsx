"use client";

import * as React from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Briefcase, Users, Calendar, FileText, Plus, MapPin, Clock } from "lucide-react";
import { toast } from "sonner";

export function RecruitmentView() {
  const [jobs, setJobs] = React.useState<any[]>([]);
  const [candidates, setCandidates] = React.useState<any[]>([]);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const fetchData = async () => {
      try {
        const [jobsRes, candRes] = await Promise.all([
          fetch("/api/recruitment/jobs"),
          fetch("/api/recruitment/candidates"),
        ]);
        const [jobsData, candData] = await Promise.all([jobsRes.json(), candRes.json()]);
        if (jobsData.success) setJobs(jobsData.data || []);
        if (candData.success) setCandidates(candData.data || []);
      } catch {} finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Open Positions</p>
                <p className="text-2xl font-bold">{jobs.filter(j => j.status === "OPEN").length}</p>
              </div>
              <Briefcase className="h-8 w-8 text-primary opacity-80" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Candidates</p>
                <p className="text-2xl font-bold">{candidates.length}</p>
              </div>
              <Users className="h-8 w-8 text-success opacity-80" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">In Interview</p>
                <p className="text-2xl font-bold">{candidates.filter(c => c.status === "INTERVIEW_SCHEDULED").length}</p>
              </div>
              <Calendar className="h-8 w-8 text-warning opacity-80" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Offers Sent</p>
                <p className="text-2xl font-bold">{candidates.filter(c => c.status === "OFFER_SENT").length}</p>
              </div>
              <FileText className="h-8 w-8 text-info opacity-80" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="jobs">
        <TabsList>
          <TabsTrigger value="jobs">Job Openings</TabsTrigger>
          <TabsTrigger value="candidates">Candidates</TabsTrigger>
        </TabsList>

        <TabsContent value="jobs">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Job Openings</CardTitle>
                  <CardDescription>Active job postings</CardDescription>
                </div>
                <Button className="gap-2">
                  <Plus className="h-4 w-4" />
                  New Job
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="text-center py-12">Loading...</div>
              ) : jobs.length === 0 ? (
                <div className="text-center py-12">
                  <Briefcase className="h-12 w-12 mx-auto text-muted-foreground/50 mb-3" />
                  <p className="text-muted-foreground">No job openings yet</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {jobs.map((job) => (
                    <Card key={job.id}>
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <h3 className="font-semibold">{job.titleEn}</h3>
                              <Badge variant={job.status === "OPEN" ? "success" : "secondary"}>{job.status}</Badge>
                            </div>
                            <p className="text-sm text-muted-foreground line-clamp-2 mb-2">{job.description}</p>
                            <div className="flex items-center gap-4 text-xs text-muted-foreground">
                              <span className="flex items-center gap-1"><Briefcase className="h-3 w-3" />{job.department?.nameEn}</span>
                              {job.location && <span className="flex items-center gap-1"><MapPin className="h-3 w-3" />{job.location}</span>}
                              <span className="flex items-center gap-1"><Users className="h-3 w-3" />{job._count?.candidates || 0} candidates</span>
                            </div>
                          </div>
                          <Button variant="outline" size="sm">View</Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="candidates">
          <Card>
            <CardHeader>
              <CardTitle>Candidates</CardTitle>
              <CardDescription>All candidates across openings</CardDescription>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="text-center py-12">Loading...</div>
              ) : candidates.length === 0 ? (
                <div className="text-center py-12">
                  <Users className="h-12 w-12 mx-auto text-muted-foreground/50 mb-3" />
                  <p className="text-muted-foreground">No candidates yet</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {candidates.map((c) => (
                    <Card key={c.id}>
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className="h-10 w-10 rounded-full gradient-primary flex items-center justify-center text-white font-semibold">
                              {c.firstName?.[0]}{c.lastName?.[0]}
                            </div>
                            <div>
                              <h3 className="font-semibold">{c.firstName} {c.lastName}</h3>
                              <p className="text-sm text-muted-foreground">{c.email}</p>
                            </div>
                          </div>
                          <Badge variant={c.status === "HIRED" ? "success" : c.status === "REJECTED" ? "destructive" : "secondary"}>
                            {c.status}
                          </Badge>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
