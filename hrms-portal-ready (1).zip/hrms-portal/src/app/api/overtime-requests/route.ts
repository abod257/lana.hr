import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth } from "@/lib/auth";
import { ApiResponse, handleApiError } from "@/lib/api-response";
import { createAuditLog, getClientInfo } from "@/lib/audit";
import { overtimeRequestSchema } from "@/lib/validations";
import { generateId } from "@/lib/utils";
import { differenceInMinutes } from "date-fns";

export async function POST(request: NextRequest) {
  try {
    const user = await requireAuth();
    if (!user.employee) {
      return ApiResponse.badRequest("User is not linked to an employee");
    }

    const body = await request.json();
    const validated = overtimeRequestSchema.parse(body);
    const { ipAddress, userAgent } = getClientInfo(request);

    const startTime = new Date(validated.startTime);
    const endTime = new Date(validated.endTime);
    const hours = (differenceInMinutes(endTime, startTime) / 60).toFixed(2);
    const hourlyRate = parseFloat(user.employee.basicSalary.toString()) / 30 / 8;
    const amount = parseFloat(hours) * hourlyRate * validated.rate;

    const overtime = await prisma.overtimeRequest.create({
      data: {
        requestNumber: generateId("OT"),
        employeeId: user.employee.id,
        date: new Date(validated.date),
        startTime,
        endTime,
        hours: parseFloat(hours),
        rate: validated.rate,
        amount,
        reason: validated.reason,
        status: "PENDING",
      },
    });

    await createAuditLog({
      userId: user.id,
      action: "CREATE",
      resource: "OvertimeRequest",
      resourceId: overtime.id,
      description: `Overtime request: ${hours} hours`,
      ipAddress,
      userAgent,
    });

    return ApiResponse.created(overtime, "Overtime request submitted");
  } catch (error) {
    return handleApiError(error);
  }
}

export async function GET(request: NextRequest) {
  try {
    const user = await requireAuth();
    if (!user.employee) {
      return ApiResponse.success([]);
    }

    const overtimes = await prisma.overtimeRequest.findMany({
      where: { employeeId: user.employee.id },
      orderBy: { createdAt: "desc" },
    });

    return ApiResponse.success(overtimes);
  } catch (error) {
    return handleApiError(error);
  }
}
