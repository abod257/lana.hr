import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { ApiResponse, handleApiError } from "@/lib/api-response";
import { createAuditLog, getClientInfo } from "@/lib/audit";
import { z } from "zod";

const schema = z.object({ email: z.string().email() });

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { email } = schema.parse(body);
    const { ipAddress, userAgent } = getClientInfo(request);

    // Find user (don't reveal if email exists)
    const user = await prisma.user.findUnique({
      where: { email: email.toLowerCase() },
    });

    // Always return success for security (don't leak email existence)
    if (user) {
      // In production: generate reset token, save it, send email
      await createAuditLog({
        userId: user.id,
        action: "PASSWORD_RESET_REQUEST",
        resource: "Authentication",
        description: "Password reset requested",
        ipAddress,
        userAgent,
      });
    }

    return ApiResponse.success({ message: "If the email exists, a reset link has been sent" });
  } catch (error) {
    return handleApiError(error);
  }
}
