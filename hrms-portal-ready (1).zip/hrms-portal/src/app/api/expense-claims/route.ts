import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth } from "@/lib/auth";
import { ApiResponse, handleApiError } from "@/lib/api-response";
import { createAuditLog, getClientInfo } from "@/lib/audit";
import { expenseClaimSchema } from "@/lib/validations";
import { generateId } from "@/lib/utils";

export async function POST(request: NextRequest) {
  try {
    const user = await requireAuth();
    if (!user.employee) {
      return ApiResponse.badRequest("User is not linked to an employee");
    }

    const body = await request.json();
    const validated = expenseClaimSchema.parse(body);
    const { ipAddress, userAgent } = getClientInfo(request);

    const claim = await prisma.expenseClaim.create({
      data: {
        claimNumber: generateId("EC"),
        employeeId: user.employee.id,
        title: validated.title,
        category: validated.category,
        amount: validated.amount,
        currency: validated.currency,
        expenseDate: new Date(validated.expenseDate),
        description: validated.description,
        receiptUrls: validated.receiptUrls,
        status: "PENDING",
      },
    });

    await createAuditLog({
      userId: user.id,
      action: "CREATE",
      resource: "ExpenseClaim",
      resourceId: claim.id,
      description: `Expense claim submitted: ${validated.title}`,
      ipAddress,
      userAgent,
    });

    return ApiResponse.created(claim, "Expense claim submitted");
  } catch (error) {
    return handleApiError(error);
  }
}

export async function GET(request: NextRequest) {
  try {
    const user = await requireAuth();
    if (!user.employee) {
      return ApiResponse.success([]);
    }

    const claims = await prisma.expenseClaim.findMany({
      where: { employeeId: user.employee.id },
      orderBy: { createdAt: "desc" },
    });

    return ApiResponse.success(claims);
  } catch (error) {
    return handleApiError(error);
  }
}
