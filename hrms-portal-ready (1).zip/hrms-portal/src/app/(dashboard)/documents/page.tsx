import { DocumentsView } from "@/components/documents/documents-view";

export default function DocumentsPage() {
  return (
    <div className="space-y-6 animate-fade-in-up">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Documents</h1>
        <p className="text-muted-foreground mt-1">Manage employee documents and contracts</p>
      </div>
      <DocumentsView />
    </div>
  );
}
