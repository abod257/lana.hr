import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth, hasPermission } from "@/lib/auth";
import { ApiResponse, handleApiError } from "@/lib/api-response";
import { createAuditLog, getClientInfo } from "@/lib/audit";
import { positionSchema, paginationSchema } from "@/lib/validations";

export async function GET(request: NextRequest) {
  try {
    await requireAuth();
    const { searchParams } = new URL(request.url);
    const { page, pageSize, search } = paginationSchema.parse({
      page: searchParams.get("page") || undefined,
      pageSize: searchParams.get("pageSize") || undefined,
      search: searchParams.get("search") || undefined,
    });
    const departmentId = searchParams.get("departmentId");

    const where: any = { isActive: true };
    if (departmentId) where.departmentId = departmentId;
    if (search) {
      where.OR = [
        { titleAr: { contains: search, mode: "insensitive" } },
        { titleEn: { contains: search, mode: "insensitive" } },
        { code: { contains: search, mode: "insensitive" } },
      ];
    }

    const [positions, total] = await Promise.all([
      prisma.position.findMany({
        where,
        include: {
          department: { select: { id: true, nameEn: true, nameAr: true } },
          _count: { select: { employees: true } },
        },
        orderBy: { titleEn: "asc" },
        skip: (page - 1) * pageSize,
        take: pageSize,
      }),
      prisma.position.count({ where }),
    ]);

    return ApiResponse.paginated(positions, total, page, pageSize);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await requireAuth();
    if (!hasPermission(user, "positions.manage")) {
      return ApiResponse.forbidden();
    }

    const body = await request.json();
    const validated = positionSchema.parse(body);
    const { ipAddress, userAgent } = getClientInfo(request);

    const existing = await prisma.position.findUnique({
      where: { code: validated.code },
    });
    if (existing) return ApiResponse.conflict("Position code already exists");

    const position = await prisma.position.create({ data: validated });

    await createAuditLog({
      userId: user.id,
      action: "CREATE",
      resource: "Position",
      resourceId: position.id,
      description: `Created position ${position.titleEn}`,
      ipAddress,
      userAgent,
    });

    return ApiResponse.created(position);
  } catch (error) {
    return handleApiError(error);
  }
}
