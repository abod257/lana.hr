"use client";

import * as React from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Settings as SettingsIcon, Save, Building2, Bell, Mail, Shield } from "lucide-react";
import { toast } from "sonner";

export function SettingsView() {
  const [settings, setSettings] = React.useState<any>({ settings: [], company: null });
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const fetchSettings = async () => {
      try {
        const res = await fetch("/api/settings");
        const data = await res.json();
        if (data.success) setSettings(data.data);
      } catch {} finally {
        setLoading(false);
      }
    };
    fetchSettings();
  }, []);

  const handleSave = async () => {
    try {
      const res = await fetch("/api/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(settings),
      });
      const data = await res.json();
      if (data.success) toast.success("Settings saved");
      else toast.error("Failed to save");
    } catch {
      toast.error("Error");
    }
  };

  return (
    <Tabs defaultValue="company">
      <TabsList className="grid w-full grid-cols-2 md:grid-cols-5">
        <TabsTrigger value="company" className="gap-2"><Building2 className="h-4 w-4" />Company</TabsTrigger>
        <TabsTrigger value="general" className="gap-2"><SettingsIcon className="h-4 w-4" />General</TabsTrigger>
        <TabsTrigger value="leave" className="gap-2"><Bell className="h-4 w-4" />Leave</TabsTrigger>
        <TabsTrigger value="attendance" className="gap-2"><Bell className="h-4 w-4" />Attendance</TabsTrigger>
        <TabsTrigger value="notifications" className="gap-2"><Mail className="h-4 w-4" />Notifications</TabsTrigger>
      </TabsList>

      <TabsContent value="company">
        <Card>
          <CardHeader>
            <CardTitle>Company Information</CardTitle>
            <CardDescription>Manage your company details</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label>Company Name (English)</Label>
                <Input defaultValue={settings.company?.nameEn} />
              </div>
              <div>
                <Label>Company Name (Arabic)</Label>
                <Input defaultValue={settings.company?.nameAr} dir="rtl" />
              </div>
              <div>
                <Label>Tax Number</Label>
                <Input defaultValue={settings.company?.taxNumber} />
              </div>
              <div>
                <Label>CR Number</Label>
                <Input defaultValue={settings.company?.crNumber} />
              </div>
              <div>
                <Label>Currency</Label>
                <Input defaultValue={settings.company?.currency || "SAR"} />
              </div>
              <div>
                <Label>Timezone</Label>
                <Input defaultValue={settings.company?.timezone || "Asia/Riyadh"} />
              </div>
            </div>
            <Button onClick={handleSave} className="gap-2">
              <Save className="h-4 w-4" />
              Save Changes
            </Button>
          </CardContent>
        </Card>
      </TabsContent>

      <TabsContent value="general">
        <Card>
          <CardHeader>
            <CardTitle>General Settings</CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? "Loading..." : (
              <div className="space-y-4">
                {settings.settings.filter((s: any) => s.category === "GENERAL" || s.category === "PAYROLL").map((s: any) => (
                  <div key={s.key}>
                    <Label>{s.key}</Label>
                    <Input value={JSON.stringify(s.value)} disabled />
                  </div>
                ))}
                <Button onClick={handleSave} className="gap-2">
                  <Save className="h-4 w-4" />
                  Save
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </TabsContent>

      <TabsContent value="leave">
        <Card>
          <CardHeader>
            <CardTitle>Leave Settings</CardTitle>
            <CardDescription>Configure leave policies and balances</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label>Annual Leave Quota (days)</Label>
              <Input type="number" defaultValue={21} />
            </div>
            <div>
              <Label>Sick Leave Quota (days)</Label>
              <Input type="number" defaultValue={30} />
            </div>
            <Button onClick={handleSave} className="gap-2">
              <Save className="h-4 w-4" />
              Save
            </Button>
          </CardContent>
        </Card>
      </TabsContent>

      <TabsContent value="attendance">
        <Card>
          <CardHeader>
            <CardTitle>Attendance Settings</CardTitle>
            <CardDescription>Configure working hours and policies</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Work Start Time</Label>
                <Input type="time" defaultValue="09:00" />
              </div>
              <div>
                <Label>Work End Time</Label>
                <Input type="time" defaultValue="17:00" />
              </div>
            </div>
            <div>
              <Label>Grace Period (minutes)</Label>
              <Input type="number" defaultValue={15} />
            </div>
            <Button onClick={handleSave} className="gap-2">
              <Save className="h-4 w-4" />
              Save
            </Button>
          </CardContent>
        </Card>
      </TabsContent>

      <TabsContent value="notifications">
        <Card>
          <CardHeader>
            <CardTitle>Notification Settings</CardTitle>
            <CardDescription>Configure email and SMS notifications</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">Email notifications are configured via SMTP settings in environment variables.</p>
              <p className="text-sm text-muted-foreground">SMS notifications require an SMS provider integration.</p>
            </div>
          </CardContent>
        </Card>
      </TabsContent>
    </Tabs>
  );
}
