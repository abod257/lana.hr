"use client";

import * as React from "react";
import Link from "next/link";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Wallet, FileText, Plus, Eye, DollarSign, TrendingUp } from "lucide-react";
import { toast } from "sonner";

export function PayrollView() {
  const [payrolls, setPayrolls] = React.useState<any[]>([]);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const fetchPayrolls = async () => {
      try {
        const res = await fetch("/api/payroll");
        const data = await res.json();
        if (data.success) {
          setPayrolls(data.data || []);
        }
      } catch (e) {
        toast.error("Failed to load payrolls");
      } finally {
        setLoading(false);
      }
    };
    fetchPayrolls();
  }, []);

  const totals = payrolls.reduce((acc, p) => ({
    earnings: acc.earnings + parseFloat(p.totalEarnings || 0),
    deductions: acc.deductions + parseFloat(p.totalDeductions || 0),
    net: acc.net + parseFloat(p.totalNetPay || 0),
  }), { earnings: 0, deductions: 0, net: 0 });

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Net Paid</p>
                <p className="text-2xl font-bold">{totals.net.toLocaleString()} SAR</p>
              </div>
              <DollarSign className="h-8 w-8 text-success opacity-80" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Earnings</p>
                <p className="text-2xl font-bold">{totals.earnings.toLocaleString()} SAR</p>
              </div>
              <TrendingUp className="h-8 w-8 text-primary opacity-80" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Deductions</p>
                <p className="text-2xl font-bold">{totals.deductions.toLocaleString()} SAR</p>
              </div>
              <Wallet className="h-8 w-8 text-warning opacity-80" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Payroll Runs</p>
                <p className="text-2xl font-bold">{payrolls.length}</p>
              </div>
              <FileText className="h-8 w-8 text-info opacity-80" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="runs">
        <TabsList>
          <TabsTrigger value="runs">Payroll Runs</TabsTrigger>
          <TabsTrigger value="my">My Payslips</TabsTrigger>
        </TabsList>

        <TabsContent value="runs" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Payroll History</CardTitle>
                  <CardDescription>View and manage payroll processing</CardDescription>
                </div>
                <Button className="gap-2">
                  <Plus className="h-4 w-4" />
                  Process New Payroll
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="text-center py-12">Loading...</div>
              ) : payrolls.length === 0 ? (
                <div className="text-center py-12">
                  <Wallet className="h-12 w-12 mx-auto text-muted-foreground/50 mb-3" />
                  <p className="text-muted-foreground">No payroll runs yet</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {payrolls.map((p) => (
                    <Card key={p.id}>
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <div className="flex items-center gap-2 mb-1">
                              <h3 className="font-semibold">Payroll {p.period}</h3>
                              <Badge variant={p.status === "PAID" ? "success" : p.status === "APPROVED" ? "info" : "warning"}>
                                {p.status}
                              </Badge>
                            </div>
                            <p className="text-sm text-muted-foreground">
                              {p.totalEmployees} employees • Net Pay: {parseFloat(p.totalNetPay).toLocaleString()} SAR
                            </p>
                          </div>
                          <Button variant="outline" size="sm" className="gap-2">
                            <Eye className="h-4 w-4" />
                            View Details
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="my">
          <Card>
            <CardHeader>
              <CardTitle>My Payslips</CardTitle>
              <CardDescription>View and download your payslips</CardDescription>
            </CardHeader>
            <CardContent>
              <MyPayslips />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

function MyPayslips() {
  const [payslips, setPayslips] = React.useState<any[]>([]);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const fetchPayslips = async () => {
      try {
        const res = await fetch("/api/payslips");
        const data = await res.json();
        if (data.success) setPayslips(data.data || []);
      } catch {} finally {
        setLoading(false);
      }
    };
    fetchPayslips();
  }, []);

  if (loading) return <div className="text-center py-8">Loading...</div>;
  if (payslips.length === 0) return (
    <div className="text-center py-12">
      <FileText className="h-12 w-12 mx-auto text-muted-foreground/50 mb-3" />
      <p className="text-muted-foreground">No payslips yet</p>
    </div>
  );

  return (
    <div className="space-y-3">
      {payslips.map((ps) => (
        <Card key={ps.id}>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="font-semibold">Payslip {ps.period}</h3>
                  <Badge variant={ps.status === "PAID" ? "success" : "info"}>{ps.status}</Badge>
                </div>
                <p className="text-sm text-muted-foreground">
                  Net: {parseFloat(ps.netPay).toLocaleString()} SAR | Gross: {parseFloat(ps.totalEarnings).toLocaleString()} SAR
                </p>
              </div>
              <Button variant="outline" size="sm">Download</Button>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
