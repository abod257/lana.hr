"use client";

import * as React from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Mail, Lock, Eye, EyeOff, Shield, Globe, Loader2 } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { loginSchema, type LoginInput } from "@/lib/validations";
import { useLocale } from "@/components/locale-provider";

export default function LoginPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { locale, setLocale, t } = useLocale();
  const [showPassword, setShowPassword] = React.useState(false);
  const [loading, setLoading] = React.useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    watch,
  } = useForm<LoginInput>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: "",
      password: "",
      rememberMe: false,
    },
  });

  const rememberMe = watch("rememberMe");

  const onSubmit = async (data: LoginInput) => {
    setLoading(true);
    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      const result = await response.json();

      if (!response.ok || !result.success) {
        toast.error(result.message || (locale === "ar" ? "فشل تسجيل الدخول" : "Login failed"));
        return;
      }

      toast.success(locale === "ar" ? "تم تسجيل الدخول بنجاح" : "Logged in successfully");
      const redirect = searchParams.get("redirect") || "/dashboard";
      router.push(redirect);
      router.refresh();
    } catch (error) {
      toast.error(locale === "ar" ? "حدث خطأ في الاتصال" : "Connection error");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center relative overflow-hidden bg-gradient-to-br from-background via-background to-accent/30 p-4">
      {/* Decorative background */}
      <div className="absolute inset-0 gradient-bg" />
      <div className="absolute -top-40 -end-40 w-96 h-96 bg-primary/20 rounded-full blur-3xl" />
      <div className="absolute -bottom-40 -start-40 w-96 h-96 bg-info/20 rounded-full blur-3xl" />

      {/* Top right controls */}
      <div className="absolute top-4 end-4 flex items-center gap-2 z-10">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setLocale(locale === "ar" ? "en" : "ar")}
          className="gap-2"
        >
          <Globe className="h-4 w-4" />
          {locale === "ar" ? "English" : "العربية"}
        </Button>
      </div>

      <div className="relative z-10 w-full max-w-md animate-fade-in-up">
        {/* Logo */}
        <div className="flex flex-col items-center mb-8">
          <div className="h-16 w-16 rounded-2xl gradient-primary flex items-center justify-center shadow-lg mb-4">
            <Shield className="h-8 w-8 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-center">
            {t("app.name")}
          </h1>
          <p className="text-sm text-muted-foreground text-center mt-1">
            {t("app.tagline")}
          </p>
        </div>

        {/* Login Card */}
        <div className="glass rounded-2xl p-8 shadow-glass-lg">
          <div className="mb-6">
            <h2 className="text-xl font-bold">{t("auth.loginTitle")}</h2>
            <p className="text-sm text-muted-foreground mt-1">
              {t("auth.loginSubtitle")}
            </p>
          </div>

          <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
            <div className="space-y-2">
              <Label htmlFor="email">{t("auth.email")}</Label>
              <Input
                id="email"
                type="email"
                placeholder="name@company.com"
                autoComplete="email"
                startIcon={<Mail className="h-4 w-4" />}
                {...register("email")}
                className={errors.email ? "border-destructive" : ""}
              />
              {errors.email && (
                <p className="text-xs text-destructive">{errors.email.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="password">{t("auth.password")}</Label>
                <Link
                  href="/forgot-password"
                  className="text-xs text-primary hover:underline"
                >
                  {t("auth.forgotPassword")}
                </Link>
              </div>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  placeholder="••••••••"
                  autoComplete="current-password"
                  startIcon={<Lock className="h-4 w-4" />}
                  {...register("password")}
                  className={errors.password ? "border-destructive" : ""}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 end-0 flex items-center pe-3 text-muted-foreground hover:text-foreground"
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
              {errors.password && (
                <p className="text-xs text-destructive">{errors.password.message}</p>
              )}
            </div>

            <div className="flex items-center space-x-2 rtl:space-x-reverse">
              <Checkbox
                id="rememberMe"
                checked={rememberMe}
                onCheckedChange={(checked) => setValue("rememberMe", !!checked)}
              />
              <Label htmlFor="rememberMe" className="text-sm cursor-pointer">
                {t("auth.rememberMe")}
              </Label>
            </div>

            <Button type="submit" className="w-full" size="lg" loading={loading} disabled={loading}>
              {loading ? <Loader2 className="me-2 h-4 w-4 animate-spin" /> : null}
              {t("auth.loginButton")}
            </Button>
          </form>

          {/* Demo credentials */}
          <div className="mt-6 p-3 bg-info/10 border border-info/20 rounded-lg">
            <p className="text-xs font-semibold text-info mb-1">
              {locale === "ar" ? "بيانات تجريبية" : "Demo Credentials"}
            </p>
            <p className="text-xs text-muted-foreground">
              {locale === "ar" ? "البريد:" : "Email:"} admin@company.com<br />
              {locale === "ar" ? "كلمة المرور:" : "Password:"} Admin@123456
            </p>
          </div>
        </div>

        {/* Footer */}
        <p className="text-center text-xs text-muted-foreground mt-6">
          © 2026 {t("app.name")}. {locale === "ar" ? "جميع الحقوق محفوظة" : "All rights reserved"}.
        </p>
      </div>
    </div>
  );
}
