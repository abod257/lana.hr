import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth } from "@/lib/auth";
import { ApiResponse, handleApiError } from "@/lib/api-response";
import { createAuditLog, getClientInfo } from "@/lib/audit";
import { salaryCertificateRequestSchema } from "@/lib/validations";
import { generateId } from "@/lib/utils";

export async function POST(request: NextRequest) {
  try {
    const user = await requireAuth();
    if (!user.employee) {
      return ApiResponse.badRequest("User is not linked to an employee");
    }

    const body = await request.json();
    const validated = salaryCertificateRequestSchema.parse(body);
    const { ipAddress, userAgent } = getClientInfo(request);

    const certificate = await prisma.salaryCertificateRequest.create({
      data: {
        requestNumber: generateId("SC"),
        employeeId: user.employee.id,
        purpose: validated.purpose,
        purposeDetails: validated.purposeDetails,
        language: validated.language,
        requiredCopies: validated.requiredCopies,
        deliveryMethod: validated.deliveryMethod,
        status: "PENDING",
        notes: validated.notes,
      },
    });

    await createAuditLog({
      userId: user.id,
      action: "CREATE",
      resource: "SalaryCertificateRequest",
      resourceId: certificate.id,
      description: `Salary certificate requested for ${validated.purpose}`,
      ipAddress,
      userAgent,
    });

    return ApiResponse.created(certificate, "Certificate request submitted");
  } catch (error) {
    return handleApiError(error);
  }
}

export async function GET(request: NextRequest) {
  try {
    const user = await requireAuth();
    if (!user.employee) {
      return ApiResponse.success([]);
    }

    const certificates = await prisma.salaryCertificateRequest.findMany({
      where: { employeeId: user.employee.id },
      orderBy: { createdAt: "desc" },
    });

    return ApiResponse.success(certificates);
  } catch (error) {
    return handleApiError(error);
  }
}
