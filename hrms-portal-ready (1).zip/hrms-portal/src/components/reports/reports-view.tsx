"use client";

import * as React from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BarChart3, Download, Users, Clock, Calendar, Wallet, FileText } from "lucide-react";
import { toast } from "sonner";

const REPORTS = [
  { id: "employees", name: "Employee Report", icon: Users, description: "Complete employee directory and statistics" },
  { id: "attendance", name: "Attendance Report", icon: Clock, description: "Monthly attendance and punctuality" },
  { id: "leave", name: "Leave Report", icon: Calendar, description: "Leave usage and balances" },
  { id: "payroll", name: "Payroll Report", icon: Wallet, description: "Payroll costs and breakdown" },
  { id: "recruitment", name: "Recruitment Report", icon: FileText, description: "Hiring metrics and pipeline" },
];

export function ReportsView() {
  const [reportData, setReportData] = React.useState<any>(null);
  const [loading, setLoading] = React.useState(false);
  const [activeReport, setActiveReport] = React.useState("employees");

  const fetchReport = React.useCallback(async (id: string) => {
    setLoading(true);
    try {
      const res = await fetch(`/api/reports/${id}`);
      const data = await res.json();
      if (data.success) setReportData(data.data);
    } catch {
      toast.error("Failed to load report");
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    fetchReport(activeReport);
  }, [activeReport, fetchReport]);

  return (
    <div className="space-y-6">
      <Tabs value={activeReport} onValueChange={setActiveReport}>
        <TabsList className="grid grid-cols-2 md:grid-cols-5 w-full">
          {REPORTS.map((r) => {
            const Icon = r.icon;
            return (
              <TabsTrigger key={r.id} value={r.id} className="gap-2">
                <Icon className="h-4 w-4" />
                <span className="hidden md:inline">{r.name}</span>
              </TabsTrigger>
            );
          })}
        </TabsList>

        {REPORTS.map((r) => (
          <TabsContent key={r.id} value={r.id}>
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <r.icon className="h-5 w-5" />
                      {r.name}
                    </CardTitle>
                    <CardDescription>{r.description}</CardDescription>
                  </div>
                  <Button variant="outline" className="gap-2">
                    <Download className="h-4 w-4" />
                    Export
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <div className="text-center py-12">Loading...</div>
                ) : !reportData ? (
                  <div className="text-center py-12">
                    <BarChart3 className="h-12 w-12 mx-auto text-muted-foreground/50 mb-3" />
                    <p className="text-muted-foreground">No data available</p>
                  </div>
                ) : (
                  <pre className="text-xs bg-muted p-4 rounded-lg overflow-auto max-h-96">
                    {JSON.stringify(reportData, null, 2)}
                  </pre>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}
