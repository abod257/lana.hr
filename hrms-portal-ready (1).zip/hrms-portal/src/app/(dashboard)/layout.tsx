import { redirect } from "next/navigation";
import { getSession } from "@/lib/auth";
import { DashboardShell } from "@/components/layout/dashboard-shell";
import { prisma } from "@/lib/prisma";

export default async function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const user = await getSession();

  if (!user) {
    redirect("/login");
  }

  // Get unread notifications count
  let notificationsCount = 0;
  try {
    notificationsCount = await prisma.notification.count({
      where: { userId: user.id, isRead: false },
    });
  } catch (e) {
    // DB might not be available yet
  }

  return (
    <DashboardShell user={user} notificationsCount={notificationsCount}>
      {children}
    </DashboardShell>
  );
}
