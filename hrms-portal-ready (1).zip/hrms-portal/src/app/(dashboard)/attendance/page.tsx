import { Suspense } from "react";
import { getSession } from "@/lib/auth";
import { redirect } from "next/navigation";
import { AttendanceView } from "@/components/attendance/attendance-view";

export default async function AttendancePage() {
  const user = await getSession();
  if (!user) redirect("/login");

  return (
    <div className="space-y-6 animate-fade-in-up">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Attendance</h1>
        <p className="text-muted-foreground mt-1">Track your attendance and check-in/out</p>
      </div>
      <Suspense fallback={<div>Loading...</div>}>
        <AttendanceView user={user} />
      </Suspense>
    </div>
  );
}
