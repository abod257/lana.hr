"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Mail, Shield, Globe, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { z } from "zod";
import { useLocale } from "@/components/locale-provider";

const forgotSchema = z.object({
  email: z.string().email("Invalid email"),
});

type ForgotInput = z.infer<typeof forgotSchema>;

export default function ForgotPasswordPage() {
  const router = useRouter();
  const { locale, setLocale, t } = useLocale();
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<ForgotInput>({
    resolver: zodResolver(forgotSchema),
  });

  const onSubmit = async (data: ForgotInput) => {
    try {
      const res = await fetch("/api/auth/forgot-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      const result = await res.json();
      if (result.success) {
        toast.success(locale === "ar" ? "تم إرسال رابط إعادة التعيين" : "Reset link sent");
        router.push("/login");
      } else {
        toast.error(result.message);
      }
    } catch {
      toast.error(locale === "ar" ? "حدث خطأ" : "Error occurred");
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center relative bg-gradient-to-br from-background via-background to-accent/30 p-4">
      <div className="absolute inset-0 gradient-bg" />
      <div className="absolute top-4 end-4">
        <Button variant="ghost" size="sm" onClick={() => setLocale(locale === "ar" ? "en" : "ar")} className="gap-2">
          <Globe className="h-4 w-4" />
          {locale === "ar" ? "English" : "العربية"}
        </Button>
      </div>

      <div className="relative z-10 w-full max-w-md glass rounded-2xl p-8 shadow-glass-lg">
        <div className="flex flex-col items-center mb-6">
          <div className="h-14 w-14 rounded-2xl gradient-primary flex items-center justify-center shadow-lg mb-4">
            <Shield className="h-7 w-7 text-white" />
          </div>
          <h1 className="text-xl font-bold">{t("auth.resetPassword")}</h1>
          <p className="text-sm text-muted-foreground mt-1 text-center">
            {locale === "ar" ? "أدخل بريدك الإلكتروني لإعادة تعيين كلمة المرور" : "Enter your email to reset your password"}
          </p>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div>
            <Label>{t("auth.email")}</Label>
            <Input type="email" placeholder="name@company.com" startIcon={<Mail className="h-4 w-4" />} {...register("email")} />
            {errors.email?.message && <p className="text-xs text-destructive mt-1">{errors.email.message}</p>}
          </div>
          <Button type="submit" className="w-full" loading={isSubmitting}>
            {t("auth.sendResetLink")}
          </Button>
          <Link href="/login">
            <Button variant="ghost" className="w-full gap-2">
              <ArrowLeft className="h-4 w-4 rtl:rotate-180" />
              {locale === "ar" ? "العودة لتسجيل الدخول" : "Back to login"}
            </Button>
          </Link>
        </form>
      </div>
    </div>
  );
}
