"use client";

import * as React from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar, Plus, CheckCircle2, XCircle, Clock, AlertCircle, FileText } from "lucide-react";
import { toast } from "sonner";
import type { AuthUser } from "@/lib/auth";
import { differenceInDays, format } from "date-fns";

interface LeaveRequest {
  id: string;
  requestNumber: string;
  leaveType: string;
  startDate: string;
  endDate: string;
  days: number;
  reason: string;
  status: string;
  createdAt: string;
  employee?: { firstNameEn: string; lastNameEn: string; employeeCode: string };
}

const LEAVE_TYPES = [
  { value: "ANNUAL", label: "Annual Leave" },
  { value: "SICK", label: "Sick Leave" },
  { value: "EMERGENCY", label: "Emergency" },
  { value: "MATERNITY", label: "Maternity" },
  { value: "PATERNITY", label: "Paternity" },
  { value: "BEREAVEMENT", label: "Bereavement" },
  { value: "UNPAID", label: "Unpaid" },
  { value: "HAJJ", label: "Hajj" },
  { value: "MARRIAGE", label: "Marriage" },
  { value: "STUDY", label: "Study" },
  { value: "COMPENSATORY", label: "Compensatory" },
];

export function LeaveRequests({ user }: { user: AuthUser }) {
  const [requests, setRequests] = React.useState<LeaveRequest[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [filter, setFilter] = React.useState<string>("all");
  const [dialogOpen, setDialogOpen] = React.useState(false);
  const [submitting, setSubmitting] = React.useState(false);

  const [form, setForm] = React.useState({
    leaveType: "ANNUAL",
    startDate: "",
    endDate: "",
    reason: "",
  });

  const fetchRequests = React.useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/leave${filter !== "all" ? `?status=${filter}` : ""}`);
      const data = await res.json();
      if (data.success) {
        setRequests(data.data || []);
      }
    } catch (e) {
      toast.error("Failed to load requests");
    } finally {
      setLoading(false);
    }
  }, [filter]);

  React.useEffect(() => {
    fetchRequests();
  }, [fetchRequests]);

  const handleSubmit = async () => {
    if (!form.startDate || !form.endDate || !form.reason) {
      toast.error("Please fill all fields");
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch("/api/leave", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (data.success) {
        toast.success("Leave request submitted");
        setDialogOpen(false);
        setForm({ leaveType: "ANNUAL", startDate: "", endDate: "", reason: "" });
        fetchRequests();
      } else {
        toast.error(data.message || "Submission failed");
      }
    } catch {
      toast.error("Error");
    } finally {
      setSubmitting(false);
    }
  };

  const getStatusVariant = (status: string) => {
    switch (status) {
      case "APPROVED": return "success" as const;
      case "REJECTED": return "destructive" as const;
      case "PENDING": return "warning" as const;
      default: return "secondary" as const;
    }
  };

  const statusCounts = {
    all: requests.length,
    PENDING: requests.filter(r => r.status === "PENDING").length,
    APPROVED: requests.filter(r => r.status === "APPROVED").length,
    REJECTED: requests.filter(r => r.status === "REJECTED").length,
  };

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Annual Balance</p>
                <p className="text-2xl font-bold">{user.employee?.annualLeaveBalance ?? 21}</p>
              </div>
              <Calendar className="h-8 w-8 text-primary opacity-80" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Pending</p>
                <p className="text-2xl font-bold">{statusCounts.PENDING}</p>
              </div>
              <Clock className="h-8 w-8 text-warning opacity-80" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Approved</p>
                <p className="text-2xl font-bold">{statusCounts.APPROVED}</p>
              </div>
              <CheckCircle2 className="h-8 w-8 text-success opacity-80" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Requests</p>
                <p className="text-2xl font-bold">{statusCounts.all}</p>
              </div>
              <FileText className="h-8 w-8 text-info opacity-80" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tabs */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Leave Requests</CardTitle>
              <CardDescription>View and manage your leave applications</CardDescription>
            </div>
            <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
              <DialogTrigger asChild>
                <Button className="gap-2">
                  <Plus className="h-4 w-4" />
                  New Request
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-lg">
                <DialogHeader>
                  <DialogTitle>New Leave Request</DialogTitle>
                  <DialogDescription>Submit a new leave application</DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label>Leave Type</Label>
                    <Select value={form.leaveType} onValueChange={(v) => setForm({ ...form, leaveType: v })}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {LEAVE_TYPES.map((t) => (
                          <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Start Date</Label>
                      <Input
                        type="date"
                        value={form.startDate}
                        onChange={(e) => setForm({ ...form, startDate: e.target.value })}
                      />
                    </div>
                    <div>
                      <Label>End Date</Label>
                      <Input
                        type="date"
                        value={form.endDate}
                        onChange={(e) => setForm({ ...form, endDate: e.target.value })}
                      />
                    </div>
                  </div>
                  <div>
                    <Label>Reason</Label>
                    <Textarea
                      placeholder="Please provide a reason for your leave..."
                      value={form.reason}
                      onChange={(e) => setForm({ ...form, reason: e.target.value })}
                      rows={4}
                    />
                  </div>
                  {form.startDate && form.endDate && (
                    <div className="p-3 bg-accent rounded-lg text-sm">
                      <strong>{differenceInDays(new Date(form.endDate), new Date(form.startDate)) + 1}</strong> days requested
                    </div>
                  )}
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
                  <Button onClick={handleSubmit} loading={submitting}>Submit Request</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs value={filter} onValueChange={setFilter}>
            <TabsList>
              <TabsTrigger value="all">All ({statusCounts.all})</TabsTrigger>
              <TabsTrigger value="PENDING">Pending ({statusCounts.PENDING})</TabsTrigger>
              <TabsTrigger value="APPROVED">Approved ({statusCounts.APPROVED})</TabsTrigger>
              <TabsTrigger value="REJECTED">Rejected ({statusCounts.REJECTED})</TabsTrigger>
            </TabsList>

            <TabsContent value={filter} className="mt-4">
              {loading ? (
                <div className="text-center py-12 text-muted-foreground">Loading...</div>
              ) : requests.length === 0 ? (
                <div className="text-center py-12">
                  <Calendar className="h-12 w-12 mx-auto text-muted-foreground/50 mb-3" />
                  <p className="text-muted-foreground">No leave requests</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {requests.map((req) => (
                    <Card key={req.id} className="hover:shadow-md transition-shadow">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <Badge variant="outline">{req.requestNumber}</Badge>
                              <Badge variant={getStatusVariant(req.status)}>{req.status}</Badge>
                              <Badge variant="secondary">{req.leaveType}</Badge>
                            </div>
                            <div className="flex items-center gap-4 text-sm text-muted-foreground mb-2">
                              <span>📅 {format(new Date(req.startDate), "MMM dd")} → {format(new Date(req.endDate), "MMM dd, yyyy")}</span>
                              <span>📆 {req.days} days</span>
                            </div>
                            <p className="text-sm">{req.reason}</p>
                            {req.employee && (
                              <p className="text-xs text-muted-foreground mt-2">
                                By: {req.employee.firstNameEn} {req.employee.lastNameEn} ({req.employee.employeeCode})
                              </p>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
