import { NextResponse } from "next/server";
import { checkDatabaseHealth } from "@/lib/prisma";

export async function GET() {
  try {
    const dbHealthy = await checkDatabaseHealth();
    return NextResponse.json({
      success: true,
      status: "healthy",
      timestamp: new Date().toISOString(),
      services: {
        database: dbHealthy ? "up" : "down",
        api: "up",
      },
    });
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        status: "unhealthy",
        error: "Service unavailable",
      },
      { status: 503 }
    );
  }
}
