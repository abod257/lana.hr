import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth } from "@/lib/auth";
import { ApiResponse, handleApiError } from "@/lib/api-response";
import { createAuditLog, getClientInfo } from "@/lib/audit";
import { checkOutSchema } from "@/lib/validations";

export async function POST(request: NextRequest) {
  try {
    const user = await requireAuth();
    if (!user.employee) {
      return ApiResponse.badRequest("User is not linked to an employee record");
    }

    const body = await request.json().catch(() => ({}));
    const validated = checkOutSchema.parse(body);
    const { ipAddress, userAgent } = getClientInfo(request);

    const today = startOfDay(new Date());
    const now = new Date();

    const existing = await prisma.attendance.findUnique({
      where: {
        employeeId_date: {
          employeeId: user.employee.id,
          date: today,
        },
      },
    });

    if (!existing || !existing.checkIn) {
      return ApiResponse.badRequest("Must check in first");
    }

    if (existing.checkOut) {
      return ApiResponse.badRequest("Already checked out");
    }

    // Calculate worked hours
    const workedHours = ((now.getTime() - existing.checkIn.getTime()) / (1000 * 60 * 60)).toFixed(2);

    // Calculate early leave (assuming 5:00 PM end)
    const endTime = new Date(today);
    endTime.setHours(17, 0, 0, 0);
    const earlyLeaveMinutes = Math.max(0, differenceInMinutes(endTime, now));
    const isEarlyLeave = earlyLeaveMinutes > 30; // 30 min grace

    const attendance = await prisma.attendance.update({
      where: { id: existing.id },
      data: {
        checkOut: now,
        workedHours: parseFloat(workedHours),
        earlyLeaveMinutes,
        isEarlyLeave,
        notes: validated.notes,
      },
    });

    await createAuditLog({
      userId: user.id,
      action: "CHECK_OUT",
      resource: "Attendance",
      resourceId: attendance.id,
      description: `Checked out. Worked: ${workedHours} hours`,
      ipAddress,
      userAgent,
    });

    return ApiResponse.success({
      ...attendance,
      message: `Checked out. Worked ${workedHours} hours`,
    });
  } catch (error) {
    return handleApiError(error);
  }
}

function startOfDay(date: Date): Date {
  const d = new Date(date);
  d.setHours(0, 0, 0, 0);
  return d;
}

function differenceInMinutes(later: Date, earlier: Date): number {
  return Math.floor((later.getTime() - earlier.getTime()) / (1000 * 60));
}
