import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { login } from "@/lib/auth";
import { createAuditLog, getClientInfo } from "@/lib/audit";
import { ApiResponse, handleApiError } from "@/lib/api-response";
import { loginSchema } from "@/lib/validations";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const validated = loginSchema.parse(body);
    const { ipAddress, userAgent } = getClientInfo(request);

    const result = await login(validated.email, validated.password, ipAddress, userAgent);

    if (!result.success) {
      await createAuditLog({
        action: "LOGIN_FAILED",
        resource: "Authentication",
        description: `Failed login attempt for email: ${validated.email}`,
        ipAddress,
        userAgent,
        status: "FAILURE",
        errorMessage: result.message,
      });
      return ApiResponse.unauthorized(result.message);
    }

    return ApiResponse.success({
      user: {
        id: result.user!.id,
        email: result.user!.email,
        role: result.user!.role,
        employee: result.user!.employee,
      },
    });
  } catch (error) {
    return handleApiError(error);
  }
}
