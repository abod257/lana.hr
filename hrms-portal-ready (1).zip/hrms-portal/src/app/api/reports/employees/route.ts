import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth, hasPermission } from "@/lib/auth";
import { ApiResponse, handleApiError } from "@/lib/api-response";

export async function GET(request: NextRequest) {
  try {
    const user = await requireAuth();
    if (!hasPermission(user, "reports.view")) {
      return ApiResponse.forbidden();
    }

    const [byDepartment, byStatus, byGender, byNationality, total] = await Promise.all([
      prisma.employee.groupBy({
        by: ["departmentId"],
        where: { deletedAt: null },
        _count: true,
      }),
      prisma.employee.groupBy({
        by: ["status"],
        where: { deletedAt: null },
        _count: true,
      }),
      prisma.employee.groupBy({
        by: ["gender"],
        where: { deletedAt: null },
        _count: true,
      }),
      prisma.employee.groupBy({
        by: ["nationality"],
        where: { deletedAt: null, nationality: { not: null } },
        _count: true,
      }),
      prisma.employee.count({ where: { deletedAt: null } }),
    ]);

    // Get department names
    const departments = await prisma.department.findMany({
      select: { id: true, nameEn: true, nameAr: true },
    });
    const deptMap = new Map(departments.map((d) => [d.id, d]));

    return ApiResponse.success({
      total,
      byDepartment: byDepartment.map((b) => ({
        ...b,
        department: deptMap.get(b.departmentId),
      })),
      byStatus,
      byGender,
      byNationality,
    });
  } catch (error) {
    return handleApiError(error);
  }
}
