import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth, hasPermission } from "@/lib/auth";
import { ApiResponse, handleApiError } from "@/lib/api-response";
import { createAuditLog, getClientInfo } from "@/lib/audit";
import { approveLeaveSchema } from "@/lib/validations";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await requireAuth();
    if (!hasPermission(user, "leave.approve")) {
      return ApiResponse.forbidden();
    }

    const { id } = await params;
    const body = await request.json();
    const validated = approveLeaveSchema.parse(body);
    const { ipAddress, userAgent } = getClientInfo(request);

    const leaveRequest = await prisma.leaveRequest.findUnique({
      where: { id },
      include: { employee: { include: { user: true } } },
    });

    if (!leaveRequest) return ApiResponse.notFound();
    if (leaveRequest.status !== "PENDING") {
      return ApiResponse.badRequest("Request is not pending");
    }

    const updated = await prisma.leaveRequest.update({
      where: { id },
      data: {
        status: validated.status,
        approvedById: user.id,
        approvedAt: new Date(),
        rejectionReason: validated.rejectionReason,
      },
    });

    // Update leave balance
    if (validated.status === "APPROVED" && leaveRequest.leaveType === "ANNUAL") {
      await prisma.employee.update({
        where: { id: leaveRequest.employeeId },
        data: {
          annualLeaveBalance: {
            decrement: leaveRequest.days,
          },
        },
      });
    }

    // Send notification
    await prisma.notification.create({
      data: {
        userId: leaveRequest.employee.user.id,
        type: validated.status === "APPROVED" ? "LEAVE_APPROVED" : "LEAVE_REJECTED",
        titleAr: validated.status === "APPROVED" ? "تمت الموافقة على إجازتك" : "تم رفض طلب إجازتك",
        titleEn: validated.status === "APPROVED" ? "Leave Approved" : "Leave Rejected",
        messageAr: validated.status === "APPROVED"
          ? `تمت الموافقة على طلب إجازتك (${leaveRequest.days} أيام)`
          : `تم رفض طلب إجازتك: ${validated.rejectionReason || ""}`,
        messageEn: validated.status === "APPROVED"
          ? `Your leave request has been approved (${leaveRequest.days} days)`
          : `Your leave request was rejected: ${validated.rejectionReason || ""}`,
        link: `/leave`,
        relatedEntity: "LeaveRequest",
        relatedId: leaveRequest.id,
        priority: "HIGH",
      },
    });

    await createAuditLog({
      userId: user.id,
      action: validated.status === "APPROVED" ? "APPROVE" : "REJECT",
      resource: "LeaveRequest",
      resourceId: id,
      description: `${validated.status} leave request`,
      ipAddress,
      userAgent,
    });

    return ApiResponse.success(updated);
  } catch (error) {
    return handleApiError(error);
  }
}
