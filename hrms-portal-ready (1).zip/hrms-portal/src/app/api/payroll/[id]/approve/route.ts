import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth, hasPermission } from "@/lib/auth";
import { ApiResponse, handleApiError } from "@/lib/api-response";
import { createAuditLog, getClientInfo } from "@/lib/audit";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await requireAuth();
    if (!hasPermission(user, "payroll.approve")) {
      return ApiResponse.forbidden();
    }

    const { id } = await params;
    const { ipAddress, userAgent } = getClientInfo(request);

    const payroll = await prisma.payroll.findUnique({
      where: { id },
      include: { payslips: true },
    });
    if (!payroll) return ApiResponse.notFound();
    if (payroll.status !== "PROCESSING") {
      return ApiResponse.badRequest("Payroll must be in processing status");
    }

    await prisma.payroll.update({
      where: { id },
      data: {
        status: "APPROVED",
        approvedById: user.id,
        approvedAt: new Date(),
      },
    });

    // Update all payslips
    await prisma.payslip.updateMany({
      where: { payrollId: id },
      data: { status: "APPROVED" },
    });

    // Notify all employees
    for (const payslip of payroll.payslips) {
      const employee = await prisma.employee.findUnique({
        where: { id: payslip.employeeId },
        include: { user: true },
      });
      if (employee) {
        await prisma.notification.create({
          data: {
            userId: employee.user.id,
            type: "PAYROLL",
            titleAr: "كشف راتب جديد",
            titleEn: "New Payslip Available",
            messageAr: `كشف راتب ${payroll.period} متاح الآن`,
            messageEn: `Your payslip for ${payroll.period} is now available`,
            link: `/payroll/payslips`,
            relatedEntity: "Payslip",
            relatedId: payslip.id,
            priority: "NORMAL",
          },
        });
      }
    }

    await createAuditLog({
      userId: user.id,
      action: "APPROVE_PAYROLL",
      resource: "Payroll",
      resourceId: id,
      description: `Approved payroll for ${payroll.period}`,
      ipAddress,
      userAgent,
    });

    return ApiResponse.success({ message: "Payroll approved successfully" });
  } catch (error) {
    return handleApiError(error);
  }
}
