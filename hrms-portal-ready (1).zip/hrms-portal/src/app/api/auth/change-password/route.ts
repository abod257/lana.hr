import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { hashPassword, verifyPassword, requireAuth } from "@/lib/auth";
import { ApiResponse, handleApiError } from "@/lib/api-response";
import { createAuditLog, getClientInfo } from "@/lib/audit";
import { changePasswordSchema } from "@/lib/validations";

export async function POST(request: NextRequest) {
  try {
    const user = await requireAuth();
    const body = await request.json();
    const validated = changePasswordSchema.parse(body);
    const { ipAddress, userAgent } = getClientInfo(request);

    const dbUser = await prisma.user.findUnique({ where: { id: user.id } });
    if (!dbUser) return ApiResponse.notFound();

    const valid = await verifyPassword(validated.currentPassword, dbUser.passwordHash);
    if (!valid) {
      return ApiResponse.badRequest("Current password is incorrect");
    }

    const newHash = await hashPassword(validated.newPassword);
    await prisma.user.update({
      where: { id: user.id },
      data: { passwordHash: newHash },
    });

    // Invalidate all other sessions
    await prisma.session.deleteMany({
      where: { userId: user.id, NOT: { userId: user.id } },
    });

    await createAuditLog({
      userId: user.id,
      action: "PASSWORD_CHANGE",
      resource: "Authentication",
      description: "Password changed successfully",
      ipAddress,
      userAgent,
    });

    return ApiResponse.success({ message: "Password changed successfully" });
  } catch (error) {
    return handleApiError(error);
  }
}
