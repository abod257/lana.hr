import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth, hasPermission } from "@/lib/auth";
import { ApiResponse, handleApiError } from "@/lib/api-response";

export async function GET(request: NextRequest) {
  try {
    const user = await requireAuth();
    if (!hasPermission(user, "reports.view")) {
      return ApiResponse.forbidden();
    }

    const year = parseInt(new URL(request.url).searchParams.get("year") || new Date().getFullYear().toString());

    const payrolls = await prisma.payroll.findMany({
      where: {
        period: {
          startsWith: year.toString(),
        },
      },
      include: { payslips: true },
      orderBy: { period: "asc" },
    });

    return ApiResponse.success({
      year,
      totalPayrolls: payrolls.length,
      totalEarnings: payrolls.reduce((s, p) => s + parseFloat(p.totalEarnings.toString()), 0),
      totalDeductions: payrolls.reduce((s, p) => s + parseFloat(p.totalDeductions.toString()), 0),
      totalNetPay: payrolls.reduce((s, p) => s + parseFloat(p.totalNetPay.toString()), 0),
      byMonth: payrolls.map((p) => ({
        period: p.period,
        earnings: parseFloat(p.totalEarnings.toString()),
        deductions: parseFloat(p.totalDeductions.toString()),
        netPay: parseFloat(p.totalNetPay.toString()),
        employees: p.totalEmployees,
        status: p.status,
      })),
    });
  } catch (error) {
    return handleApiError(error);
  }
}
