"use client";

import * as React from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { History, Search, CheckCircle2, XCircle } from "lucide-react";
import { toast } from "sonner";
import { getRelativeTime } from "@/lib/utils";

export function AuditView() {
  const [logs, setLogs] = React.useState<any[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [search, setSearch] = React.useState("");

  React.useEffect(() => {
    const fetchLogs = async () => {
      try {
        const res = await fetch("/api/audit?pageSize=50");
        const data = await res.json();
        if (data.success) setLogs(data.data || []);
      } catch {} finally {
        setLoading(false);
      }
    };
    fetchLogs();
  }, []);

  const filtered = logs.filter((l) =>
    !search ||
    l.action?.includes(search.toUpperCase()) ||
    l.resource?.includes(search) ||
    l.description?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <History className="h-5 w-5" />
          Audit Trail
        </CardTitle>
        <CardDescription>Complete activity log for security and compliance</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="relative mb-4">
          <Search className="absolute start-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search logs..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="ps-10"
          />
        </div>

        {loading ? (
          <div className="text-center py-12">Loading...</div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-12">
            <History className="h-12 w-12 mx-auto text-muted-foreground/50 mb-3" />
            <p className="text-muted-foreground">No audit logs</p>
          </div>
        ) : (
          <div className="space-y-2">
            {filtered.map((log) => (
              <div key={log.id} className="flex items-start gap-3 p-3 rounded-lg border hover:bg-accent transition-colors">
                <div className={`mt-1 h-2 w-2 rounded-full ${log.status === "SUCCESS" ? "bg-success" : "bg-destructive"}`} />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <Badge variant="outline">{log.action}</Badge>
                    <Badge variant="secondary">{log.resource}</Badge>
                    {log.status === "FAILURE" && <Badge variant="destructive">Failed</Badge>}
                  </div>
                  <p className="text-sm">{log.description || `${log.action} on ${log.resource}`}</p>
                  <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                    <span>{log.user?.email || "System"}</span>
                    <span>•</span>
                    <span>{getRelativeTime(log.createdAt, "en")}</span>
                    {log.ipAddress && (<><span>•</span><span>{log.ipAddress}</span></>)}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
