import { getSession, hasPermission } from "@/lib/auth";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Briefcase, Plus, Users } from "lucide-react";

export default async function PositionsPage() {
  const user = await getSession();
  if (!user) redirect("/login");

  const positions = await prisma.position.findMany({
    where: { isActive: true },
    include: {
      department: true,
      _count: { select: { employees: true } },
    },
    orderBy: { titleEn: "asc" },
  }).catch(() => []);

  const canManage = hasPermission(user, "positions.manage");

  return (
    <div className="space-y-6 animate-fade-in-up">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Positions</h1>
          <p className="text-muted-foreground mt-1">Job titles and roles</p>
        </div>
        {canManage && (
          <Button className="gap-2">
            <Plus className="h-4 w-4" />
            Add Position
          </Button>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {positions.map((pos) => (
          <Card key={pos.id} className="card-hover">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="h-12 w-12 rounded-xl bg-gradient-to-br from-info to-info/60 flex items-center justify-center">
                  <Briefcase className="h-6 w-6 text-white" />
                </div>
                <Badge variant="outline">Level {pos.level}</Badge>
              </div>
              <CardTitle className="mt-3">{pos.titleEn}</CardTitle>
              <CardDescription>{pos.department.nameEn}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Users className="h-4 w-4" />
                  {pos._count.employees} holders
                </div>
                <div className="text-xs text-muted-foreground">{pos.code}</div>
              </div>
              {pos.minSalary && pos.maxSalary && (
                <p className="text-xs text-muted-foreground mt-2">
                  Range: {parseFloat(pos.minSalary.toString()).toLocaleString()} - {parseFloat(pos.maxSalary.toString()).toLocaleString()} SAR
                </p>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
