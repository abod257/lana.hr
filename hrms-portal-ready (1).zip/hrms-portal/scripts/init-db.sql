-- =====================================================
-- HRMS Portal - Database Initialization Script
-- =====================================================

-- Create extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "citext";

-- Create indexes for common queries
-- (Prisma will auto-generate most, this is for additional performance)

-- Full-text search indexes
CREATE INDEX IF NOT EXISTS idx_employees_search ON employees
  USING GIN (
    to_tsvector('simple',
      COALESCE(first_name_en, '') || ' ' ||
      COALESCE(last_name_en, '') || ' ' ||
      COALESCE(first_name_ar, '') || ' ' ||
      COALESCE(last_name_ar, '') || ' ' ||
      COALESCE(employee_code, '') || ' ' ||
      COALESCE(email, '')
    )
  );

CREATE INDEX IF NOT EXISTS idx_jobs_search ON job_openings
  USING GIN (
    to_tsvector('simple',
      COALESCE(title_en, '') || ' ' ||
      COALESCE(title_ar, '') || ' ' ||
      COALESCE(description, '')
    )
  );

-- Audit log partitioning (optional, for high-volume production)
-- This example shows monthly partitioning for audit_logs
-- CREATE TABLE audit_logs_2026_01 PARTITION OF audit_logs
--   FOR VALUES FROM ('2026-01-01') TO ('2026-02-01');

-- Grant privileges (adjust role name as needed)
-- GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO hrms_user;
-- GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO hrms_user;
