#!/bin/bash

# Generate secure secrets for production deployment
echo "🔐 Generating secure secrets..."
echo ""

JWT_SECRET=$(openssl rand -base64 32)
JWT_REFRESH_SECRET=$(openssl rand -base64 32)
SESSION_SECRET=$(openssl rand -base64 32)
ENCRYPTION_KEY=$(openssl rand -hex 16)

cat <<EOF

Copy these values to your .env file:

# JWT Authentication
JWT_SECRET="$JWT_SECRET"
JWT_REFRESH_SECRET="$JWT_REFRESH_SECRET"

# Session
SESSION_SECRET="$SESSION_SECRET"

# Encryption
ENCRYPTION_KEY="$ENCRYPTION_KEY"

EOF

echo "✅ Done! Keep these values secret and never commit to git."
