import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth } from "@/lib/auth";
import { ApiResponse, handleApiError } from "@/lib/api-response";

export async function GET(request: NextRequest) {
  try {
    const user = await requireAuth();
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get("page") || "1");
    const pageSize = parseInt(searchParams.get("pageSize") || "10");

    if (!user.employee) {
      return ApiResponse.badRequest("User is not linked to an employee");
    }

    const [payslips, total] = await Promise.all([
      prisma.payslip.findMany({
        where: { employeeId: user.employee.id },
        orderBy: { createdAt: "desc" },
        skip: (page - 1) * pageSize,
        take: pageSize,
      }),
      prisma.payslip.count({ where: { employeeId: user.employee.id } }),
    ]);

    return ApiResponse.paginated(payslips, total, page, pageSize);
  } catch (error) {
    return handleApiError(error);
  }
}
