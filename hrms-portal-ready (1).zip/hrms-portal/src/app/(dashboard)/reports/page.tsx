import { ReportsView } from "@/components/reports/reports-view";

export default function ReportsPage() {
  return (
    <div className="space-y-6 animate-fade-in-up">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Reports</h1>
        <p className="text-muted-foreground mt-1">Generate and export HR analytics reports</p>
      </div>
      <ReportsView />
    </div>
  );
}
