#!/bin/bash

# =====================================================
# HRMS Portal - Quick Start Script
# =====================================================

set -e

echo "🚀 HRMS Portal - Quick Start"
echo ""

# Check Node.js
if ! command -v node >/dev/null 2>&1; then
  echo "❌ Node.js is required. Please install Node.js 20+ from https://nodejs.org"
  exit 1
fi

# Check PostgreSQL
if ! command -v psql >/dev/null 2>&1; then
  echo "⚠️  PostgreSQL not detected. You'll need to set up a PostgreSQL database."
  echo "    Options:"
  echo "    - Local: Install PostgreSQL from https://www.postgresql.org"
  echo "    - Cloud: Use Neon, Supabase, Vercel Postgres, or Railway"
  echo ""
  read -p "Press Enter to continue..."
fi

# Install dependencies
echo "📦 Installing dependencies..."
npm install

# Create .env if not exists
if [ ! -f .env ]; then
  echo "📝 Creating .env from .env.example..."
  cp .env.example .env

  # Generate secure secrets
  JWT_SECRET=$(openssl rand -base64 32 2>/dev/null || cat /dev/urandom | tr -dc 'a-zA-Z0-9' | fold -w 32 | head -n 1)
  JWT_REFRESH_SECRET=$(openssl rand -base64 32 2>/dev/null || cat /dev/urandom | tr -dc 'a-zA-Z0-9' | fold -w 32 | head -n 1)
  SESSION_SECRET=$(openssl rand -base64 32 2>/dev/null || cat /dev/urandom | tr -dc 'a-zA-Z0-9' | fold -w 32 | head -n 1)
  ENCRYPTION_KEY=$(openssl rand -hex 16 2>/dev/null || cat /dev/urandom | tr -dc 'a-f0-9' | fold -w 32 | head -n 1)

  # Update .env
  sed -i "s|JWT_SECRET=.*|JWT_SECRET=\"$JWT_SECRET\"|" .env
  sed -i "s|JWT_REFRESH_SECRET=.*|JWT_REFRESH_SECRET=\"$JWT_REFRESH_SECRET\"|" .env
  sed -i "s|SESSION_SECRET=.*|SESSION_SECRET=\"$SESSION_SECRET\"|" .env
  sed -i "s|ENCRYPTION_KEY=.*|ENCRYPTION_KEY=\"$ENCRYPTION_KEY\"|" .env

  echo "✓ Secure secrets generated"
fi

# Generate Prisma client
echo "🔧 Generating Prisma client..."
npm run db:generate

# Push schema to database (simpler than migrations for quick start)
echo "🗄️  Setting up database schema..."
npm run db:push || {
  echo "❌ Database setup failed. Please check your DATABASE_URL in .env"
  exit 1
}

# Seed database
echo "🌱 Seeding database with sample data..."
npm run db:seed || echo "⚠️  Seeding failed (you can run 'npm run db:seed' later)"

echo ""
echo "✅ Setup complete!"
echo ""
echo "🚀 Start the development server:"
echo "   npm run dev"
echo ""
echo "Then visit http://localhost:3000"
echo ""
echo "🔑 Login credentials:"
echo "   Admin:    admin@company.com    / Admin@123456"
echo "   Employee: ahmed.mohammed@company.com / Demo@123456"
