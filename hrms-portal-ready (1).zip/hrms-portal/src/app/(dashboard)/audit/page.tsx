import { AuditView } from "@/components/audit/audit-view";

export default function AuditPage() {
  return (
    <div className="space-y-6 animate-fade-in-up">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Audit Logs</h1>
        <p className="text-muted-foreground mt-1">System activity tracking and security logs</p>
      </div>
      <AuditView />
    </div>
  );
}
