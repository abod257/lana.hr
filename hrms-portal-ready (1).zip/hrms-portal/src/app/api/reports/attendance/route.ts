import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth, hasPermission } from "@/lib/auth";
import { ApiResponse, handleApiError } from "@/lib/api-response";

export async function GET(request: NextRequest) {
  try {
    const user = await requireAuth();
    if (!hasPermission(user, "reports.view")) {
      return ApiResponse.forbidden();
    }

    const { searchParams } = new URL(request.url);
    const startDate = searchParams.get("startDate") || new Date(new Date().setDate(new Date().getDate() - 30)).toISOString();
    const endDate = searchParams.get("endDate") || new Date().toISOString();

    const attendances = await prisma.attendance.findMany({
      where: {
        date: {
          gte: new Date(startDate),
          lte: new Date(endDate),
        },
      },
      select: {
        status: true,
        workedHours: true,
        overtimeHours: true,
        lateMinutes: true,
        date: true,
        employeeId: true,
      },
    });

    // Aggregate
    const summary = {
      totalDays: attendances.length,
      present: attendances.filter((a) => a.status === "PRESENT").length,
      late: attendances.filter((a) => a.status === "LATE").length,
      absent: attendances.filter((a) => a.status === "ABSENT").length,
      onLeave: attendances.filter((a) => a.status === "ON_LEAVE").length,
      totalWorkedHours: attendances.reduce((s, a) => s + parseFloat((a.workedHours || 0).toString()), 0),
      totalOvertimeHours: attendances.reduce((s, a) => s + parseFloat((a.overtimeHours || 0).toString()), 0),
      averageLateMinutes: attendances.filter((a) => a.lateMinutes > 0).reduce((s, a) => s + a.lateMinutes, 0) / Math.max(1, attendances.filter((a) => a.lateMinutes > 0).length),
    };

    return ApiResponse.success({ summary, period: { startDate, endDate } });
  } catch (error) {
    return handleApiError(error);
  }
}
