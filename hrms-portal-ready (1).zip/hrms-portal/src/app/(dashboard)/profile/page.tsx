import { Suspense } from "react";
import { getSession } from "@/lib/auth";
import { redirect } from "next/navigation";
import { ProfileView } from "@/components/profile/profile-view";

export default async function ProfilePage() {
  const user = await getSession();
  if (!user) redirect("/login");

  return (
    <div className="space-y-6 animate-fade-in-up">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">My Profile</h1>
        <p className="text-muted-foreground mt-1">View and update your personal information</p>
      </div>
      <Suspense fallback={<div>Loading...</div>}>
        <ProfileView user={user} />
      </Suspense>
    </div>
  );
}
