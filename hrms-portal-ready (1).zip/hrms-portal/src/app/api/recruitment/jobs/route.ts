import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth, hasPermission } from "@/lib/auth";
import { ApiResponse, handleApiError } from "@/lib/api-response";
import { createAuditLog, getClientInfo } from "@/lib/audit";
import { jobOpeningSchema } from "@/lib/validations";

export async function GET(request: NextRequest) {
  try {
    const user = await requireAuth();
    const { searchParams } = new URL(request.url);
    const status = searchParams.get("status");
    const page = parseInt(searchParams.get("page") || "1");
    const pageSize = parseInt(searchParams.get("pageSize") || "10");

    const where: any = {};
    if (status) where.status = status;
    if (searchParams.get("departmentId")) where.departmentId = searchParams.get("departmentId");

    const [jobs, total] = await Promise.all([
      prisma.jobOpening.findMany({
        where,
        include: {
          _count: { select: { candidates: true } },
        },
        orderBy: { createdAt: "desc" },
        skip: (page - 1) * pageSize,
        take: pageSize,
      }),
      prisma.jobOpening.count({ where }),
    ]);

    // Fetch departments separately
    const deptIds = jobs.map((j) => j.departmentId);
    const depts = await prisma.department.findMany({
      where: { id: { in: deptIds } },
      select: { id: true, nameEn: true, nameAr: true },
    });
    const deptMap = new Map(depts.map((d) => [d.id, d]));
    const jobsWithDept = jobs.map((j) => ({ ...j, department: deptMap.get(j.departmentId) }));

    return ApiResponse.paginated(jobsWithDept, total, page, pageSize);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await requireAuth();
    if (!hasPermission(user, "recruitment.manage")) {
      return ApiResponse.forbidden();
    }

    const body = await request.json();
    const validated = jobOpeningSchema.parse(body);
    const { ipAddress, userAgent } = getClientInfo(request);

    const job = await prisma.jobOpening.create({
      data: {
        ...validated,
        postedDate: validated.status === "OPEN" ? new Date() : null,
        closingDate: validated.closingDate ? new Date(validated.closingDate) : null,
        postedById: user.id,
      },
    });

    await createAuditLog({
      userId: user.id,
      action: "CREATE",
      resource: "JobOpening",
      resourceId: job.id,
      description: `Created job opening: ${validated.titleEn}`,
      ipAddress,
      userAgent,
    });

    return ApiResponse.created(job, "Job opening created");
  } catch (error) {
    return handleApiError(error);
  }
}
