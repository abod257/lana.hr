import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth, hasPermission } from "@/lib/auth";
import { ApiResponse, handleApiError } from "@/lib/api-response";
import { createAuditLog, getClientInfo } from "@/lib/audit";
import { updateEmployeeSchema } from "@/lib/validations";

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await requireAuth();
    const { id } = await params;

    const employee = await prisma.employee.findUnique({
      where: { id },
      include: {
        user: { select: { id: true, email: true, status: true, role: true } },
        department: true,
        position: true,
        manager: { select: { id: true, firstNameEn: true, lastNameEn: true, firstNameAr: true, lastNameAr: true } },
        subordinates: { select: { id: true, firstNameEn: true, lastNameEn: true, firstNameAr: true, lastNameAr: true, employeeCode: true } },
        contracts: { orderBy: { createdAt: "desc" } },
      },
    });

    if (!employee) {
      return ApiResponse.notFound("Employee not found");
    }

    // Authorization check
    const canView = hasPermission(user, "employees.view") ||
      user.employee?.id === id ||
      (user.role.name === "MANAGER" && employee.managerId === user.employee?.id);

    if (!canView) {
      return ApiResponse.forbidden("You don't have permission to view this employee");
    }

    return ApiResponse.success(employee);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await requireAuth();
    const { id } = await params;

    if (!hasPermission(user, "employees.update")) {
      return ApiResponse.forbidden();
    }

    const body = await request.json();
    const validated = updateEmployeeSchema.parse(body);
    const { ipAddress, userAgent } = getClientInfo(request);

    const existing = await prisma.employee.findUnique({
      where: { id },
      include: { user: true },
    });
    if (!existing) return ApiResponse.notFound();

    const employee = await prisma.employee.update({
      where: { id },
      data: {
        ...(validated.firstNameAr && { firstNameAr: validated.firstNameAr }),
        ...(validated.lastNameAr && { lastNameAr: validated.lastNameAr }),
        ...(validated.firstNameEn && { firstNameEn: validated.firstNameEn }),
        ...(validated.lastNameEn && { lastNameEn: validated.lastNameEn }),
        ...(validated.gender && { gender: validated.gender }),
        ...(validated.maritalStatus && { maritalStatus: validated.maritalStatus }),
        ...(validated.dateOfBirth && { dateOfBirth: new Date(validated.dateOfBirth) }),
        ...(validated.nationality !== undefined && { nationality: validated.nationality }),
        ...(validated.phone !== undefined && { phone: validated.phone }),
        ...(validated.address !== undefined && { address: validated.address }),
        ...(validated.departmentId && { departmentId: validated.departmentId }),
        ...(validated.positionId && { positionId: validated.positionId }),
        ...(validated.managerId !== undefined && { managerId: validated.managerId || null }),
        ...(validated.contractType && { contractType: validated.contractType }),
        ...(validated.contractEndDate !== undefined && { contractEndDate: validated.contractEndDate ? new Date(validated.contractEndDate) : null }),
        ...(validated.status && { status: validated.status }),
        ...(validated.basicSalary !== undefined && { basicSalary: validated.basicSalary }),
        ...(validated.housingAllowance !== undefined && { housingAllowance: validated.housingAllowance }),
        ...(validated.transportAllowance !== undefined && { transportAllowance: validated.transportAllowance }),
        ...(validated.otherAllowances !== undefined && { otherAllowances: validated.otherAllowances }),
        ...(validated.bankName !== undefined && { bankName: validated.bankName }),
        ...(validated.bankAccountNumber !== undefined && { bankAccountNumber: validated.bankAccountNumber }),
        ...(validated.iban !== undefined && { iban: validated.iban }),
        ...(validated.iqamaNumber !== undefined && { iqamaNumber: validated.iqamaNumber }),
        ...(validated.iqamaIssueDate !== undefined && { iqamaIssueDate: validated.iqamaIssueDate ? new Date(validated.iqamaIssueDate) : null }),
        ...(validated.iqamaExpiryDate !== undefined && { iqamaExpiryDate: validated.iqamaExpiryDate ? new Date(validated.iqamaExpiryDate) : null }),
        ...(validated.passportIssueDate !== undefined && { passportIssueDate: validated.passportIssueDate ? new Date(validated.passportIssueDate) : null }),
        ...(validated.passportExpiryDate !== undefined && { passportExpiryDate: validated.passportExpiryDate ? new Date(validated.passportExpiryDate) : null }),
        ...(validated.annualLeaveBalance !== undefined && { annualLeaveBalance: validated.annualLeaveBalance }),
        ...(validated.sickLeaveBalance !== undefined && { sickLeaveBalance: validated.sickLeaveBalance }),
      },
      include: { department: true, position: true, user: true },
    });

    await createAuditLog({
      userId: user.id,
      action: "UPDATE",
      resource: "Employee",
      resourceId: id,
      description: `Updated employee ${employee.employeeCode}`,
      ipAddress,
      userAgent,
      oldValues: { ...existing },
    });

    return ApiResponse.success(employee, 200, { message: "Employee updated successfully" });
  } catch (error) {
    return handleApiError(error);
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await requireAuth();
    const { id } = await params;

    if (!hasPermission(user, "employees.delete")) {
      return ApiResponse.forbidden();
    }

    const { ipAddress, userAgent } = getClientInfo(request);

    // Soft delete
    await prisma.employee.update({
      where: { id },
      data: { deletedAt: new Date(), status: "TERMINATED" },
    });

    await createAuditLog({
      userId: user.id,
      action: "DELETE",
      resource: "Employee",
      resourceId: id,
      description: "Employee terminated (soft delete)",
      ipAddress,
      userAgent,
    });

    return ApiResponse.success({ message: "Employee terminated successfully" });
  } catch (error) {
    return handleApiError(error);
  }
}
