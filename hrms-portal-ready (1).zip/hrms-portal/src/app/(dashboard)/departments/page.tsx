import { Suspense } from "react";
import { getSession, hasPermission } from "@/lib/auth";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Building2, Plus, Users, MoreHorizontal } from "lucide-react";

export default async function DepartmentsPage() {
  const user = await getSession();
  if (!user) redirect("/login");

  const departments = await prisma.department.findMany({
    where: { isActive: true },
    include: {
      manager: { select: { firstNameEn: true, lastNameEn: true } },
      _count: { select: { employees: true } },
    },
    orderBy: { nameEn: "asc" },
  }).catch(() => []);

  const canManage = hasPermission(user, "departments.manage");

  return (
    <div className="space-y-6 animate-fade-in-up">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Departments</h1>
          <p className="text-muted-foreground mt-1">Organizational structure and teams</p>
        </div>
        {canManage && (
          <Button className="gap-2">
            <Plus className="h-4 w-4" />
            Add Department
          </Button>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {departments.map((dept) => (
          <Card key={dept.id} className="card-hover">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="h-12 w-12 rounded-xl gradient-primary flex items-center justify-center">
                  <Building2 className="h-6 w-6 text-white" />
                </div>
                <Badge variant="secondary">{dept.code}</Badge>
              </div>
              <CardTitle className="mt-3">{dept.nameEn}</CardTitle>
              <CardDescription>{dept.nameAr}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Users className="h-4 w-4" />
                  {dept._count.employees} employees
                </div>
                {dept.manager && (
                  <div className="text-xs text-muted-foreground">
                    Lead: {dept.manager.firstNameEn} {dept.manager.lastNameEn}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
