import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth, hasPermission } from "@/lib/auth";
import { ApiResponse, handleApiError } from "@/lib/api-response";

export async function GET(request: NextRequest) {
  try {
    const user = await requireAuth();
    if (!hasPermission(user, "audit.view")) {
      return ApiResponse.forbidden();
    }

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get("page") || "1");
    const pageSize = parseInt(searchParams.get("pageSize") || "20");

    const where: any = {};
    if (searchParams.get("userId")) where.userId = searchParams.get("userId");
    if (searchParams.get("action")) where.action = searchParams.get("action");
    if (searchParams.get("resource")) where.resource = searchParams.get("resource");
    if (searchParams.get("status")) where.status = searchParams.get("status");

    const [logs, total] = await Promise.all([
      prisma.auditLog.findMany({
        where,
        include: { user: { select: { id: true, email: true } } },
        orderBy: { createdAt: "desc" },
        skip: (page - 1) * pageSize,
        take: pageSize,
      }),
      prisma.auditLog.count({ where }),
    ]);

    return ApiResponse.paginated(logs, total, page, pageSize);
  } catch (error) {
    return handleApiError(error);
  }
}
