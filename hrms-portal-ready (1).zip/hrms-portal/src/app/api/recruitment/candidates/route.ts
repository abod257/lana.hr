import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth, hasPermission } from "@/lib/auth";
import { ApiResponse, handleApiError } from "@/lib/api-response";
import { createAuditLog, getClientInfo } from "@/lib/audit";
import { candidateSchema } from "@/lib/validations";

export async function GET(request: NextRequest) {
  try {
    await requireAuth();
    const { searchParams } = new URL(request.url);
    const jobOpeningId = searchParams.get("jobOpeningId");
    const status = searchParams.get("status");

    const where: any = {};
    if (jobOpeningId) where.jobOpeningId = jobOpeningId;
    if (status) where.status = status;

    const candidates = await prisma.candidate.findMany({
      where,
      include: {
        jobOpening: { select: { id: true, titleEn: true, titleAr: true } },
        _count: { select: { interviews: true } },
      },
      orderBy: { createdAt: "desc" },
    });

    return ApiResponse.success(candidates);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await requireAuth();
    if (!hasPermission(user, "recruitment.manage")) {
      return ApiResponse.forbidden();
    }

    const body = await request.json();
    const validated = candidateSchema.parse(body);
    const { ipAddress, userAgent } = getClientInfo(request);

    const candidate = await prisma.candidate.create({
      data: {
        ...validated,
        status: "NEW",
      },
    });

    await createAuditLog({
      userId: user.id,
      action: "CREATE",
      resource: "Candidate",
      resourceId: candidate.id,
      description: `Added candidate ${validated.firstName} ${validated.lastName}`,
      ipAddress,
      userAgent,
    });

    return ApiResponse.created(candidate, "Candidate added");
  } catch (error) {
    return handleApiError(error);
  }
}
