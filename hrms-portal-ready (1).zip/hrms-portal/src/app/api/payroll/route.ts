import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth, hasPermission } from "@/lib/auth";
import { ApiResponse, handleApiError } from "@/lib/api-response";
import { createAuditLog, getClientInfo } from "@/lib/audit";
import { payrollProcessSchema, paginationSchema } from "@/lib/validations";
import { generateId } from "@/lib/utils";

export async function GET(request: NextRequest) {
  try {
    const user = await requireAuth();
    const { searchParams } = new URL(request.url);
    const { page, pageSize, sortBy, sortOrder } = paginationSchema.parse({
      page: searchParams.get("page") || undefined,
      pageSize: searchParams.get("pageSize") || undefined,
      sortBy: searchParams.get("sortBy") || undefined,
      sortOrder: searchParams.get("sortOrder") || undefined,
    });

    if (!hasPermission(user, "payroll.view_all")) {
      return ApiResponse.forbidden();
    }

    const where: any = {};
    if (searchParams.get("status")) where.status = searchParams.get("status");
    if (searchParams.get("period")) where.period = searchParams.get("period");

    const [payrolls, total] = await Promise.all([
      prisma.payroll.findMany({
        where,
        include: { _count: { select: { payslips: true } } },
        orderBy: { [sortBy || "period"]: sortOrder },
        skip: (page - 1) * pageSize,
        take: pageSize,
      }),
      prisma.payroll.count({ where }),
    ]);

    return ApiResponse.paginated(payrolls, total, page, pageSize);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await requireAuth();
    if (!hasPermission(user, "payroll.process")) {
      return ApiResponse.forbidden();
    }

    const body = await request.json();
    const validated = payrollProcessSchema.parse(body);
    const { ipAddress, userAgent } = getClientInfo(request);

    // Check if payroll for this period already exists
    const existing = await prisma.payroll.findUnique({
      where: { period: validated.period },
    });
    if (existing) {
      return ApiResponse.conflict(`Payroll for period ${validated.period} already exists`);
    }

    // Create payroll record
    const payroll = await prisma.payroll.create({
      data: {
        period: validated.period,
        startDate: new Date(validated.startDate),
        endDate: new Date(validated.endDate),
        paymentDate: validated.paymentDate ? new Date(validated.paymentDate) : null,
        status: "PROCESSING",
        processedById: user.id,
        notes: validated.notes,
      },
    });

    await createAuditLog({
      userId: user.id,
      action: "PROCESS_PAYROLL",
      resource: "Payroll",
      resourceId: payroll.id,
      description: `Initiated payroll processing for ${validated.period}`,
      ipAddress,
      userAgent,
    });

    return ApiResponse.created(payroll, "Payroll processing started");
  } catch (error) {
    return handleApiError(error);
  }
}
