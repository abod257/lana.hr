import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth, hasPermission } from "@/lib/auth";
import { ApiResponse, handleApiError } from "@/lib/api-response";
import { createAuditLog, getClientInfo } from "@/lib/audit";
import { departmentSchema, paginationSchema } from "@/lib/validations";

export async function GET(request: NextRequest) {
  try {
    await requireAuth();
    const { searchParams } = new URL(request.url);
    const { page, pageSize, search } = paginationSchema.parse({
      page: searchParams.get("page") || undefined,
      pageSize: searchParams.get("pageSize") || undefined,
      search: searchParams.get("search") || undefined,
    });

    const where: any = { isActive: true };
    if (search) {
      where.OR = [
        { nameAr: { contains: search, mode: "insensitive" } },
        { nameEn: { contains: search, mode: "insensitive" } },
        { code: { contains: search, mode: "insensitive" } },
      ];
    }

    const [departments, total] = await Promise.all([
      prisma.department.findMany({
        where,
        include: {
          manager: { select: { id: true, firstNameEn: true, lastNameEn: true } },
          _count: { select: { employees: true } },
        },
        orderBy: { nameEn: "asc" },
        skip: (page - 1) * pageSize,
        take: pageSize,
      }),
      prisma.department.count({ where }),
    ]);

    return ApiResponse.paginated(departments, total, page, pageSize);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await requireAuth();
    if (!hasPermission(user, "departments.manage")) {
      return ApiResponse.forbidden();
    }

    const body = await request.json();
    const validated = departmentSchema.parse(body);
    const { ipAddress, userAgent } = getClientInfo(request);

    const existing = await prisma.department.findUnique({
      where: { code: validated.code },
    });
    if (existing) return ApiResponse.conflict("Department code already exists");

    const department = await prisma.department.create({ data: validated });

    await createAuditLog({
      userId: user.id,
      action: "CREATE",
      resource: "Department",
      resourceId: department.id,
      description: `Created department ${department.nameEn}`,
      ipAddress,
      userAgent,
    });

    return ApiResponse.created(department);
  } catch (error) {
    return handleApiError(error);
  }
}
