import { Suspense } from "react";
import { getSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { DashboardStats } from "@/components/dashboard/dashboard-stats";
import { DashboardCharts } from "@/components/dashboard/dashboard-charts";
import { DashboardRecent } from "@/components/dashboard/dashboard-recent";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Calendar,
  Clock,
  FileText,
  Users,
  TrendingUp,
  AlertCircle,
  Cake,
  Gift,
  Sparkles,
} from "lucide-react";
import Link from "next/link";
import { formatDate, formatRelativeTime, getRelativeTime } from "@/lib/utils";

async function getDashboardData(userId: string, roleName: string, employeeId?: string) {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
  const startOfYear = new Date(today.getFullYear(), 0, 1);

  // Common stats
  const [
    totalEmployees,
    activeEmployees,
    todayAttendance,
    presentToday,
    onLeaveToday,
    pendingLeaveRequests,
    pendingLoanRequests,
    pendingExpenseClaims,
    pendingOvertimeRequests,
    upcomingHolidays,
    recentNotifications,
    unreadNotifications,
  ] = await Promise.all([
    prisma.employee.count({ where: { deletedAt: null } }).catch(() => 0),
    prisma.employee.count({ where: { deletedAt: null, status: "ACTIVE" } }).catch(() => 0),
    prisma.attendance.findMany({
      where: { date: today },
      include: { employee: true },
      take: 10,
    }).catch(() => []),
    prisma.attendance.count({ where: { date: today, status: "PRESENT" } }).catch(() => 0),
    prisma.leaveRequest.count({
      where: {
        status: "APPROVED",
        startDate: { lte: today },
        endDate: { gte: today },
      },
    }).catch(() => 0),
    prisma.leaveRequest.count({ where: { status: "PENDING" } }).catch(() => 0),
    prisma.loanRequest.count({ where: { status: "PENDING" } }).catch(() => 0),
    prisma.expenseClaim.count({ where: { status: "PENDING" } }).catch(() => 0),
    prisma.overtimeRequest.count({ where: { status: "PENDING" } }).catch(() => 0),
    prisma.holiday.findMany({
      where: { date: { gte: today } },
      orderBy: { date: "asc" },
      take: 3,
    }).catch(() => []),
    prisma.notification.findMany({
      where: { userId },
      orderBy: { createdAt: "desc" },
      take: 5,
    }).catch(() => []),
    prisma.notification.count({ where: { userId, isRead: false } }).catch(() => 0),
  ]);

  // Today's birthdays
  const allEmployees = await prisma.employee.findMany({
    where: { deletedAt: null, dateOfBirth: { not: null } },
    select: { id: true, firstNameAr: true, firstNameEn: true, lastNameAr: true, lastNameEn: true, dateOfBirth: true, profilePicture: true },
  }).catch(() => []);

  const birthdaysToday = allEmployees.filter((emp) => {
    if (!emp.dateOfBirth) return false;
    const dob = new Date(emp.dateOfBirth);
    return dob.getMonth() === today.getMonth() && dob.getDate() === today.getDate();
  });

  // New hires this month
  const newHires = await prisma.employee.count({
    where: { deletedAt: null, hireDate: { gte: startOfMonth } },
  }).catch(() => 0);

  // Open positions
  const openPositions = await prisma.jobOpening.count({
    where: { status: "OPEN" },
  }).catch(() => 0);

  // Documents expiring soon (within 30 days)
  const thirtyDaysLater = new Date();
  thirtyDaysLater.setDate(thirtyDaysLater.getDate() + 30);
  const expiringDocs = await prisma.employeeDocument.count({
    where: {
      expiryDate: {
        gte: today,
        lte: thirtyDaysLater,
      },
      status: "ACTIVE",
    },
  }).catch(() => 0);

  // Personal stats for employee
  let personalStats = null;
  if (employeeId) {
    const [myAttendance, myPending, myApproved, myPayslips] = await Promise.all([
      prisma.attendance.findFirst({
        where: { employeeId, date: today },
      }).catch(() => null),
      prisma.leaveRequest.count({
        where: { employeeId, status: "PENDING" },
      }).catch(() => 0),
      prisma.leaveRequest.count({
        where: { employeeId, status: "APPROVED" },
      }).catch(() => 0),
      prisma.payslip.count({ where: { employeeId } }).catch(() => 0),
    ]);
    personalStats = { myAttendance, myPending, myApproved, myPayslips };
  }

  return {
    totalEmployees,
    activeEmployees,
    presentToday,
    onLeaveToday,
    absentToday: activeEmployees - presentToday - onLeaveToday,
    pendingLeaveRequests,
    pendingLoanRequests,
    pendingExpenseClaims,
    pendingOvertimeRequests,
    upcomingHolidays,
    recentNotifications,
    unreadNotifications,
    birthdaysToday,
    newHires,
    openPositions,
    expiringDocs,
    personalStats,
  };
}

export default async function DashboardPage() {
  const user = await getSession();
  if (!user) return null;

  let data;
  try {
    data = await getDashboardData(user.id, user.role.name, user.employee?.id);
  } catch (e) {
    // Fallback for when DB is not available
    data = {
      totalEmployees: 0,
      activeEmployees: 0,
      presentToday: 0,
      onLeaveToday: 0,
      absentToday: 0,
      pendingLeaveRequests: 0,
      pendingLoanRequests: 0,
      pendingExpenseClaims: 0,
      pendingOvertimeRequests: 0,
      upcomingHolidays: [],
      recentNotifications: [],
      unreadNotifications: 0,
      birthdaysToday: [],
      newHires: 0,
      openPositions: 0,
      expiringDocs: 0,
      personalStats: null,
    };
  }

  const firstName = user.employee?.firstNameEn || user.email.split("@")[0];

  return (
    <div className="space-y-6 animate-fade-in-up">
      {/* Welcome Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">
            {user.employee?.firstNameAr
              ? `أهلاً، ${user.employee.firstNameAr} 👋`
              : `Welcome back, ${firstName} 👋`}
          </h1>
          <p className="text-muted-foreground mt-1">
            {new Date().toLocaleDateString("en-US", { weekday: "long", year: "numeric", month: "long", day: "numeric" })}
          </p>
        </div>
        <div className="flex gap-2">
          <Link href="/attendance">
            <Button variant="outline" className="gap-2">
              <Clock className="h-4 w-4" />
              Check In
            </Button>
          </Link>
          <Link href="/leave">
            <Button className="gap-2">
              <Calendar className="h-4 w-4" />
              Request Leave
            </Button>
          </Link>
        </div>
      </div>

      {/* Stats Cards */}
      <DashboardStats
        data={data}
        roleName={user.role.name}
      />

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-primary" />
            Quick Actions
          </CardTitle>
          <CardDescription>Frequently used actions</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <Link href="/leave">
              <Button variant="outline" className="w-full h-auto flex-col py-4 gap-2">
                <Calendar className="h-5 w-5 text-primary" />
                <span className="text-xs">Request Leave</span>
              </Button>
            </Link>
            <Link href="/attendance">
              <Button variant="outline" className="w-full h-auto flex-col py-4 gap-2">
                <Clock className="h-5 w-5 text-success" />
                <span className="text-xs">Attendance</span>
              </Button>
            </Link>
            <Link href="/payroll/payslips">
              <Button variant="outline" className="w-full h-auto flex-col py-4 gap-2">
                <FileText className="h-5 w-5 text-info" />
                <span className="text-xs">My Payslips</span>
              </Button>
            </Link>
            <Link href="/documents">
              <Button variant="outline" className="w-full h-auto flex-col py-4 gap-2">
                <FileText className="h-5 w-5 text-warning" />
                <span className="text-xs">Documents</span>
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>

      {/* Charts */}
      <DashboardCharts />

      {/* Recent Activity */}
      <DashboardRecent data={data} />

      {/* Birthdays & Holidays side by side */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Birthdays Today */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Cake className="h-5 w-5 text-pink-500" />
              Birthdays Today
            </CardTitle>
          </CardHeader>
          <CardContent>
            {data.birthdaysToday.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-8">
                No birthdays today
              </p>
            ) : (
              <div className="space-y-3">
                {data.birthdaysToday.map((emp: any) => (
                  <div key={emp.id} className="flex items-center gap-3 p-2 rounded-lg hover:bg-accent">
                    <div className="h-10 w-10 rounded-full gradient-primary flex items-center justify-center text-white font-semibold">
                      {emp.firstNameEn?.[0]}{emp.lastNameEn?.[0]}
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-sm">{emp.firstNameEn} {emp.lastNameEn}</p>
                      <p className="text-xs text-muted-foreground">Happy Birthday! 🎉</p>
                    </div>
                    <Button size="sm" variant="ghost">
                      <Gift className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Upcoming Holidays */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5 text-info" />
              Upcoming Holidays
            </CardTitle>
          </CardHeader>
          <CardContent>
            {data.upcomingHolidays.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-8">
                No upcoming holidays
              </p>
            ) : (
              <div className="space-y-3">
                {data.upcomingHolidays.map((holiday: any) => (
                  <div key={holiday.id} className="flex items-center justify-between p-3 rounded-lg bg-accent/30">
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 rounded-lg bg-info/10 flex items-center justify-center">
                        <Calendar className="h-5 w-5 text-info" />
                      </div>
                      <div>
                        <p className="font-medium text-sm">{holiday.nameEn}</p>
                        <p className="text-xs text-muted-foreground">
                          {formatDate(holiday.date, "en-US", { weekday: "short", month: "short", day: "numeric" })}
                        </p>
                      </div>
                    </div>
                    <Badge variant={holiday.isPaid ? "success" : "secondary"}>
                      {holiday.isPaid ? "Paid" : "Unpaid"}
                    </Badge>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
