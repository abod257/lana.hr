import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth, hasPermission } from "@/lib/auth";
import { ApiResponse, handleApiError } from "@/lib/api-response";
import { createAuditLog, getClientInfo } from "@/lib/audit";
import { leaveRequestSchema, paginationSchema } from "@/lib/validations";
import { generateId } from "@/lib/utils";
import { differenceInDays } from "date-fns";

export async function GET(request: NextRequest) {
  try {
    const user = await requireAuth();
    const { searchParams } = new URL(request.url);
    const { page, pageSize, status } = paginationSchema.parse({
      page: searchParams.get("page") || undefined,
      pageSize: searchParams.get("pageSize") || undefined,
      status: searchParams.get("status") || undefined,
    });
    const employeeId = searchParams.get("employeeId");

    const where: any = {};
    if (employeeId) where.employeeId = employeeId;
    if (status) where.status = status;

    // Role-based filter
    if (!hasPermission(user, "leave.view_all")) {
      if (hasPermission(user, "leave.view_team") && user.employee) {
        where.employee = { managerId: user.employee.id };
      } else if (user.employee) {
        where.employeeId = user.employee.id;
      }
    }

    const [requests, total] = await Promise.all([
      prisma.leaveRequest.findMany({
        where,
        include: {
          employee: { select: { id: true, employeeCode: true, firstNameEn: true, lastNameEn: true, firstNameAr: true, lastNameAr: true, profilePicture: true } },
          approver: { select: { id: true, email: true } },
        },
        orderBy: { createdAt: "desc" },
        skip: (page - 1) * pageSize,
        take: pageSize,
      }),
      prisma.leaveRequest.count({ where }),
    ]);

    return ApiResponse.paginated(requests, total, page, pageSize);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await requireAuth();
    if (!user.employee) {
      return ApiResponse.badRequest("User is not linked to an employee record");
    }

    const body = await request.json();
    const validated = leaveRequestSchema.parse(body);
    const { ipAddress, userAgent } = getClientInfo(request);

    const startDate = new Date(validated.startDate);
    const endDate = new Date(validated.endDate);
    const days = differenceInDays(endDate, startDate) + 1;

    // Check leave balance for annual/sick
    const annualBalance = user.employee.annualLeaveBalance ?? 0;
    if (validated.leaveType === "ANNUAL" && days > annualBalance) {
      return ApiResponse.badRequest(`Insufficient annual leave balance. Available: ${annualBalance} days`);
    }

    const requestNumber = generateId("LR");

    const leaveRequest = await prisma.leaveRequest.create({
      data: {
        requestNumber,
        employeeId: user.employee.id,
        leaveType: validated.leaveType,
        startDate,
        endDate,
        days,
        reason: validated.reason,
        contactDuringLeave: validated.contactDuringLeave,
        handoverNotes: validated.handoverNotes,
        attachments: validated.attachments,
        createdById: user.id,
      },
      include: { employee: true },
    });

    // Notify manager
    if (user.employee.managerId) {
      const manager = await prisma.employee.findUnique({
        where: { id: user.employee.managerId },
        include: { user: true },
      });
      if (manager) {
        await prisma.notification.create({
          data: {
            userId: manager.user.id,
            type: "LEAVE_REQUEST",
            titleAr: "طلب إجازة جديد",
            titleEn: "New Leave Request",
            messageAr: `${user.employee.firstNameAr} ${user.employee.lastNameAr} قدم طلب إجازة`,
            messageEn: `${user.employee.firstNameEn} ${user.employee.lastNameEn} submitted a leave request`,
            link: `/leave`,
            relatedEntity: "LeaveRequest",
            relatedId: leaveRequest.id,
            priority: "NORMAL",
          },
        });
      }
    }

    await createAuditLog({
      userId: user.id,
      action: "CREATE",
      resource: "LeaveRequest",
      resourceId: leaveRequest.id,
      description: `Leave request submitted: ${validated.leaveType} for ${days} days`,
      ipAddress,
      userAgent,
    });

    return ApiResponse.created(leaveRequest, "Leave request submitted");
  } catch (error) {
    return handleApiError(error);
  }
}
