import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth, hasPermission } from "@/lib/auth";
import { ApiResponse, handleApiError } from "@/lib/api-response";
import { createAuditLog, getClientInfo } from "@/lib/audit";
import { employeeSchema, paginationSchema } from "@/lib/validations";
import { hashPassword } from "@/lib/auth";

export async function GET(request: NextRequest) {
  try {
    const user = await requireAuth();
    const { searchParams } = new URL(request.url);

    const { page, pageSize, search, sortBy, sortOrder, departmentId, status } = paginationSchema.parse({
      page: searchParams.get("page") || undefined,
      pageSize: searchParams.get("pageSize") || undefined,
      search: searchParams.get("search") || undefined,
      sortBy: searchParams.get("sortBy") || undefined,
      sortOrder: searchParams.get("sortOrder") || undefined,
    });

    // Additional filters
    const extraFilters: any = {};
    if (searchParams.get("departmentId")) extraFilters.departmentId = searchParams.get("departmentId");
    if (searchParams.get("status")) extraFilters.status = searchParams.get("status");
    if (searchParams.get("managerId")) extraFilters.managerId = searchParams.get("managerId");

    // Build where clause
    const where: any = {
      deletedAt: null,
      ...extraFilters,
    };

    if (search) {
      where.OR = [
        { firstNameAr: { contains: search, mode: "insensitive" } },
        { lastNameAr: { contains: search, mode: "insensitive" } },
        { firstNameEn: { contains: search, mode: "insensitive" } },
        { lastNameEn: { contains: search, mode: "insensitive" } },
        { email: { contains: search, mode: "insensitive" } },
        { employeeCode: { contains: search, mode: "insensitive" } },
        { nationalId: { contains: search, mode: "insensitive" } },
      ];
    }

    // Role-based filtering
    if (user.role.name === "MANAGER" && user.employee) {
      where.OR = [
        { id: user.employee.id },
        { managerId: user.employee.id },
      ];
    }

    const [employees, total] = await Promise.all([
      prisma.employee.findMany({
        where,
        include: {
          user: { select: { id: true, email: true, status: true } },
          department: { select: { id: true, nameEn: true, nameAr: true } },
          position: { select: { id: true, titleEn: true, titleAr: true } },
          manager: { select: { id: true, firstNameEn: true, lastNameEn: true, firstNameAr: true, lastNameAr: true } },
        },
        orderBy: { [sortBy || "createdAt"]: sortOrder },
        skip: (page - 1) * pageSize,
        take: pageSize,
      }),
      prisma.employee.count({ where }),
    ]);

    return ApiResponse.paginated(employees, total, page, pageSize);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await requireAuth();
    if (!hasPermission(user, "employees.create")) {
      return ApiResponse.forbidden("You don't have permission to create employees");
    }

    const body = await request.json();
    const validated = employeeSchema.parse(body);
    const { ipAddress, userAgent } = getClientInfo(request);

    // Check if email exists
    const existingEmail = await prisma.user.findUnique({
      where: { email: validated.email.toLowerCase() },
    });
    if (existingEmail) {
      return ApiResponse.conflict("Email already exists");
    }

    // Check if employee code exists
    const existingCode = await prisma.employee.findUnique({
      where: { employeeCode: validated.employeeCode },
    });
    if (existingCode) {
      return ApiResponse.conflict("Employee code already exists");
    }

    // Generate a default password (employee must change on first login)
    const defaultPassword = `Welcome@${validated.employeeCode}`;
    const passwordHash = await hashPassword(defaultPassword);

    // Create user + employee in transaction
    const result = await prisma.$transaction(async (tx) => {
      const newUser = await tx.user.create({
        data: {
          email: validated.email.toLowerCase(),
          passwordHash,
          roleId: validated.roleId,
          status: "ACTIVE",
          emailVerified: false,
        },
      });

      const employee = await tx.employee.create({
        data: {
          userId: newUser.id,
          employeeCode: validated.employeeCode,
          firstNameAr: validated.firstNameAr,
          lastNameAr: validated.lastNameAr,
          firstNameEn: validated.firstNameEn,
          lastNameEn: validated.lastNameEn,
          nationalId: validated.nationalId || null,
          passportNumber: validated.passportNumber || null,
          gender: validated.gender,
          maritalStatus: validated.maritalStatus,
          dateOfBirth: validated.dateOfBirth ? new Date(validated.dateOfBirth) : null,
          nationality: validated.nationality,
          phone: validated.phone,
          personalEmail: validated.personalEmail,
          address: validated.address,
          city: validated.city,
          country: validated.country,
          departmentId: validated.departmentId,
          positionId: validated.positionId,
          managerId: validated.managerId || null,
          hireDate: new Date(validated.hireDate),
          contractType: validated.contractType,
          contractEndDate: validated.contractEndDate ? new Date(validated.contractEndDate) : null,
          status: validated.status,
          basicSalary: validated.basicSalary,
          housingAllowance: validated.housingAllowance,
          transportAllowance: validated.transportAllowance,
          otherAllowances: validated.otherAllowances,
          bankName: validated.bankName,
          bankAccountNumber: validated.bankAccountNumber,
          iban: validated.iban,
          iqamaNumber: validated.iqamaNumber,
          iqamaIssueDate: validated.iqamaIssueDate ? new Date(validated.iqamaIssueDate) : null,
          iqamaExpiryDate: validated.iqamaExpiryDate ? new Date(validated.iqamaExpiryDate) : null,
          passportIssueDate: validated.passportIssueDate ? new Date(validated.passportIssueDate) : null,
          passportExpiryDate: validated.passportExpiryDate ? new Date(validated.passportExpiryDate) : null,
          workSchedule: validated.workSchedule,
          annualLeaveBalance: validated.annualLeaveBalance,
          sickLeaveBalance: validated.sickLeaveBalance,
        },
        include: {
          department: true,
          position: true,
          user: true,
        },
      });

      return { user: newUser, employee };
    });

    await createAuditLog({
      userId: user.id,
      action: "CREATE",
      resource: "Employee",
      resourceId: result.employee.id,
      description: `Created employee ${result.employee.employeeCode}`,
      ipAddress,
      userAgent,
      newValues: { employeeCode: result.employee.employeeCode, email: validated.email },
    });

    return ApiResponse.created(result.employee, "Employee created successfully");
  } catch (error) {
    return handleApiError(error);
  }
}
