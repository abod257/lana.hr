import { redirect } from "next/navigation";
import { getSession, hasPermission } from "@/lib/auth";
import { EmployeeForm } from "@/components/employees/employee-form";
import { prisma } from "@/lib/prisma";

export default async function NewEmployeePage() {
  const user = await getSession();
  if (!user) redirect("/login");
  if (!hasPermission(user, "employees.create")) redirect("/employees");

  const [departments, positions, roles] = await Promise.all([
    prisma.department.findMany({ where: { isActive: true }, orderBy: { nameEn: "asc" } }),
    prisma.position.findMany({ where: { isActive: true }, orderBy: { titleEn: "asc" } }),
    prisma.role.findMany({ orderBy: { level: "asc" } }),
  ]).catch(() => [[], [], []]);

  return (
    <div className="space-y-6 animate-fade-in-up">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Add Employee</h1>
        <p className="text-muted-foreground mt-1">Create a new employee record</p>
      </div>
      <EmployeeForm
        departments={departments}
        positions={positions}
        roles={roles}
      />
    </div>
  );
}
