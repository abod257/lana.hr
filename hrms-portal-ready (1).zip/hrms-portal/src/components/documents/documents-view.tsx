"use client";

import * as React from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FileText, Upload, AlertCircle, CheckCircle2, Clock, Download } from "lucide-react";
import { toast } from "sonner";

export function DocumentsView() {
  const [documents, setDocuments] = React.useState<any[]>([]);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const fetchDocs = async () => {
      try {
        const res = await fetch("/api/documents");
        const data = await res.json();
        if (data.success) setDocuments(data.data || []);
      } catch {} finally {
        setLoading(false);
      }
    };
    fetchDocs();
  }, []);

  const now = new Date();
  const thirtyDays = new Date();
  thirtyDays.setDate(thirtyDays.getDate() + 30);

  const expiringSoon = documents.filter((d) => {
    if (!d.expiryDate) return false;
    const exp = new Date(d.expiryDate);
    return exp > now && exp <= thirtyDays;
  });

  const expired = documents.filter((d) => {
    if (!d.expiryDate) return false;
    return new Date(d.expiryDate) < now;
  });

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Documents</p>
                <p className="text-2xl font-bold">{documents.length}</p>
              </div>
              <FileText className="h-8 w-8 text-primary opacity-80" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Expiring Soon</p>
                <p className="text-2xl font-bold text-warning">{expiringSoon.length}</p>
              </div>
              <Clock className="h-8 w-8 text-warning opacity-80" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Expired</p>
                <p className="text-2xl font-bold text-destructive">{expired.length}</p>
              </div>
              <AlertCircle className="h-8 w-8 text-destructive opacity-80" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Active</p>
                <p className="text-2xl font-bold text-success">{documents.filter(d => d.status === "ACTIVE").length}</p>
              </div>
              <CheckCircle2 className="h-8 w-8 text-success opacity-80" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Document Library</CardTitle>
              <CardDescription>Manage all employee documents</CardDescription>
            </div>
            <Button className="gap-2">
              <Upload className="h-4 w-4" />
              Upload Document
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="all">
            <TabsList>
              <TabsTrigger value="all">All ({documents.length})</TabsTrigger>
              <TabsTrigger value="expiring">Expiring ({expiringSoon.length})</TabsTrigger>
              <TabsTrigger value="expired">Expired ({expired.length})</TabsTrigger>
            </TabsList>

            <TabsContent value="all" className="mt-4">
              {loading ? (
                <div className="text-center py-12">Loading...</div>
              ) : documents.length === 0 ? (
                <div className="text-center py-12">
                  <FileText className="h-12 w-12 mx-auto text-muted-foreground/50 mb-3" />
                  <p className="text-muted-foreground">No documents uploaded</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {documents.map((doc) => (
                    <Card key={doc.id}>
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between gap-4">
                          <div className="flex items-center gap-3 flex-1 min-w-0">
                            <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                              <FileText className="h-5 w-5 text-primary" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <h4 className="font-medium text-sm truncate">{doc.titleEn}</h4>
                              <p className="text-xs text-muted-foreground">
                                {doc.documentType} • {doc.employee?.firstNameEn} {doc.employee?.lastNameEn}
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            {doc.expiryDate && (
                              <Badge variant={new Date(doc.expiryDate) < now ? "destructive" : new Date(doc.expiryDate) <= thirtyDays ? "warning" : "success"}>
                                {new Date(doc.expiryDate) < now ? "Expired" : `Expires ${new Date(doc.expiryDate).toLocaleDateString()}`}
                              </Badge>
                            )}
                            <Button variant="ghost" size="icon">
                              <Download className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>

            <TabsContent value="expiring" className="mt-4">
              <div className="text-center py-8 text-muted-foreground">
                {expiringSoon.length === 0 ? "No documents expiring soon" : `${expiringSoon.length} documents expiring within 30 days`}
              </div>
            </TabsContent>

            <TabsContent value="expired" className="mt-4">
              <div className="text-center py-8 text-muted-foreground">
                {expired.length === 0 ? "No expired documents" : `${expired.length} expired documents`}
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
