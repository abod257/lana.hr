"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Save, ArrowLeft, User, Building2, DollarSign, FileText } from "lucide-react";
import { toast } from "sonner";
import Link from "next/link";
import { employeeSchema, type EmployeeInput } from "@/lib/validations";

interface EmployeeFormProps {
  departments: any[];
  positions: any[];
  roles: any[];
  initialData?: Partial<EmployeeInput>;
}

export function EmployeeForm({ departments, positions, roles, initialData }: EmployeeFormProps) {
  const router = useRouter();
  const [submitting, setSubmitting] = React.useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    watch,
  } = useForm<EmployeeInput>({
    resolver: zodResolver(employeeSchema),
    defaultValues: {
      contractType: "PERMANENT",
      status: "ACTIVE",
      gender: "MALE",
      maritalStatus: "SINGLE",
      workSchedule: "STANDARD",
      annualLeaveBalance: 21,
      sickLeaveBalance: 30,
      ...initialData,
    },
  });

  const onSubmit = async (data: EmployeeInput) => {
    setSubmitting(true);
    try {
      const res = await fetch("/api/employees", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      const result = await res.json();
      if (result.success) {
        toast.success("Employee created successfully");
        router.push(`/employees/${result.data.id}`);
      } else {
        toast.error(result.message || "Failed to create");
      }
    } catch {
      toast.error("Network error");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      <div className="flex justify-between items-center">
        <Link href="/employees">
          <Button variant="ghost" type="button" className="gap-2">
            <ArrowLeft className="h-4 w-4 rtl:rotate-180" />
            Back
          </Button>
        </Link>
        <Button type="submit" loading={submitting} className="gap-2">
          <Save className="h-4 w-4" />
          Save Employee
        </Button>
      </div>

      <Tabs defaultValue="personal">
        <TabsList>
          <TabsTrigger value="personal" className="gap-2"><User className="h-4 w-4" />Personal</TabsTrigger>
          <TabsTrigger value="employment" className="gap-2"><Building2 className="h-4 w-4" />Employment</TabsTrigger>
          <TabsTrigger value="compensation" className="gap-2"><DollarSign className="h-4 w-4" />Compensation</TabsTrigger>
          <TabsTrigger value="documents" className="gap-2"><FileText className="h-4 w-4" />Documents</TabsTrigger>
        </TabsList>

        <TabsContent value="personal">
          <Card>
            <CardHeader>
              <CardTitle>Personal Information</CardTitle>
              <CardDescription>Basic employee details</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label>Employee Code *</Label>
                  <Input {...register("employeeCode")} placeholder="EMP-001" />
                  {errors.employeeCode && <p className="text-xs text-destructive mt-1">{errors.employeeCode.message}</p>}
                </div>
                <div>
                  <Label>Email *</Label>
                  <Input {...register("email")} type="email" placeholder="name@company.com" />
                  {errors.email && <p className="text-xs text-destructive mt-1">{errors.email.message}</p>}
                </div>
                <div>
                  <Label>First Name (English) *</Label>
                  <Input {...register("firstNameEn")} />
                  {errors.firstNameEn && <p className="text-xs text-destructive mt-1">{errors.firstNameEn.message}</p>}
                </div>
                <div>
                  <Label>Last Name (English) *</Label>
                  <Input {...register("lastNameEn")} />
                  {errors.lastNameEn && <p className="text-xs text-destructive mt-1">{errors.lastNameEn.message}</p>}
                </div>
                <div>
                  <Label>First Name (Arabic) *</Label>
                  <Input {...register("firstNameAr")} dir="rtl" />
                  {errors.firstNameAr && <p className="text-xs text-destructive mt-1">{errors.firstNameAr.message}</p>}
                </div>
                <div>
                  <Label>Last Name (Arabic) *</Label>
                  <Input {...register("lastNameAr")} dir="rtl" />
                  {errors.lastNameAr && <p className="text-xs text-destructive mt-1">{errors.lastNameAr.message}</p>}
                </div>
                <div>
                  <Label>Gender *</Label>
                  <Select onValueChange={(v) => setValue("gender", v as any)} defaultValue={watch("gender")}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="MALE">Male</SelectItem>
                      <SelectItem value="FEMALE">Female</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Marital Status</Label>
                  <Select onValueChange={(v) => setValue("maritalStatus", v as any)} defaultValue={watch("maritalStatus")}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="SINGLE">Single</SelectItem>
                      <SelectItem value="MARRIED">Married</SelectItem>
                      <SelectItem value="DIVORCED">Divorced</SelectItem>
                      <SelectItem value="WIDOWED">Widowed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>National ID</Label>
                  <Input {...register("nationalId")} placeholder="1XXXXXXXXX" />
                </div>
                <div>
                  <Label>Date of Birth</Label>
                  <Input {...register("dateOfBirth")} type="date" />
                </div>
                <div>
                  <Label>Nationality</Label>
                  <Input {...register("nationality")} placeholder="Saudi Arabia" />
                </div>
                <div>
                  <Label>Phone</Label>
                  <Input {...register("phone")} placeholder="+966 5X XXX XXXX" />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="employment">
          <Card>
            <CardHeader>
              <CardTitle>Employment Details</CardTitle>
              <CardDescription>Position and contract information</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label>Department *</Label>
                  <Select onValueChange={(v) => setValue("departmentId", v)}>
                    <SelectTrigger><SelectValue placeholder="Select department" /></SelectTrigger>
                    <SelectContent>
                      {departments.map((d) => (
                        <SelectItem key={d.id} value={d.id}>{d.nameEn}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {errors.departmentId && <p className="text-xs text-destructive mt-1">{errors.departmentId.message}</p>}
                </div>
                <div>
                  <Label>Position *</Label>
                  <Select onValueChange={(v) => setValue("positionId", v)}>
                    <SelectTrigger><SelectValue placeholder="Select position" /></SelectTrigger>
                    <SelectContent>
                      {positions.map((p) => (
                        <SelectItem key={p.id} value={p.id}>{p.titleEn}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {errors.positionId && <p className="text-xs text-destructive mt-1">{errors.positionId.message}</p>}
                </div>
                <div>
                  <Label>Role *</Label>
                  <Select onValueChange={(v) => setValue("roleId", v)}>
                    <SelectTrigger><SelectValue placeholder="Select role" /></SelectTrigger>
                    <SelectContent>
                      {roles.map((r) => (
                        <SelectItem key={r.id} value={r.id}>{r.displayNameEn}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {errors.roleId && <p className="text-xs text-destructive mt-1">{errors.roleId.message}</p>}
                </div>
                <div>
                  <Label>Hire Date *</Label>
                  <Input {...register("hireDate")} type="date" />
                  {errors.hireDate && <p className="text-xs text-destructive mt-1">{errors.hireDate.message}</p>}
                </div>
                <div>
                  <Label>Contract Type *</Label>
                  <Select onValueChange={(v) => setValue("contractType", v as any)} defaultValue={watch("contractType")}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="PERMANENT">Permanent</SelectItem>
                      <SelectItem value="TEMPORARY">Temporary</SelectItem>
                      <SelectItem value="PROBATION">Probation</SelectItem>
                      <SelectItem value="CONTRACT">Contract</SelectItem>
                      <SelectItem value="PART_TIME">Part Time</SelectItem>
                      <SelectItem value="INTERN">Intern</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Status</Label>
                  <Select onValueChange={(v) => setValue("status", v as any)} defaultValue={watch("status")}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ACTIVE">Active</SelectItem>
                      <SelectItem value="ON_LEAVE">On Leave</SelectItem>
                      <SelectItem value="PROBATION">Probation</SelectItem>
                      <SelectItem value="NOTICE_PERIOD">Notice Period</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Annual Leave Balance</Label>
                  <Input {...register("annualLeaveBalance")} type="number" />
                </div>
                <div>
                  <Label>Sick Leave Balance</Label>
                  <Input {...register("sickLeaveBalance")} type="number" />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="compensation">
          <Card>
            <CardHeader>
              <CardTitle>Compensation</CardTitle>
              <CardDescription>Salary and benefits</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label>Basic Salary (SAR) *</Label>
                  <Input {...register("basicSalary")} type="number" step="0.01" />
                  {errors.basicSalary && <p className="text-xs text-destructive mt-1">{errors.basicSalary.message}</p>}
                </div>
                <div>
                  <Label>Housing Allowance</Label>
                  <Input {...register("housingAllowance")} type="number" step="0.01" />
                </div>
                <div>
                  <Label>Transport Allowance</Label>
                  <Input {...register("transportAllowance")} type="number" step="0.01" />
                </div>
                <div>
                  <Label>Other Allowances</Label>
                  <Input {...register("otherAllowances")} type="number" step="0.01" />
                </div>
                <div>
                  <Label>Bank Name</Label>
                  <Input {...register("bankName")} placeholder="e.g., Al Rajhi Bank" />
                </div>
                <div>
                  <Label>Bank Account Number</Label>
                  <Input {...register("bankAccountNumber")} />
                </div>
                <div className="md:col-span-2">
                  <Label>IBAN</Label>
                  <Input {...register("iban")} placeholder="SA00 0000 0000 0000 0000 0000" />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="documents">
          <Card>
            <CardHeader>
              <CardTitle>Documents Tracking</CardTitle>
              <CardDescription>Iqama and passport expiry</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label>Iqama Number</Label>
                  <Input {...register("iqamaNumber")} />
                </div>
                <div>
                  <Label>Iqama Expiry Date</Label>
                  <Input {...register("iqamaExpiryDate")} type="date" />
                </div>
                <div>
                  <Label>Passport Number</Label>
                  <Input {...register("passportNumber")} />
                </div>
                <div>
                  <Label>Passport Expiry Date</Label>
                  <Input {...register("passportExpiryDate")} type="date" />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </form>
  );
}
