import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth } from "@/lib/auth";
import { ApiResponse, handleApiError } from "@/lib/api-response";
import { createAuditLog, getClientInfo } from "@/lib/audit";
import { loanRequestSchema } from "@/lib/validations";
import { generateId } from "@/lib/utils";

export async function POST(request: NextRequest) {
  try {
    const user = await requireAuth();
    if (!user.employee) {
      return ApiResponse.badRequest("User is not linked to an employee");
    }

    const body = await request.json();
    const validated = loanRequestSchema.parse(body);
    const { ipAddress, userAgent } = getClientInfo(request);

    const monthlyDeduction = validated.amount / validated.installments;

    const loan = await prisma.loanRequest.create({
      data: {
        requestNumber: generateId("LN"),
        employeeId: user.employee.id,
        amount: validated.amount,
        reason: validated.reason,
        installments: validated.installments,
        monthlyDeduction,
        startDate: new Date(validated.startDate),
        endDate: new Date(new Date(validated.startDate).getTime() + validated.installments * 30 * 24 * 60 * 60 * 1000),
        remainingAmount: validated.amount,
        status: "PENDING",
        notes: validated.notes,
      },
    });

    await createAuditLog({
      userId: user.id,
      action: "CREATE",
      resource: "LoanRequest",
      resourceId: loan.id,
      description: `Loan request submitted: ${validated.amount} SAR`,
      ipAddress,
      userAgent,
    });

    return ApiResponse.created(loan, "Loan request submitted");
  } catch (error) {
    return handleApiError(error);
  }
}

export async function GET(request: NextRequest) {
  try {
    const user = await requireAuth();
    const { searchParams } = new URL(request.url);
    const status = searchParams.get("status");

    const where: any = {};
    if (user.employee) {
      where.employeeId = user.employee.id;
    }
    if (status) where.status = status;

    const loans = await prisma.loanRequest.findMany({
      where,
      include: { employee: { select: { id: true, firstNameEn: true, lastNameEn: true, firstNameAr: true, lastNameAr: true, employeeCode: true } } },
      orderBy: { createdAt: "desc" },
    });

    return ApiResponse.success(loans);
  } catch (error) {
    return handleApiError(error);
  }
}
