import { Suspense } from "react";
import { getSession } from "@/lib/auth";
import { redirect } from "next/navigation";
import { EmployeesList } from "@/components/employees/employees-list";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { hasPermission } from "@/lib/auth";

export default async function EmployeesPage() {
  const user = await getSession();
  if (!user) redirect("/login");

  const canManage = hasPermission(user, "employees.create");

  return (
    <div className="space-y-6 animate-fade-in-up">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Employees</h1>
          <p className="text-muted-foreground mt-1">
            Manage employee records, contracts, and information
          </p>
        </div>
      </div>

      <Suspense fallback={<div>Loading...</div>}>
        <EmployeesList canManage={canManage} />
      </Suspense>
    </div>
  );
}
